# Design-Partner Pilot Plan

## Pilot goal

Validate that Decoda can fit a real institutional workflow for policy review, simulation, evidence generation, and operational triage.

## Suggested pilot phases

### Phase 1 - Setup
- identify customer sponsor and admin users
- map tenant roles
- configure initial policy set
- agree evidence/report format
- define success criteria

### Phase 2 - Active use
- run real or realistic simulations weekly
- test approval and incident workflows
- validate webhook/integration needs
- review evidence exports with customer stakeholders

### Phase 3 - Evaluation
- compare time saved and workflow fit
- identify missing enterprise controls
- decide expand, iterate, or stop

## Pilot length

Recommended baseline: 4 to 8 weeks.
