from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable

from app.config import settings
from app.db import db


def enqueue_job(*, job_type: str, payload: dict[str, Any], tenant_id: int | None, user_id: int | None, available_at: str, max_attempts: int | None = None) -> int:
    with db() as conn:
        cur = conn.execute(
            '''
            INSERT INTO jobs (
                tenant_id, user_id, job_type, status, payload_json, attempts, max_attempts,
                available_at, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''',
            (
                tenant_id,
                user_id,
                job_type,
                'queued',
                json.dumps(payload),
                0,
                max_attempts or settings.webhook_max_retries,
                available_at,
                available_at,
                available_at,
            ),
        )
        return int(cur.lastrowid)


def claim_next_job(worker_name: str, now_value: str, allowed_types: Iterable[str] | None = None) -> dict[str, Any] | None:
    allowed_types = list(allowed_types or [])
    with db() as conn:
        rows = conn.execute('SELECT * FROM jobs WHERE status = ? AND available_at <= ? ORDER BY id ASC', ('queued', now_value)).fetchall()
        for row in rows:
            if allowed_types and row['job_type'] not in allowed_types:
                continue
            result = conn.execute(
                '''
                UPDATE jobs
                SET status = ?, locked_at = ?, locked_by = ?, attempts = attempts + 1, updated_at = ?
                WHERE id = ? AND status = ?
                ''',
                ('processing', now_value, worker_name, now_value, row['id'], 'queued'),
            )
            if getattr(result.cursor, 'rowcount', 1) == 0:
                continue
            refreshed = conn.execute('SELECT * FROM jobs WHERE id = ?', (row['id'],)).fetchone()
            if refreshed:
                refreshed['payload'] = json.loads(refreshed['payload_json'])
                refreshed['result'] = json.loads(refreshed['result_json']) if refreshed.get('result_json') else None
                return refreshed
    return None


def complete_job(job_id: int, now_value: str, result: dict[str, Any]) -> None:
    with db() as conn:
        conn.execute(
            'UPDATE jobs SET status = ?, result_json = ?, updated_at = ?, locked_at = NULL, locked_by = NULL WHERE id = ?',
            ('completed', json.dumps(result), now_value, job_id),
        )


def retry_job(job: dict[str, Any], now_value: str, error_message: str) -> None:
    max_attempts = int(job['max_attempts'])
    attempts = int(job['attempts'])
    status = 'failed' if attempts >= max_attempts else 'queued'
    available_at = now_value
    if status == 'queued':
        delay_seconds = min(300, max(5, attempts * 15))
        next_dt = datetime.now(timezone.utc) + timedelta(seconds=delay_seconds)
        available_at = next_dt.strftime('%Y-%m-%d %H:%M:%S UTC')
    with db() as conn:
        conn.execute(
            '''
            UPDATE jobs
            SET status = ?, available_at = ?, updated_at = ?, locked_at = NULL, locked_by = NULL, last_error = ?
            WHERE id = ?
            ''',
            (status, available_at, now_value, error_message[:1000], job['id']),
        )


def get_job(job_id: int) -> dict[str, Any] | None:
    with db() as conn:
        row = conn.execute('SELECT * FROM jobs WHERE id = ?', (job_id,)).fetchone()
    if not row:
        return None
    row['payload'] = json.loads(row['payload_json'])
    row['result'] = json.loads(row['result_json']) if row.get('result_json') else None
    return row
