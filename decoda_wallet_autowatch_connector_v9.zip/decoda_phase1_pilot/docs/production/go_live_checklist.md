# Go-live checklist

## Before launch
- Replace demo credentials.
- Set production secrets outside the repo.
- Confirm database backups and restore test.
- Verify webhook delivery against a real receiver.
- Configure a real OIDC provider and test login.
- Run CI and record release artifact hashes.
- Review incident, backup, and release runbooks.

## After launch
- Review alerts daily for the first two weeks.
- Verify the worker is draining jobs.
- Review audit exports with the pilot customer.
