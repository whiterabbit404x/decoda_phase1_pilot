#!/usr/bin/env bash
set -euo pipefail
./scripts/prestart.sh
exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 2
