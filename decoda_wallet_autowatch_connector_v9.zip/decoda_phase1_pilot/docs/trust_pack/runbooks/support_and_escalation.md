# Support and Escalation Runbook

## Support model

The initial design-partner phase should use named owners for product, engineering, and security.

## Suggested severity targets

- **P1** critical service issue or confirmed security event: acknowledge within 1 hour
- **P2** material feature degradation: acknowledge within 4 business hours
- **P3** routine issue or question: acknowledge within 1 business day

## Escalation path

1. support owner triages
2. engineering owner engaged for defects or outages
3. security owner engaged for security-relevant findings
4. product owner coordinates customer communication and priorities

## Support artifacts per ticket

- tenant or customer name
- issue summary
- severity
- affected feature
- timeline
- workaround
- owner
- resolution or next step
