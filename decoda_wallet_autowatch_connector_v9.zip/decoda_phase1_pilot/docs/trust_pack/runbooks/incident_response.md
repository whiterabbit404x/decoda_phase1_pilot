# Incident Response Runbook

## Goal

Provide a repeatable response for security incidents affecting the Decoda platform or customer data.

## Severity levels

- **SEV-1**: active compromise, material customer impact, or ongoing data exposure
- **SEV-2**: serious security issue with contained or limited blast radius
- **SEV-3**: suspected issue, degraded control, or moderate operational risk
- **SEV-4**: low-risk issue, policy deviation, or informational finding

## Trigger sources

- customer report
- internal alert or log anomaly
- dependency vulnerability disclosure
- failed control validation
- external researcher or pen test finding

## Workflow

1. Open incident record and assign owner
2. Classify severity and affected scope
3. Contain impact
4. Preserve evidence and timeline
5. Communicate internally
6. Communicate externally if thresholds are met
7. Remediate and validate
8. Close with post-incident review

## First-hour checklist

- confirm whether incident is active
- preserve logs and audit exports
- disable or rotate exposed secrets if relevant
- pause risky background jobs if needed
- identify affected tenants and features
- establish internal communication channel and timestamp log

## Closure requirements

- root cause summary
- user/customer impact summary
- remediation completed
- preventive follow-up actions assigned
