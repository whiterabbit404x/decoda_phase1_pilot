# Design-Partner Pilot Pack

This folder is for the first serious institutional pilot.

## Included

- `pilot_plan.md`
- `onboarding_checklist.md`
- `success_criteria.md`
- `weekly_review_template.md`
- `mutual_action_plan.md`

The goal is to shorten the jump from product demo to repeatable customer pilot.
