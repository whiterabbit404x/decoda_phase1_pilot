# SOC 2 Readiness

This folder contains working materials for a readiness-first approach.

## Intended sequence

1. stabilize operations and control owners
2. collect evidence for key controls
3. complete readiness assessment
4. remediate gaps
5. pursue SOC 2 Type I
6. operate controls consistently
7. pursue SOC 2 Type II

This folder does not claim an active attestation. It is a preparation workspace.
