# Production deployment package

This folder contains the practical material for taking the institutional beta into a deployable production package.

Contents:
- `deployment_guide.md`
- `go_live_checklist.md`
- `oidc_real_provider_guide.md`
- `architecture.md`
- `operational_acceptance.md`
