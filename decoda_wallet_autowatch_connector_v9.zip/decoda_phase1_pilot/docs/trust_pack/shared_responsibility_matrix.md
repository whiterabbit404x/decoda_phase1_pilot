# Shared Responsibility Matrix

| Area | Decoda Responsibility | Customer Responsibility |
|---|---|---|
| Application code | Build, patch, test, and document the platform | Review configuration choices for customer deployment |
| Identity provider | Support OIDC/SAML integration patterns | Operate IdP, enforce MFA, manage user lifecycle |
| Tenant permissions | Provide RBAC model and approval workflow | Assign roles appropriately and review least privilege |
| Infrastructure | Provide reference architecture and hardening guidance | Secure cloud account, network controls, backups, and monitoring if self-hosted |
| Secrets | Support external secrets configuration | Store secrets in approved managed secret system |
| Audit exports | Provide exportable evidence packages | Review and retain exports per policy |
| Incident handling | Maintain incident process and product fixes | Report customer-side incidents and participate in coordination |
| Compliance evidence | Provide product documentation and control artifacts | Complete customer-side vendor review and deployment controls |
