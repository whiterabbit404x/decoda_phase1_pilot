# Weekly Pilot Review Template

## Week of

## Usage summary
- active users
- simulations run
- approvals completed
- incidents opened/closed
- exports generated

## What worked

## What blocked adoption

## Security or trust concerns raised

## Requested product changes

## Agreed next steps
