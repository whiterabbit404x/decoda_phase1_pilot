# Release Management Runbook

## Release gates

A release should not ship unless the following are true:

- tests pass
- migrations are reviewed
- dependency changes are reviewed
- security-impacting changes are identified
- rollback plan exists
- customer-facing changes are documented when needed

## Standard flow

1. Create release candidate
2. Review migrations and config changes
3. Run tests and verification
4. Approve release
5. Deploy to staging
6. Validate smoke checks
7. Deploy to production or pilot environment
8. Monitor logs, metrics, and background jobs
9. Record release notes and known issues
