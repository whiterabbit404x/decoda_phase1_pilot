# Backup and Restore Runbook

## Scope

This runbook covers application database, export artifacts, and essential configuration required to restore service.

## Backup policy baseline

- database backups: daily full plus more frequent point-in-time capability where supported
- export artifacts: versioned object storage or equivalent
- configuration backups: IaC or version-controlled configuration, excluding live secrets

## Restore exercise cadence

- perform restore validation at least quarterly
- record restore duration, issues found, and remediation items

## Restore checklist

1. Identify target restore point
2. Verify environment isolation before recovery
3. Restore database
4. Restore artifact storage if needed
5. Validate application startup and worker startup
6. Run smoke tests
7. Confirm audit/event integrity
8. Document actual RTO/RPO achieved
