# Decoda Security Overview

## Product summary

Decoda Security is an institutional workflow platform for security analysis of tokenized-finance control surfaces. The current enterprise build includes:

- multi-tenant application model
- local and PostgreSQL-capable data layer
- role-based access controls
- approval workflows for sensitive actions
- simulation jobs and worker-based processing
- incident tracking
- signed webhook delivery with retry handling
- monitoring summary endpoints and metrics output
- audit/export package generation
- mock OIDC-style SSO flow for demo purposes

## Hosting model

Recommended production deployment pattern:

- customer-facing application service
- API service
- background worker service
- managed PostgreSQL
- queue/cache backend
- object storage for export artifacts
- centralized logging and monitoring
- secrets manager / KMS-backed secret storage

## Security principles

1. Least privilege access
2. Tenant isolation by data access layer and permission checks
3. Auditable administrative actions
4. Fresh re-verification for sensitive admin operations
5. Secure defaults for sessions and secrets handling
6. Background execution for long-running or integration jobs
7. Exportable evidence for audit and customer review

## Current assurance posture

- Secure development and dependency hygiene: **Documented / in progress**
- SBOM generation workflow: **Documented and included as workflow**
- External penetration test: **Planned**
- SOC 2 readiness: **In progress**
- SOC 2 Type I / Type II report: **Not in place**
- Production SSO with live customer IdP: **Planned next implementation**

## Sensitive data categories to avoid claiming by default

Until real production integrations exist, this demo platform should avoid storing live customer secrets, production signing keys, or regulated customer data unless the deployment and handling controls are separately validated.
