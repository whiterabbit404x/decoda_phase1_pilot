#!/usr/bin/env bash
set -euo pipefail
python - <<'PY'
from app.main import startup_bootstrap
startup_bootstrap()
print('migrations complete')
PY
