# Design-Partner Onboarding Checklist

- sponsor identified
- security reviewer identified
- tenant admin identified
- test users created
- role matrix reviewed
- pilot data boundaries agreed
- incident contact list exchanged
- support channel established
- weekly review cadence scheduled
- success metrics approved
