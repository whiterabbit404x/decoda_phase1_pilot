# Stage 2 - Pilot to Institutional Beta

This zip includes Stage 2 scaffolding, not a claim of completed institutional rollout.

## Added in the app scaffold
- incident logging table and API
- webhook registry table and API
- admin settings table and API
- tenant-specific policies in the database model

## Still needed for a true institutional beta
- SSO with SAML or OIDC
- RBAC matrix by persona and tenant
- verified outbound webhook signing and delivery retries
- cloud monitoring and on-call routing
- customer-specific policy CRUD with approvals
- support SLAs and escalation playbooks
- completed privacy, terms, and security review

## Suggested next implementation order
1. Add SSO and role claims.
2. Replace single role string with true RBAC roles and permissions.
3. Add delivery worker for webhook retries.
4. Add incident workflow states and owner fields.
5. Add settings validation and admin-only write guards.
6. Connect monitoring to your hosting provider.
