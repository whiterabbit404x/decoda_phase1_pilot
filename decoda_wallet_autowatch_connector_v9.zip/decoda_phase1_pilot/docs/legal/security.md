# Security Overview Starter

Suggested sections for a customer-facing security page:
- hosting architecture summary
- authentication model
- audit logging summary
- report export controls
- vulnerability disclosure contact
- incident response summary
