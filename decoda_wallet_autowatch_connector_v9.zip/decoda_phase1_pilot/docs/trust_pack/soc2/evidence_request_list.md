# SOC 2 Evidence Request List

Use this as the internal checklist before a readiness assessment.

- org chart and control owners
- architecture diagram and system description
- access control policy
- user access review evidence
- release/change evidence
- incident response procedure and test evidence
- backup/restore evidence
- vulnerability management tickets and remediation evidence
- dependency/SBOM artifacts
- monitoring and alert evidence
- vendor management list if applicable
