from __future__ import annotations

import re
import sqlite3
from pathlib import Path
from typing import Any, Iterable, Optional
from urllib.parse import urlparse

from app.config import settings

try:
    import psycopg
    from psycopg.rows import dict_row
except Exception:  # pragma: no cover - optional dependency for production
    psycopg = None
    dict_row = None


class CursorWrapper:
    def __init__(self, backend: str, cursor: Any, lastrowid: Optional[int] = None):
        self.backend = backend
        self.cursor = cursor
        self.lastrowid = lastrowid or getattr(cursor, 'lastrowid', None)

    def _normalize_row(self, row: Any) -> Any:
        if row is None:
            return None
        if isinstance(row, dict):
            return row
        try:
            return dict(row)
        except Exception:
            return row

    def fetchone(self) -> Any:
        return self._normalize_row(self.cursor.fetchone())

    def fetchall(self) -> list[Any]:
        return [self._normalize_row(item) for item in self.cursor.fetchall()]


class ConnectionWrapper:
    def __init__(self, backend: str, conn: Any):
        self.backend = backend
        self.conn = conn

    def _adapt_sql(self, sql: str) -> str:
        if self.backend == 'postgres':
            return re.sub(r'\?', '%s', sql)
        return sql

    def execute(self, sql: str, params: Iterable[Any] | None = None) -> CursorWrapper:
        params = tuple(params or ())
        cur = self.conn.cursor()
        cur.execute(self._adapt_sql(sql), params)
        lastrowid = getattr(cur, 'lastrowid', None)
        if self.backend == 'postgres' and sql.lstrip().upper().startswith('INSERT'):
            id_cur = self.conn.cursor(row_factory=dict_row) if dict_row else self.conn.cursor()
            id_cur.execute('SELECT LASTVAL() AS id')
            row = id_cur.fetchone()
            if isinstance(row, dict):
                lastrowid = row['id']
            else:
                lastrowid = row[0]
            id_cur.close()
        return CursorWrapper(self.backend, cur, lastrowid=lastrowid)

    def executemany(self, sql: str, params_seq: Iterable[Iterable[Any]]) -> None:
        cur = self.conn.cursor()
        cur.executemany(self._adapt_sql(sql), list(params_seq))
        cur.close()

    def commit(self) -> None:
        self.conn.commit()

    def rollback(self) -> None:
        self.conn.rollback()

    def close(self) -> None:
        self.conn.close()

    def __enter__(self) -> 'ConnectionWrapper':
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if exc_type:
            self.rollback()
        else:
            self.commit()
        self.close()


def database_backend(database_url: str | None = None) -> str:
    url = database_url or settings.database_url
    if url.startswith('sqlite:///'):
        return 'sqlite'
    if url.startswith('postgres://') or url.startswith('postgresql://'):
        return 'postgres'
    raise RuntimeError(f'Unsupported DATABASE_URL scheme: {url}')


def db() -> ConnectionWrapper:
    url = settings.database_url
    backend = database_backend(url)
    if backend == 'sqlite':
        raw_path = url.removeprefix('sqlite:///')
        path = Path(raw_path)
        if path.parent:
            path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return ConnectionWrapper('sqlite', conn)

    if psycopg is None:
        raise RuntimeError('psycopg is required for PostgreSQL DATABASE_URL values')
    parsed = urlparse(url)
    connect_kwargs = {
        'dbname': parsed.path.lstrip('/'),
        'user': parsed.username,
        'password': parsed.password,
        'host': parsed.hostname,
        'port': parsed.port or 5432,
        'row_factory': dict_row,
    }
    conn = psycopg.connect(**connect_kwargs)
    return ConnectionWrapper('postgres', conn)
