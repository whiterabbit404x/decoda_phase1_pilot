# Deployment guide

## Local production-style run
1. Copy `.env.example` to `.env`.
2. Set `APP_ENV=production`.
3. Set `DATABASE_URL` to PostgreSQL.
4. Set `SESSION_COOKIE_SECURE=true`.
5. Set `PUBLIC_BASE_URL` to the public HTTPS URL.
6. Run `docker compose -f docker-compose.production.yml up --build`.

## Required preflight checks
- TLS terminated at the reverse proxy or load balancer.
- PostgreSQL backups scheduled and restore-tested.
- One app deployment and one worker deployment can both reach the database.
- `/healthz` and `/ready` checks wired into orchestration.
- OIDC mock mode disabled in production.
- Default demo credentials rotated or removed.
