from __future__ import annotations

import argparse
import time

from app.config import settings
from app.jobs import claim_next_job, complete_job, retry_job
from app.main import process_background_job, startup_bootstrap, utc_now


def run_worker(once: bool = False, worker_name: str = 'decoda-worker') -> int:
    startup_bootstrap()
    processed = 0
    while True:
        now_value = utc_now()
        job = claim_next_job(worker_name=worker_name, now_value=now_value)
        if not job:
            if once:
                return processed
            time.sleep(settings.worker_poll_seconds)
            continue
        try:
            result = process_background_job(job)
            complete_job(int(job['id']), utc_now(), result)
            processed += 1
        except Exception as exc:  # pragma: no cover - worker failure path
            retry_job(job, utc_now(), str(exc))
        if once:
            return processed


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Decoda background worker')
    parser.add_argument('--once', action='store_true', help='Process at most one available job and exit')
    parser.add_argument('--worker-name', default='decoda-worker')
    args = parser.parse_args()
    raise SystemExit(run_worker(once=args.once, worker_name=args.worker_name))
