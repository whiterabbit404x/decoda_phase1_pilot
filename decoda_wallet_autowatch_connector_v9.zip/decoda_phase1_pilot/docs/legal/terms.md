# Terms Starter

This starter document is not legal advice.

- define pilot-use scope
- define no-warranty language for demo environments
- define confidentiality and acceptable use
- define export and retention behavior
