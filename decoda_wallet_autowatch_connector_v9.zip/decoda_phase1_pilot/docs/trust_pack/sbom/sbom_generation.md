# SBOM Generation Guide

## Recommended approach

Generate a CycloneDX JSON SBOM in CI and attach it to release artifacts.

## Example commands

### Using CycloneDX for Python

```bash
pip install cyclonedx-bom
cyclonedx-py requirements -i requirements.txt -o sbom.cdx.json
```

### Optional vulnerability audit

```bash
pip install pip-audit
pip-audit -r requirements.txt
```

## Repository workflow

See `.github/workflows/sbom.yml` for a reference GitHub Actions workflow.
