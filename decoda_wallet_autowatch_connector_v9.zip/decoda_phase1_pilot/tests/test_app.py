import io
import os
import sys
import tempfile
import zipfile
from pathlib import Path

TEST_DB = Path(tempfile.gettempdir()) / 'decoda_enterprise_plus_test.db'
if TEST_DB.exists():
    TEST_DB.unlink()
os.environ['DATABASE_URL'] = f'sqlite:///{TEST_DB.as_posix()}'
os.environ['SESSION_COOKIE_SECURE'] = 'false'
os.environ['PUBLIC_BASE_URL'] = 'http://testserver'

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fastapi.testclient import TestClient
from app.main import app, SESSION_COOKIE, startup_bootstrap
from app.worker import run_worker

startup_bootstrap()
client = TestClient(app)


def login_cookie(email='admin@decoda.local', password='Decoda123!') -> str:
    response = client.post('/api/auth/login', headers={'User-Agent': 'pytest-agent/1.0'}, json={'email': email, 'password': password})
    assert response.status_code == 200
    cookie = response.cookies.get(SESSION_COOKIE)
    assert cookie
    return cookie


def auth_headers(cookie: str):
    return {'Cookie': f'{SESSION_COOKIE}={cookie}', 'User-Agent': 'pytest-agent/1.0'}


def test_health():
    response = client.get('/healthz')
    assert response.status_code == 200
    assert response.json()['status'] == 'ok'


def test_oidc_mock_login_flow():
    started = client.post('/api/auth/oidc/start', json={'next_path': '/dashboard', 'login_hint': 'oidc.user@decoda.local'})
    assert started.status_code == 200
    callback = client.get(started.json()['authorization_url'], follow_redirects=True)
    assert callback.status_code == 200
    data = callback.json()
    assert data['ok'] is True
    assert data['redirect'] == '/dashboard'


def test_login_and_dashboard():
    cookie = login_cookie()
    response = client.get('/dashboard', headers=auth_headers(cookie))
    assert response.status_code == 200
    assert 'Institutional beta' in response.text
    assert 'TreasuryToken 2026-A' in response.text


def test_rbac_and_tenant_users():
    cookie = login_cookie()
    verified = client.post('/api/auth/admin/verify', headers={**auth_headers(cookie), 'Content-Type': 'application/json'}, json={'tenant_id': 1, 'password': 'Decoda123!'})
    assert verified.status_code == 200
    matrix = client.get('/api/v1/rbac/matrix?tenant_id=1', headers=auth_headers(cookie))
    assert matrix.status_code == 200
    assert 'tenant_admin' in matrix.json()['roles']
    created = client.post('/api/v1/tenant-users', headers={**auth_headers(cookie), 'Content-Type': 'application/json'}, json={'tenant_id': 1, 'email': 'new.reviewer@decoda.local', 'full_name': 'New Reviewer', 'role_name': 'reviewer'})
    assert created.status_code == 200
    listed = client.get('/api/v1/tenant-users?tenant_id=1', headers=auth_headers(cookie))
    assert listed.status_code == 200
    assert any(item['email'] == 'new.reviewer@decoda.local' for item in listed.json())


def test_simulation_run_creates_blocked_result():
    cookie = login_cookie()
    response = client.post(
        '/api/v1/simulations/run',
        headers={**auth_headers(cookie), 'Content-Type': 'application/json'},
        json={
            'tenant_id': 1,
            'asset_name': 'TreasuryToken 2026-A',
            'environment': 'production',
            'action': 'upgrade_proxy_implementation',
            'contract_name': 'TreasuryTokenProxy',
            'requested_by': '0xBEEF00000000000000000000000000000000BEEF',
            'new_implementation': '0x9999999999999999999999999999999999999999',
            'change_window': 'closed',
            'dual_approval': False,
            'implementation_preapproved': False,
            'allowlisted_signer': False,
            'touches_mint_redeem_logic': True,
            'notes': 'test run',
        }
    )
    assert response.status_code == 200
    data = response.json()
    assert data['status'] == 'blocked'
    assert data['risk_score'] >= 80
    assert data['report_id'] >= 1


def test_approval_flow_and_job_queue():
    requester_cookie = login_cookie('analyst@decoda.local', 'Decoda123!')
    create = client.post('/api/v1/approvals', headers={**auth_headers(requester_cookie), 'Content-Type': 'application/json'}, json={
        'tenant_id': 1,
        'title': 'Approve safe upgrade',
        'target_type': 'simulation',
        'target_payload': {
            'simulation': {
                'tenant_id': 1,
                'asset_name': 'TreasuryToken 2026-B',
                'environment': 'production',
                'action': 'upgrade_proxy_implementation',
                'contract_name': 'TreasuryTokenProxy',
                'requested_by': '0xCAFE00000000000000000000000000000000CAFE',
                'new_implementation': '0x8888888888888888888888888888888888888888',
                'change_window': 'open',
                'dual_approval': True,
                'implementation_preapproved': True,
                'allowlisted_signer': True,
                'touches_mint_redeem_logic': False,
                'notes': 'approval test'
            }
        },
        'required_approvals': 1
    })
    assert create.status_code == 200
    approval_id = create.json()['approval_id']
    reviewer_cookie = login_cookie('reviewer@decoda.local', 'Decoda123!')
    decision = client.post(f'/api/v1/approvals/{approval_id}/decision', headers={**auth_headers(reviewer_cookie), 'Content-Type': 'application/json'}, json={'decision': 'approve', 'notes': 'Looks good'})
    assert decision.status_code == 200
    assert decision.json()['status'] == 'approved'
    assert decision.json()['job_id'] >= 1
    assert run_worker(once=True, worker_name='pytest-worker') >= 1


def test_webhook_retry_monitoring_and_export_bundle():
    cookie = login_cookie()
    verified = client.post('/api/auth/admin/verify', headers={**auth_headers(cookie), 'Content-Type': 'application/json'}, json={'tenant_id': 1, 'password': 'Decoda123!'})
    assert verified.status_code == 200
    webhook = client.post('/api/v1/webhooks', headers={**auth_headers(cookie), 'Content-Type': 'application/json'}, json={'tenant_id': 1, 'name': 'Failing Sink', 'url': 'mock://fail', 'event_type': 'simulation.blocked'})
    assert webhook.status_code == 200
    webhook_id = webhook.json()['webhook_id']
    queued = client.post(f'/api/v1/webhooks/{webhook_id}/test', headers=auth_headers(cookie))
    assert queued.status_code == 200
    run_worker(once=True, worker_name='pytest-worker')
    deliveries = client.get(f'/api/v1/webhooks/{webhook_id}/deliveries', headers=auth_headers(cookie))
    assert deliveries.status_code == 200
    assert deliveries.json()[0]['attempt_count'] >= 1
    summary = client.get('/api/v1/monitoring/summary?tenant_id=1', headers=auth_headers(cookie))
    assert summary.status_code == 200
    assert summary.json()['failed_webhook_deliveries'] >= 1
    alerts = client.get('/api/v1/alerts?tenant_id=1', headers=auth_headers(cookie))
    assert alerts.status_code == 200
    assert len(alerts.json()) >= 1
    metrics = client.get('/metrics')
    assert metrics.status_code == 200
    assert 'decoda_jobs_total' in metrics.text
    exported = client.get('/api/v1/export/package?tenant_id=1', headers=auth_headers(cookie))
    assert exported.status_code == 200
    zf = zipfile.ZipFile(io.BytesIO(exported.content))
    names = set(zf.namelist())
    assert 'summary.json' in names
    assert 'reports.csv' in names


def test_oidc_live_provider_flow(monkeypatch):
    class DummyResponse:
        def __init__(self, payload):
            self._payload = payload
            self.status_code = 200

        def raise_for_status(self):
            return None

        def json(self):
            return self._payload

    class DummyClient:
        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def post(self, url, data=None, headers=None):
            assert 'grant_type' in data
            return DummyResponse({'access_token': 'token-123'})

        def get(self, url, headers=None):
            assert headers['Authorization'] == 'Bearer token-123'
            return DummyResponse({'email': 'live.user@decoda.local', 'name': 'Live User'})

    from app.main import db
    import app.main as main_mod

    monkeypatch.setattr(main_mod.httpx, 'Client', DummyClient)
    with db() as conn:
        provider = conn.execute('SELECT * FROM oidc_providers WHERE slug = ?', ('live-sso',)).fetchone()
        if provider:
            conn.execute('DELETE FROM oidc_providers WHERE slug = ?', ('live-sso',))
        conn.execute(
            'INSERT INTO oidc_providers (slug, name, issuer, authorization_endpoint, token_endpoint, userinfo_endpoint, client_id, client_secret, scopes, mode, is_active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            ('live-sso', 'Live SSO', 'https://issuer.example', 'https://issuer.example/auth', 'https://issuer.example/token', 'https://issuer.example/userinfo', 'client-123', 'secret-456', 'openid profile email', 'live', 1, '2026-03-12 00:00:00 UTC', '2026-03-12 00:00:00 UTC')
        )
    started = client.post('/api/auth/oidc/start', json={'provider_slug': 'live-sso', 'next_path': '/dashboard', 'login_hint': 'live.user@decoda.local'})
    assert started.status_code == 200
    assert 'response_type=code' in started.json()['authorization_url']
    import urllib.parse as up
    parsed = up.urlparse(started.json()['authorization_url'])
    query = up.parse_qs(parsed.query)
    state = query['state'][0]
    callback = client.get(f'/api/auth/oidc/callback?state={state}&code=real-auth-code')
    assert callback.status_code == 200
    assert callback.json()['ok'] is True
    assert callback.json()['mode'] == 'live'


def test_platform_feature_pages_and_apis():
    cookie = login_cookie()
    for path in ['/threat-defense?tenant_id=1', '/oracle-integrity?tenant_id=1', '/governance?tenant_id=1', '/resilience?tenant_id=1']:
        response = client.get(path, headers=auth_headers(cookie))
        assert response.status_code == 200
    market = client.get('/api/v1/threat-defense/market-events?tenant_id=1', headers=auth_headers(cookie))
    assert market.status_code == 200
    assert len(market.json()) >= 1
    oracle = client.get('/api/v1/oracle-integrity/snapshots?tenant_id=1', headers=auth_headers(cookie))
    assert oracle.status_code == 200
    assert len(oracle.json()) >= 1


def test_extended_platform_signals_are_returned_in_simulation():
    cookie = login_cookie()
    response = client.post(
        '/api/v1/simulations/run',
        headers={**auth_headers(cookie), 'Content-Type': 'application/json'},
        json={
            'tenant_id': 1,
            'asset_name': 'TreasuryToken 2026-C',
            'environment': 'production',
            'action': 'reconcile_cross_chain_supply',
            'contract_name': 'TreasuryTokenBridge',
            'requested_by': '0xDEAD00000000000000000000000000000000DEAD',
            'change_window': 'open',
            'dual_approval': True,
            'implementation_preapproved': True,
            'allowlisted_signer': True,
            'touches_mint_redeem_logic': False,
            'ai_zero_day_score': 82,
            'flash_loan_exposure': True,
            'liquidity_drain_path_detected': False,
            'market_anomaly_score': 67,
            'suspected_spoofing': True,
            'suspected_wash_trading': False,
            'oracle_source_count': 3,
            'oracle_healthy_sources': 1,
            'oracle_max_drift_bps': 19,
            'collateral_ratio_pct': 97,
            'spv_attested': False,
            'provenance_complete': False,
            'kyc_wrapper_enabled': True,
            'travel_rule_enabled': True,
            'sanctioned_wallet_hit': False,
            'domestic_processing_only': True,
            'friendly_cloud_region': 'us-east',
            'transfer_restriction_enabled': True,
            'chain_count': 4,
            'reconciliation_delta_tokens': 150,
            'circuit_breaker_armed': False,
            'liquidity_backstop_ready': False,
            'settlement_finality_ok': False,
            'notes': 'extended signal test',
        }
    )
    assert response.status_code == 200
    data = response.json()
    assert data['status'] == 'blocked'
    assert 'threat_defense' in data['control_layers']
    assert len(data['headline_findings']) >= 1



def test_auto_watch_monitoring_profile_flow():
    cookie = login_cookie()
    overview = client.get('/monitoring?tenant_id=1', headers=auth_headers(cookie))
    assert overview.status_code == 200
    assert 'Auto Watch' in overview.text
    profiles = client.get('/api/v1/monitoring/profiles?tenant_id=1', headers=auth_headers(cookie))
    assert profiles.status_code == 200
    assert len(profiles.json()) >= 1
    profile_id = profiles.json()[0]['id']
    detail = client.get(f'/monitoring/profiles/{profile_id}?tenant_id=1', headers=auth_headers(cookie))
    assert detail.status_code == 200
    run_now = client.post(f'/api/v1/monitoring/profiles/{profile_id}/run-now?tenant_id=1', headers=auth_headers(cookie))
    assert run_now.status_code == 200
    run_data = run_now.json()
    assert run_data['monitoring_run_id'] >= 1
    runs = client.get(f'/api/v1/monitoring/runs?tenant_id=1&profile_id={profile_id}', headers=auth_headers(cookie))
    assert runs.status_code == 200
    assert len(runs.json()) >= 1
    summary = client.get('/api/v1/monitoring/summary?tenant_id=1', headers=auth_headers(cookie))
    assert summary.status_code == 200
    assert summary.json()['watch_profiles'] >= 1


def test_monitoring_dashboards_are_separated():
    cookie = login_cookie()
    for path, marker in [
        ('/monitoring?tenant_id=1', 'Monitoring Overview'),
        ('/monitoring/watch?tenant_id=1', 'Auto Watch'),
        ('/monitoring/review?tenant_id=1', 'Auto Review'),
        ('/monitoring/enforce?tenant_id=1', 'Auto Enforce'),
    ]:
        response = client.get(path, headers=auth_headers(cookie))
        assert response.status_code == 200
        assert marker in response.text
    profiles = client.get('/api/v1/monitoring/profiles?tenant_id=1&mode=auto_watch', headers=auth_headers(cookie))
    assert profiles.status_code == 200
    assert all(item['mode'] == 'auto_watch' for item in profiles.json())

def test_wallet_snapshot_connector_impacts_auto_watch():
    cookie = login_cookie()
    profiles = client.get('/api/v1/monitoring/profiles?tenant_id=1&mode=auto_watch', headers=auth_headers(cookie))
    assert profiles.status_code == 200
    profile = profiles.json()[0]
    reserve_wallet = profile['reserve_wallets'][0]
    upsert = client.post(
        '/api/v1/monitoring/wallet-snapshots',
        headers={**auth_headers(cookie), 'Content-Type': 'application/json'},
        json={
            'tenant_id': 1,
            'wallet_address': reserve_wallet,
            'wallet_role': 'reserve',
            'chain_name': 'ethereum',
            'source_mode': 'manual',
            'tx_count_24h': 3,
            'incoming_tx_count_24h': 0,
            'outgoing_tx_count_24h': 2,
            'outgoing_native_amount_24h': 2.5,
            'last_seen_at': '2026-03-13 15:00:00 UTC',
            'burst_score': 30,
            'details': {'note': 'pytest reserve outflow'},
        },
    )
    assert upsert.status_code == 200
    run_now = client.post(f"/api/v1/monitoring/profiles/{profile['id']}/run-now?tenant_id=1", headers=auth_headers(cookie))
    assert run_now.status_code == 200
    data = run_now.json()
    assert data['wallet_activity']['signals']['reserve_outflow_detected'] is True
    assert any('Reserve wallet movement exceeded' in item for item in data['control_layers']['wallet_activity'])
    activity = client.get(f"/api/v1/monitoring/profiles/{profile['id']}/wallet-activity?tenant_id=1", headers=auth_headers(cookie))
    assert activity.status_code == 200
    assert len(activity.json()['wallet_snapshots']) >= 1
