from __future__ import annotations

import csv
import hashlib
import hmac
import io
import json
import secrets
import zipfile
from urllib.parse import urlencode
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

import httpx
from fastapi import Cookie, FastAPI, Header, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse, RedirectResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field, field_validator

from app.config import settings
from app.db import db
from app.jobs import enqueue_job, get_job
from app.migrations import run_migrations
from app.platform_features import (
    evaluate_platform_signals,
    list_compliance_controls,
    list_market_surveillance_events,
    list_oracle_integrity_snapshots,
    list_provenance_records,
    list_resilience_states,
    platform_feature_summary,
    seed_platform_feature_data,
)

APP_NAME = settings.app_name
VERSION = settings.version
BASE_DIR = settings.base_dir
SESSION_COOKIE = settings.session_cookie
PBKDF2_ROUNDS = settings.pbkdf2_rounds
DEMO_USER_EMAIL = settings.demo_user_email
DEMO_USER_PASSWORD = settings.demo_user_password

app = FastAPI(title=APP_NAME, version=VERSION)
app.mount('/static', StaticFiles(directory=str(BASE_DIR / 'app' / 'static')), name='static')
templates = Jinja2Templates(directory=str(BASE_DIR / 'app' / 'templates'))


ROLE_PERMISSIONS = {
    'tenant_admin': {
        'dashboard.read',
        'policy.read', 'policy.manage',
        'simulation.read', 'simulation.run', 'simulation.queue',
        'report.read', 'audit.read',
        'incident.read', 'incident.create', 'incident.manage',
        'webhook.read', 'webhook.manage',
        'settings.read', 'settings.manage',
        'job.read',
    },
    'analyst': {
        'dashboard.read', 'policy.read', 'simulation.read', 'simulation.run', 'simulation.queue',
        'report.read', 'audit.read', 'incident.read', 'job.read',
    },
    'reviewer': {
        'dashboard.read', 'policy.read', 'simulation.read', 'report.read', 'audit.read', 'incident.read', 'job.read',
    },
}


SETTINGS_CATALOG = {
    'auto_incident_min_risk': {'type': 'int', 'min': 0, 'max': 100, 'default': 80},
    'webhook_timeout_seconds': {'type': 'int', 'min': 1, 'max': 30, 'default': settings.webhook_timeout_seconds},
    'require_dual_approval_production': {'type': 'bool', 'default': True},
    'export_retention_days': {'type': 'int', 'min': 7, 'max': 3650, 'default': 365},
}

MONITORING_MODES = {'off', 'auto_watch', 'auto_review', 'auto_enforce'}
DEFAULT_MONITORING_THRESHOLDS = {
    'ai_zero_day_warning': 70,
    'ai_zero_day_critical': 85,
    'oracle_drift_warning_bps': 10,
    'oracle_drift_critical_bps': 15,
    'market_anomaly_warning': 65,
    'reconciliation_warning_tokens': 1,
    'reconciliation_critical_tokens': 100,
    'collateral_ratio_min_pct': 100,
}
DEFAULT_MONITORING_SIGNAL_OVERRIDES = {
    'change_window': 'open',
    'dual_approval': True,
    'implementation_preapproved': True,
    'allowlisted_signer': True,
    'touches_mint_redeem_logic': False,
    'ai_zero_day_score': 18,
    'flash_loan_exposure': False,
    'liquidity_drain_path_detected': False,
    'market_anomaly_score': 12,
    'suspected_spoofing': False,
    'suspected_wash_trading': False,
    'oracle_max_drift_bps': 3,
    'collateral_ratio_pct': 100,
    'spv_attested': True,
    'provenance_complete': True,
    'kyc_wrapper_enabled': True,
    'travel_rule_enabled': True,
    'sanctioned_wallet_hit': False,
    'domestic_processing_only': True,
    'friendly_cloud_region': 'us-east',
    'transfer_restriction_enabled': True,
    'reconciliation_delta_tokens': 0,
    'circuit_breaker_armed': True,
    'liquidity_backstop_ready': True,
    'settlement_finality_ok': True,
    'wallet_activity_sources': {},
    'wallet_admin_burst_warning_txs': 6,
    'wallet_admin_burst_critical_txs': 12,
    'wallet_reserve_outflow_warning_native': 0.5,
    'wallet_reserve_outflow_critical_native': 2.0,
    'wallet_stale_minutes': 1440,
}

ROLE_PERMISSIONS['tenant_admin'].update({'tenant_user.read', 'tenant_user.manage', 'approval.read', 'approval.request', 'approval.approve', 'monitoring.read', 'monitoring.manage', 'export.package', 'rbac.read', 'oidc.manage'})
ROLE_PERMISSIONS['analyst'].update({'approval.read', 'approval.request', 'monitoring.read', 'export.package'})
ROLE_PERMISSIONS['reviewer'].update({'approval.read', 'approval.approve', 'monitoring.read', 'export.package'})
ROLE_PERMISSIONS['governance_reviewer'] = {
    'dashboard.read', 'policy.read', 'simulation.read', 'report.read', 'audit.read', 'incident.read', 'approval.read', 'approval.approve', 'monitoring.read', 'export.package', 'job.read'
}


class LoginRequest(BaseModel):
    email: str
    password: str


class PolicyToggleRequest(BaseModel):
    enabled: bool


class SimulationRequest(BaseModel):
    tenant_id: int
    asset_name: str
    environment: str = 'production'
    action: str
    contract_name: str
    requested_by: str
    new_implementation: Optional[str] = None
    change_window: str = 'closed'
    dual_approval: bool = False
    implementation_preapproved: bool = False
    allowlisted_signer: bool = False
    touches_mint_redeem_logic: bool = True
    ai_zero_day_score: int = Field(default=15, ge=0, le=100)
    flash_loan_exposure: bool = False
    liquidity_drain_path_detected: bool = False
    market_anomaly_score: int = Field(default=8, ge=0, le=100)
    suspected_spoofing: bool = False
    suspected_wash_trading: bool = False
    oracle_source_count: int = Field(default=3, ge=1, le=10)
    oracle_healthy_sources: int = Field(default=3, ge=0, le=10)
    oracle_max_drift_bps: int = Field(default=2, ge=0, le=500)
    collateral_ratio_pct: int = Field(default=100, ge=0, le=1000)
    spv_attested: bool = True
    provenance_complete: bool = True
    kyc_wrapper_enabled: bool = True
    travel_rule_enabled: bool = True
    sanctioned_wallet_hit: bool = False
    domestic_processing_only: bool = True
    friendly_cloud_region: str = 'us-east'
    transfer_restriction_enabled: bool = True
    chain_count: int = Field(default=2, ge=1, le=20)
    reconciliation_delta_tokens: int = Field(default=0, ge=0)
    circuit_breaker_armed: bool = True
    liquidity_backstop_ready: bool = True
    settlement_finality_ok: bool = True
    notes: Optional[str] = ''


class IncidentCreateRequest(BaseModel):
    tenant_id: int
    title: str
    severity: str
    status: str = 'open'
    summary: str
    source: str = 'manual'
    assignee: Optional[str] = None
    external_ticket: Optional[str] = None


class IncidentUpdateRequest(BaseModel):
    status: Optional[str] = None
    summary: Optional[str] = None
    assignee: Optional[str] = None
    external_ticket: Optional[str] = None
    resolution_notes: Optional[str] = None


class WebhookCreateRequest(BaseModel):
    tenant_id: int
    name: str
    url: str
    event_type: str = 'simulation.blocked'


class WebhookUpdateRequest(BaseModel):
    is_active: bool


class AdminSettingUpdateRequest(BaseModel):
    tenant_id: int
    setting_key: str
    setting_value: str


class AdminVerifyRequest(BaseModel):
    tenant_id: int
    password: str


class OIDCStartRequest(BaseModel):
    provider_slug: Optional[str] = None
    next_path: str = '/dashboard'
    login_hint: Optional[str] = None


class TenantUserCreateRequest(BaseModel):
    tenant_id: int
    email: str
    full_name: str
    role_name: str = 'reviewer'
    temporary_password: Optional[str] = None


class TenantUserUpdateRequest(BaseModel):
    role_name: Optional[str] = None
    membership_active: Optional[bool] = None
    user_active: Optional[bool] = None


class ApprovalCreateRequest(BaseModel):
    tenant_id: int
    approval_type: str = 'simulation.execution'
    title: str
    target_type: str
    target_payload: Dict[str, Any]
    required_approvals: int = Field(default=2, ge=1, le=5)
    execute_on_approval: bool = True
    execute_job_type: Optional[str] = None
    execute_payload: Optional[Dict[str, Any]] = None


class ApprovalDecisionRequest(BaseModel):
    decision: str
    notes: Optional[str] = None

    @field_validator('decision')
    @classmethod
    def validate_decision(cls, value: str) -> str:
        value = value.strip().lower()
        if value not in {'approve', 'reject'}:
            raise ValueError('decision must be approve or reject')
        return value


class MonitoringAlertCreateRequest(BaseModel):
    tenant_id: int
    alert_key: str
    severity: str
    summary: str
    source: str = 'manual'
    details: Dict[str, Any] = Field(default_factory=dict)


class MonitoringProfileCreateRequest(BaseModel):
    tenant_id: int
    name: str
    description: str = ''
    environment: str = 'production'
    asset_type: str = 'Treasury token'
    mode: str = 'auto_watch'
    frequency_seconds: int = Field(default=300, ge=60, le=86400)
    contract_name: str = 'TreasuryTokenProxy'
    admin_wallets: List[str] = Field(default_factory=list)
    reserve_wallets: List[str] = Field(default_factory=list)
    oracle_endpoints: List[str] = Field(default_factory=list)
    chain_list: List[str] = Field(default_factory=lambda: ['ethereum', 'avalanche'])
    notification_emails: List[str] = Field(default_factory=list)
    webhook_url: Optional[str] = None
    thresholds: Dict[str, Any] = Field(default_factory=dict)
    signal_overrides: Dict[str, Any] = Field(default_factory=dict)
    is_active: bool = True

    @field_validator('mode')
    @classmethod
    def validate_mode(cls, value: str) -> str:
        value = value.strip().lower()
        if value not in MONITORING_MODES:
            raise ValueError('Unsupported monitoring mode')
        return value


class MonitoringProfileStateRequest(BaseModel):
    is_active: bool


class WalletActivitySnapshotUpsertRequest(BaseModel):
    tenant_id: int
    wallet_address: str
    wallet_role: str = 'reserve'
    chain_name: str = 'base'
    source_mode: str = 'manual'
    tx_count_24h: int = Field(default=0, ge=0)
    incoming_tx_count_24h: int = Field(default=0, ge=0)
    outgoing_tx_count_24h: int = Field(default=0, ge=0)
    outgoing_native_amount_24h: float = Field(default=0.0, ge=0.0)
    last_seen_at: Optional[str] = None
    burst_score: int = Field(default=0, ge=0, le=100)
    details: Dict[str, Any] = Field(default_factory=dict)

    @field_validator('wallet_role')
    @classmethod
    def validate_wallet_role(cls, value: str) -> str:
        value = value.strip().lower()
        if value not in {'admin', 'reserve'}:
            raise ValueError('wallet_role must be admin or reserve')
        return value



def utc_dt() -> datetime:
    return datetime.now(timezone.utc)



def utc_now() -> str:
    return utc_dt().strftime('%Y-%m-%d %H:%M:%S UTC')



def parse_utc(value: str | None) -> datetime | None:
    if not value:
        return None
    return datetime.strptime(value, '%Y-%m-%d %H:%M:%S UTC').replace(tzinfo=timezone.utc)



def hash_password(password: str, salt: str) -> str:
    digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), PBKDF2_ROUNDS)
    return digest.hex()



def verify_password(password: str, salt: str, password_hash: str) -> bool:
    candidate = hash_password(password, salt)
    return hmac.compare_digest(candidate, password_hash)



def sha256_text(value: str | None) -> str | None:
    if not value:
        return None
    return hashlib.sha256(value.encode('utf-8')).hexdigest()



def request_ip(request: Request) -> str:
    forwarded = request.headers.get('x-forwarded-for')
    if forwarded:
        return forwarded.split(',')[0].strip()
    return request.client.host if request.client else 'unknown'



def request_user_agent(request: Request) -> str:
    return request.headers.get('user-agent', 'unknown')



def startup_bootstrap() -> None:
    run_migrations(utc_now())
    seed_demo_data()
    seed_enterprise_data()
    seed_platform_feature_data(utc_now())
    seed_auto_watch_data()


@app.on_event('startup')
def startup() -> None:
    startup_bootstrap()



def audit_event(tenant_id: Optional[int], user_id: Optional[int], event_type: str, target_type: str, target_id: Optional[str], summary: str, details: Dict[str, Any]) -> None:
    with db() as conn:
        conn.execute(
            '''
            INSERT INTO audit_events (tenant_id, user_id, event_type, target_type, target_id, summary, details_json, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''',
            (tenant_id, user_id, event_type, target_type, target_id, summary, json.dumps(details), utc_now()),
        )



def seed_demo_data() -> None:
    with db() as conn:
        user_row = conn.execute('SELECT * FROM users WHERE email = ?', (DEMO_USER_EMAIL,)).fetchone()
        if not user_row:
            salt = secrets.token_hex(16)
            user_id = int(conn.execute(
                'INSERT INTO users (email, full_name, password_salt, password_hash, created_at) VALUES (?, ?, ?, ?, ?)',
                (DEMO_USER_EMAIL, 'Anthony Pham Demo Admin', salt, hash_password(DEMO_USER_PASSWORD, salt), utc_now()),
            ).lastrowid)
        else:
            user_id = int(user_row['id'])

        tenants = conn.execute('SELECT * FROM tenants ORDER BY id').fetchall()
        if not tenants:
            seed_tenants = [
                ('Atlas Treasury Labs', 'atlas-treasury-labs', 'production', utc_now()),
                ('Harbor RWA Markets', 'harbor-rwa-markets', 'production', utc_now()),
                ('Federal Pilot Desk', 'federal-pilot-desk', 'staging', utc_now()),
            ]
            for item in seed_tenants:
                conn.execute('INSERT INTO tenants (name, slug, environment, created_at) VALUES (?, ?, ?, ?)', item)
            tenants = conn.execute('SELECT * FROM tenants ORDER BY id').fetchall()

        for tenant in tenants:
            existing = conn.execute(
                'SELECT 1 FROM user_tenants WHERE user_id = ? AND tenant_id = ?',
                (user_id, tenant['id']),
            ).fetchone()
            if not existing:
                conn.execute(
                    'INSERT INTO user_tenants (user_id, tenant_id, role_name) VALUES (?, ?, ?)',
                    (user_id, tenant['id'], 'tenant_admin'),
                )

        for tenant in tenants:
            policies = [
                (
                    tenant['id'], 'UPG-001', 'Approved signer required for privileged upgrades',
                    'Blocks proxy or implementation upgrades when the requesting signer is not on the tenant allowlist.',
                    json.dumps({'check': 'allowlisted_signer', 'expected': True, 'mode': 'block'}), 1, utc_now(), utc_now(),
                ),
                (
                    tenant['id'], 'UPG-002', 'Maintenance window must be open',
                    'Requires production changes to occur in the open maintenance window.',
                    json.dumps({'check': 'change_window', 'expected': 'open', 'mode': 'block'}), 1, utc_now(), utc_now(),
                ),
                (
                    tenant['id'], 'UPG-003', 'Implementation must be pre-approved',
                    'Requires the new implementation to be reviewed before production execution.',
                    json.dumps({'check': 'implementation_preapproved', 'expected': True, 'mode': 'block'}), 1, utc_now(), utc_now(),
                ),
                (
                    tenant['id'], 'UPG-004', 'Dual approval required in production',
                    'Sensitive changes need documented dual approval before execution.',
                    json.dumps({'check': 'dual_approval', 'expected': True, 'mode': 'review'}), 1, utc_now(), utc_now(),
                ),
                (
                    tenant['id'], 'UPG-005', 'Mint/redeem path changes escalate risk',
                    'Changes touching mint and redeem logic require additional review.',
                    json.dumps({'check': 'touches_mint_redeem_logic', 'expected': False, 'mode': 'review'}), 1, utc_now(), utc_now(),
                ),
                (
                    tenant['id'], 'CMP-001', 'KYC wrapper must stay enabled',
                    'Security tokens require embedded transfer restrictions and KYC gating.',
                    json.dumps({'check': 'kyc_wrapper_enabled', 'expected': True, 'mode': 'block'}), 1, utc_now(), utc_now(),
                ),
                (
                    tenant['id'], 'CMP-002', 'Sanctions screening must pass',
                    'Blocks transfers that touch sanctioned or unauthorized wallets.',
                    json.dumps({'check': 'sanctioned_wallet_hit', 'expected': False, 'mode': 'block'}), 1, utc_now(), utc_now(),
                ),
                (
                    tenant['id'], 'ORC-001', 'Oracle drift must remain in tolerance',
                    'Treasury price truth depends on healthy institutional data quorum.',
                    json.dumps({'check': 'oracle_max_drift_bps', 'expected': 10, 'mode': 'review'}), 1, utc_now(), utc_now(),
                ),
                (
                    tenant['id'], 'RES-001', 'Circuit breaker must remain armed',
                    'Digital run prevention depends on an active circuit breaker.',
                    json.dumps({'check': 'circuit_breaker_armed', 'expected': True, 'mode': 'review'}), 1, utc_now(), utc_now(),
                ),
            ]
            for policy in policies:
                exists = conn.execute('SELECT 1 FROM policies WHERE tenant_id = ? AND policy_code = ?', (tenant['id'], policy[1])).fetchone()
                if not exists:
                    conn.execute(
                        '''
                        INSERT INTO policies (tenant_id, policy_code, name, description, rule_json, enabled, created_at, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        ''',
                        policy,
                    )

        if conn.execute('SELECT COUNT(*) AS count FROM admin_settings').fetchone()['count'] == 0:
            for tenant in tenants:
                for key, rule in SETTINGS_CATALOG.items():
                    value = str(rule['default']).lower() if rule['type'] == 'bool' else str(rule['default'])
                    conn.execute(
                        'INSERT INTO admin_settings (tenant_id, setting_key, setting_value, updated_at) VALUES (?, ?, ?, ?)',
                        (tenant['id'], key, value, utc_now()),
                    )

    # Seed one blocked run so the dashboard is populated.
    with db() as conn:
        has_runs = conn.execute('SELECT COUNT(*) AS count FROM simulation_runs').fetchone()['count']
        if has_runs == 0:
            payload = SimulationRequest(
                tenant_id=1,
                asset_name='TreasuryToken 2026-A',
                environment='production',
                action='upgrade_proxy_implementation',
                contract_name='TreasuryTokenProxy',
                requested_by='0xBEEF00000000000000000000000000000000BEEF',
                new_implementation='0x9999999999999999999999999999999999999999',
                change_window='closed',
                dual_approval=False,
                implementation_preapproved=False,
                allowlisted_signer=False,
                touches_mint_redeem_logic=True,
                notes='Seeded blocked scenario for institutional beta',
            )
            run_simulation_and_persist(user_id=1, payload=payload, emit_webhooks=False)



def severity_for(score: int) -> str:
    if score >= 90:
        return 'critical'
    if score >= 75:
        return 'high'
    if score >= 55:
        return 'medium'
    return 'low'



def status_for(score: int) -> str:
    if score >= 80:
        return 'blocked'
    if score >= 55:
        return 'review'
    return 'allowed'



def list_policies(tenant_id: int) -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute('SELECT * FROM policies WHERE tenant_id = ? ORDER BY policy_code', (tenant_id,)).fetchall()
    for row in rows:
        row['rule'] = json.loads(row['rule_json'])
    return rows



def get_user_tenants(user_id: int) -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute(
            '''
            SELECT t.*, ut.role_name
            FROM user_tenants ut
            JOIN tenants t ON t.id = ut.tenant_id
            WHERE ut.user_id = ?
            ORDER BY t.id
            ''',
            (user_id,),
        ).fetchall()
    return rows



def current_tenant_for(user_id: int, tenant_id: Optional[int]) -> Dict[str, Any]:
    tenants = get_user_tenants(user_id)
    if not tenants:
        raise HTTPException(status_code=403, detail='No tenant access assigned')
    if tenant_id is None:
        return tenants[0]
    for tenant in tenants:
        if int(tenant['id']) == int(tenant_id):
            return tenant
    raise HTTPException(status_code=403, detail='Tenant access denied')



def permission_for_tenant(user_id: int, tenant_id: int, permission: str) -> None:
    tenant = current_tenant_for(user_id, tenant_id)
    role_name = tenant.get('role_name', 'reviewer')
    if permission not in ROLE_PERMISSIONS.get(role_name, set()):
        raise HTTPException(status_code=403, detail='Permission denied')



def list_simulation_runs(tenant_id: int, limit: int = 20) -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute(
            'SELECT * FROM simulation_runs WHERE tenant_id = ? ORDER BY id DESC LIMIT ?',
            (tenant_id, limit),
        ).fetchall()
    for row in rows:
        row['payload'] = json.loads(row['payload_json'])
        row['explanations'] = json.loads(row['explanations_json'])
    return rows



def list_reports(tenant_id: int, limit: int = 20) -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute('SELECT * FROM reports WHERE tenant_id = ? ORDER BY id DESC LIMIT ?', (tenant_id, limit)).fetchall()
    for row in rows:
        row['content'] = json.loads(row['content_json'])
    return rows



def list_audit_events(tenant_id: int, limit: int = 50) -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute('SELECT * FROM audit_events WHERE tenant_id = ? ORDER BY id DESC LIMIT ?', (tenant_id, limit)).fetchall()
    for row in rows:
        row['details'] = json.loads(row['details_json'])
    return rows



def list_incidents(tenant_id: int) -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute('SELECT * FROM incidents WHERE tenant_id = ? ORDER BY id DESC', (tenant_id,)).fetchall()
    return rows



def list_webhooks(tenant_id: int) -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute('SELECT id, tenant_id, name, url, event_type, secret_preview, is_active, created_at, updated_at, last_delivery_at FROM webhooks WHERE tenant_id = ? ORDER BY id DESC', (tenant_id,)).fetchall()
    return rows



def list_webhook_deliveries(webhook_id: int, limit: int = 20) -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute('SELECT * FROM webhook_deliveries WHERE webhook_id = ? ORDER BY id DESC LIMIT ?', (webhook_id, limit)).fetchall()
    return rows



def list_admin_settings(tenant_id: int) -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute('SELECT * FROM admin_settings WHERE tenant_id = ? ORDER BY setting_key', (tenant_id,)).fetchall()
    return rows



def get_admin_setting_map(tenant_id: int) -> Dict[str, str]:
    return {row['setting_key']: row['setting_value'] for row in list_admin_settings(tenant_id)}



def dashboard_stats(tenant_id: int) -> Dict[str, Any]:
    runs = list_simulation_runs(tenant_id, limit=200)
    reports = list_reports(tenant_id, limit=200)
    audits = list_audit_events(tenant_id, limit=200)
    platform = platform_feature_summary(tenant_id)
    total_runs = len(runs)
    blocked = sum(1 for item in runs if item['status'] == 'blocked')
    review = sum(1 for item in runs if item['status'] == 'review')
    average_risk = round(sum(int(item['risk_score']) for item in runs) / total_runs, 1) if total_runs else 0
    return {
        'total_runs': total_runs,
        'blocked': blocked,
        'review': review,
        'average_risk': average_risk,
        'reports': len(reports),
        'audits': len(audits),
        'market_alerts': platform['market_alerts'],
        'avg_oracle_drift_bps': platform['avg_oracle_drift_bps'],
        'provenance_events': platform['provenance_events'],
        'resilience_chains': platform['resilience_chains'],
    }



def scenario_catalog() -> List[Dict[str, str]]:
    return [
        {'action': 'upgrade_proxy_implementation', 'label': 'Upgrade proxy implementation'},
        {'action': 'rotate_reserve_wallet', 'label': 'Rotate reserve wallet'},
        {'action': 'transfer_admin_role', 'label': 'Transfer admin role'},
        {'action': 'refresh_oracle_mesh', 'label': 'Refresh oracle validator mesh'},
        {'action': 'reconcile_cross_chain_supply', 'label': 'Reconcile cross-chain supply'},
        {'action': 'enable_regulatory_wrapper', 'label': 'Enable regulatory wrapper'},
    ]



def short_addr(value: str) -> str:
    if not value or len(value) < 12:
        return value
    return f"{value[:6]}...{value[-4:]}"



def summarize_dashboard_focus(latest_runs: List[Dict[str, Any]], policies: List[Dict[str, Any]]) -> Dict[str, Any]:
    focus_run = latest_runs[0] if latest_runs else None
    policy_checks = []
    control_layers = {}
    if focus_run:
        payload = focus_run['payload']
        policy_checks = [
            {'code': 'UPG-001', 'name': 'Allowlisted signer required', 'passed': bool(payload.get('allowlisted_signer')), 'detail': f"allowlisted_signer = {payload.get('allowlisted_signer')}"},
            {'code': 'UPG-002', 'name': 'Maintenance window must be open', 'passed': payload.get('change_window') == 'open', 'detail': f"change_window = {payload.get('change_window')}"},
            {'code': 'CMP-001', 'name': 'KYC wrapper enabled', 'passed': bool(payload.get('kyc_wrapper_enabled', True)), 'detail': f"kyc_wrapper_enabled = {payload.get('kyc_wrapper_enabled', True)}"},
            {'code': 'ORC-001', 'name': 'Oracle drift in tolerance', 'passed': int(payload.get('oracle_max_drift_bps', 0)) <= 10, 'detail': f"oracle_max_drift_bps = {payload.get('oracle_max_drift_bps', 0)}"},
            {'code': 'RES-001', 'name': 'Circuit breaker armed', 'passed': bool(payload.get('circuit_breaker_armed', True)), 'detail': f"circuit_breaker_armed = {payload.get('circuit_breaker_armed', True)}"},
        ]
        control_layers = evaluate_platform_signals(payload)['layer_summaries']
    remediation = [
        'Require an allowlisted signer and document reviewer identity.',
        'Restore oracle quorum and keep drift inside Treasury tolerances.',
        'Keep KYC wrappers, sanctions screening, and circuit breakers enabled in production.',
    ]
    business_impact = [
        'A bad privileged upgrade can affect mint and redeem controls.',
        'Oracle drift or missing collateral evidence can de-peg sovereign debt tokens from the underlying asset.',
        'Cross-chain reconciliation failures can create systemic liquidity and settlement risk.',
    ]
    return {
        'focus_run': focus_run,
        'action_title': 'Upgrade TreasuryTokenProxy implementation',
        'policy_checks': policy_checks,
        'remediation': remediation,
        'business_impact': business_impact,
        'control_layers': control_layers,
    }



def build_simulation_seed(latest_run: Optional[Dict[str, Any]], latest_report: Optional[Dict[str, Any]], latest_audit: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if latest_report and latest_report.get('content'):
        content = latest_report['content']
        return {
            'latest_run_id': latest_run['id'] if latest_run else None,
            'latest_report_id': latest_report['id'] if latest_report else None,
            'latest_audit_id': latest_audit['id'] if latest_audit else None,
            'payload': content.get('payload', {}),
            'status': content.get('decision', {}).get('status'),
            'risk_score': content.get('decision', {}).get('risk_score'),
            'summary': content.get('decision', {}).get('summary'),
            'asset_name': content.get('asset_name'),
            'environment': content.get('payload', {}).get('environment'),
            'action': content.get('payload', {}).get('action'),
            'contract_name': content.get('payload', {}).get('contract_name'),
            'control_layers': content.get('control_layers', {}),
            'headline_findings': content.get('headline_findings', []),
            'report_code': content.get('report_code'),
            'explanations': content.get('decision', {}).get('explanations', []),
        }
    return {
        'latest_run_id': latest_run['id'] if latest_run else None,
        'latest_report_id': latest_report['id'] if latest_report else None,
        'latest_audit_id': latest_audit['id'] if latest_audit else None,
    }



def record_login_attempt(email: str, ip_hash: str | None, succeeded: bool) -> None:
    with db() as conn:
        conn.execute(
            'INSERT INTO login_attempts (email, ip_hash, created_at, succeeded) VALUES (?, ?, ?, ?)',
            (email, ip_hash, utc_now(), 1 if succeeded else 0),
        )



def login_rate_limited(email: str, ip_hash: str | None) -> bool:
    cutoff = utc_dt() - timedelta(seconds=settings.login_rate_window_seconds)
    with db() as conn:
        rows = conn.execute('SELECT * FROM login_attempts WHERE email = ? ORDER BY id DESC LIMIT 25', (email,)).fetchall()
    failures = 0
    for row in rows:
        created_at = parse_utc(row['created_at'])
        if not created_at or created_at < cutoff:
            continue
        if ip_hash and row.get('ip_hash') and row['ip_hash'] != ip_hash:
            continue
        if int(row['succeeded']) == 0:
            failures += 1
    return failures >= settings.login_rate_max_attempts



def create_session(user_id: int, request: Request) -> str:
    token = secrets.token_urlsafe(48)
    now_value = utc_now()
    expires_at = (utc_dt() + timedelta(minutes=settings.session_absolute_minutes)).strftime('%Y-%m-%d %H:%M:%S UTC')
    with db() as conn:
        conn.execute(
            '''
            INSERT INTO sessions (user_id, token, user_agent_hash, ip_hash, created_at, last_seen_at, expires_at, is_active)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''',
            (user_id, token, sha256_text(request_user_agent(request)), sha256_text(request_ip(request)), now_value, now_value, expires_at, 1),
        )
    return token



def destroy_session(session_token: Optional[str]) -> None:
    if not session_token:
        return
    with db() as conn:
        conn.execute('UPDATE sessions SET is_active = 0 WHERE token = ?', (session_token,))



def get_session_user(session_token: Optional[str], request: Optional[Request] = None) -> Optional[Dict[str, Any]]:
    if not session_token:
        return None
    with db() as conn:
        row = conn.execute(
            '''
            SELECT
                u.id AS id,
                s.id AS session_id,
                s.user_id AS user_id,
                s.token,
                s.user_agent_hash,
                s.ip_hash,
                s.admin_verified_at,
                s.created_at,
                s.last_seen_at,
                s.expires_at,
                s.is_active,
                u.email,
                u.full_name,
                u.is_active AS user_active
            FROM sessions s
            JOIN users u ON u.id = s.user_id
            WHERE s.token = ? AND s.is_active = 1
            ''',
            (session_token,),
        ).fetchone()
        if not row:
            return None
        if int(row['user_active']) != 1:
            return None
        now_dt = utc_dt()
        expires_at = parse_utc(row['expires_at'])
        last_seen = parse_utc(row['last_seen_at'])
        if expires_at and now_dt > expires_at:
            conn.execute('UPDATE sessions SET is_active = 0 WHERE token = ?', (session_token,))
            return None
        if last_seen and now_dt - last_seen > timedelta(minutes=settings.session_idle_minutes):
            conn.execute('UPDATE sessions SET is_active = 0 WHERE token = ?', (session_token,))
            return None
        if request:
            expected_ua = row.get('user_agent_hash')
            if expected_ua and expected_ua != sha256_text(request_user_agent(request)):
                conn.execute('UPDATE sessions SET is_active = 0 WHERE token = ?', (session_token,))
                return None
        conn.execute('UPDATE sessions SET last_seen_at = ? WHERE token = ?', (utc_now(), session_token))
    return row



def require_user(request: Request) -> Dict[str, Any]:
    user = get_session_user(request.cookies.get(SESSION_COOKIE), request=request)
    if not user:
        raise HTTPException(status_code=401, detail='Authentication required')
    return user



def ensure_admin_reauth(user: Dict[str, Any], request: Request, tenant_id: int, admin_reauth: str | None = None) -> None:
    permission_for_tenant(int(user['user_id'] if 'user_id' in user else user['id']), tenant_id, 'settings.manage')
    session_token = request.cookies.get(SESSION_COOKIE)
    if not session_token:
        raise HTTPException(status_code=401, detail='Authentication required')
    with db() as conn:
        session_row = conn.execute('SELECT * FROM sessions WHERE token = ? AND is_active = 1', (session_token,)).fetchone()
        if not session_row:
            raise HTTPException(status_code=401, detail='Authentication required')
        verified_at = parse_utc(session_row.get('admin_verified_at'))
        if verified_at and utc_dt() - verified_at <= timedelta(minutes=settings.admin_reauth_minutes):
            return
        candidate = admin_reauth or request.headers.get('X-Admin-Reauth')
        if not candidate:
            raise HTTPException(status_code=403, detail='Fresh admin verification required')
        user_row = conn.execute('SELECT * FROM users WHERE id = ?', (user['id'],)).fetchone()
        if not user_row or not verify_password(candidate, user_row['password_salt'], user_row['password_hash']):
            raise HTTPException(status_code=403, detail='Invalid admin re-verification password')
        conn.execute('UPDATE sessions SET admin_verified_at = ? WHERE token = ?', (utc_now(), session_token))



def evaluate_policies(policies: List[Dict[str, Any]], payload: SimulationRequest) -> Dict[str, Any]:
    explanations: List[str] = []
    risk_score = 18
    hard_failures = 0
    payload_map = payload.model_dump()
    for policy in policies:
        if int(policy['enabled']) != 1:
            continue
        rule = policy['rule']
        actual_value = payload_map.get(rule['check'])
        expected = rule['expected']
        if rule['check'] == 'oracle_max_drift_bps':
            passed = int(actual_value or 0) <= int(expected)
        else:
            passed = actual_value == expected
        if passed:
            explanations.append(f"{policy['policy_code']} passed: {policy['name']}")
            continue
        mode = rule.get('mode', 'block')
        if mode == 'block':
            explanations.append(f"{policy['policy_code']} failed and blocks execution")
            risk_score += 20
            hard_failures += 1
        else:
            explanations.append(f"{policy['policy_code']} failed and requires review")
            risk_score += 12

    if payload.environment == 'production':
        risk_score += 6
        explanations.append('Production environment raises operational sensitivity')
    if payload.action == 'upgrade_proxy_implementation':
        risk_score += 8
        explanations.append('Privileged upgrade path touches governance-sensitive control surfaces')
    if payload.touches_mint_redeem_logic:
        risk_score += 10
        explanations.append('Change can affect mint or redeem logic')

    platform_signal = evaluate_platform_signals(payload_map)
    risk_score += int(platform_signal['risk_delta'])
    hard_failures += int(platform_signal['hard_failures'])
    explanations.extend(platform_signal['explanations'])

    risk_score = min(risk_score, 100)
    status = 'blocked' if hard_failures >= 2 or risk_score >= 80 else status_for(risk_score)
    severity = severity_for(risk_score)
    summary = {
        'blocked': 'Privileged change blocked because platform controls flagged unacceptable Treasury-token risk.',
        'review': 'Change requires multi-team review before execution.',
        'allowed': 'Change satisfied the configured platform, compliance, and resilience controls.',
    }[status]
    headline_findings = []
    for layer_name, messages in platform_signal['layer_summaries'].items():
        if messages:
            headline_findings.append(f"{layer_name.replace('_', ' ').title()}: {messages[0]}")
    return {
        'risk_score': risk_score,
        'status': status,
        'severity': severity,
        'summary': summary,
        'explanations': explanations,
        'control_layers': platform_signal['layer_summaries'],
        'headline_findings': headline_findings[:4],
        'alert_candidates': platform_signal['alert_candidates'],
    }



def create_incident_record(tenant_id: int, user_id: int | None, *, title: str, severity: str, status: str, summary: str, source: str, assignee: str | None = None, external_ticket: str | None = None, resolution_notes: str | None = None) -> int:
    now_value = utc_now()
    with db() as conn:
        incident_id = int(conn.execute(
            '''
            INSERT INTO incidents (
                tenant_id, title, severity, status, summary, source, assignee, external_ticket,
                resolution_notes, created_by_user_id, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''',
            (tenant_id, title, severity, status, summary, source, assignee, external_ticket, resolution_notes, user_id, now_value, now_value),
        ).lastrowid)
        conn.execute(
            'INSERT INTO incident_events (incident_id, actor_user_id, event_type, details_json, created_at) VALUES (?, ?, ?, ?, ?)',
            (incident_id, user_id, 'incident.created', json.dumps({'status': status, 'summary': summary}), now_value),
        )
    return incident_id



def queue_webhook_jobs(tenant_id: int, user_id: int | None, event_type: str, payload: Dict[str, Any]) -> int:
    queued = 0
    with db() as conn:
        webhooks = conn.execute(
            'SELECT * FROM webhooks WHERE tenant_id = ? AND event_type = ? AND is_active = 1',
            (tenant_id, event_type),
        ).fetchall()
    for webhook in webhooks:
        enqueue_job(
            job_type='webhook.deliver',
            tenant_id=tenant_id,
            user_id=user_id,
            available_at=utc_now(),
            payload={'webhook_id': webhook['id'], 'event_type': event_type, 'event_payload': payload},
            max_attempts=settings.webhook_max_retries,
        )
        queued += 1
    return queued



def run_simulation_and_persist(user_id: int, payload: SimulationRequest, *, emit_webhooks: bool = True) -> Dict[str, Any]:
    tenant = current_tenant_for(user_id, payload.tenant_id)
    permission_for_tenant(user_id, tenant['id'], 'simulation.run')
    policies = list_policies(tenant['id'])
    decision = evaluate_policies(policies, payload)
    report_code = f"INFRA-{datetime.now(timezone.utc).strftime('%Y%m%d')}-{secrets.randbelow(900)+100}"
    now_value = utc_now()
    with db() as conn:
        simulation_run_id = int(conn.execute(
            '''
            INSERT INTO simulation_runs (
                tenant_id, user_id, asset_name, environment, action, contract_name, requested_by,
                payload_json, status, risk_score, severity, summary, explanations_json, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''',
            (
                tenant['id'], user_id, payload.asset_name, payload.environment, payload.action,
                payload.contract_name, payload.requested_by, payload.model_dump_json(), decision['status'],
                decision['risk_score'], decision['severity'], decision['summary'], json.dumps(decision['explanations']), now_value,
            ),
        ).lastrowid)
        report_body = {
            'report_code': report_code,
            'tenant': tenant['name'],
            'asset_name': payload.asset_name,
            'decision': decision,
            'payload': payload.model_dump(),
            'generated_at': now_value,
            'control_layers': decision.get('control_layers', {}),
            'headline_findings': decision.get('headline_findings', []),
            'recommended_action': (
                'Escalate to review board, restore oracle/compliance controls, and require approved signer plus dual approval in an open maintenance window.'
                if decision['status'] == 'blocked'
                else 'Document reviewer approval, verify oracle health, and maintain audit evidence.' if decision['status'] == 'review'
                else 'Proceed under standard monitoring with provenance, market, and resilience checks retained.'
            ),
        }
        report_id = int(conn.execute(
            'INSERT INTO reports (tenant_id, simulation_run_id, report_code, content_json, created_at) VALUES (?, ?, ?, ?, ?)',
            (tenant['id'], simulation_run_id, report_code, json.dumps(report_body), now_value),
        ).lastrowid)

    audit_event(
        tenant['id'], user_id, 'simulation.run', 'simulation_run', str(simulation_run_id),
        f"{payload.action} evaluated with status {decision['status']}",
        {'asset_name': payload.asset_name, 'risk_score': decision['risk_score'], 'report_id': report_id},
    )

    incident_id = None
    settings_map = get_admin_setting_map(tenant['id'])
    threshold = int(settings_map.get('auto_incident_min_risk', '80'))
    for candidate in decision.get('alert_candidates', []):
        create_or_update_alert(tenant['id'], candidate['alert_key'], candidate['severity'], candidate['source'], candidate['summary'], candidate['details'])
    if decision['status'] == 'blocked' and decision['risk_score'] >= threshold:
        incident_id = create_incident_record(
            tenant['id'], user_id,
            title=f'Blocked simulation for {payload.asset_name}',
            severity=decision['severity'],
            status='open',
            summary=decision['summary'],
            source='simulation',
        )
        audit_event(tenant['id'], user_id, 'incident.create.auto', 'incident', str(incident_id), 'Auto-created incident from blocked simulation', {'simulation_run_id': simulation_run_id})

    queued_webhooks = 0
    if emit_webhooks:
        queued_webhooks = queue_webhook_jobs(
            tenant['id'], user_id, f"simulation.{decision['status']}",
            {'simulation_run_id': simulation_run_id, 'report_id': report_id, 'tenant_id': tenant['id'], 'status': decision['status'], 'risk_score': decision['risk_score'], 'summary': decision['summary']},
        )

    return {
        'simulation_run_id': simulation_run_id,
        'report_id': report_id,
        'incident_id': incident_id,
        'queued_webhook_jobs': queued_webhooks,
        'tenant': tenant,
        **decision,
    }



def validate_setting(setting_key: str, setting_value: str) -> str:
    if setting_key not in SETTINGS_CATALOG:
        raise HTTPException(status_code=400, detail='Unsupported setting key')
    rule = SETTINGS_CATALOG[setting_key]
    if rule['type'] == 'int':
        try:
            parsed = int(setting_value)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail='Setting value must be an integer') from exc
        if parsed < rule['min'] or parsed > rule['max']:
            raise HTTPException(status_code=400, detail='Setting value out of range')
        return str(parsed)
    if rule['type'] == 'bool':
        lowered = setting_value.strip().lower()
        if lowered not in {'true', 'false'}:
            raise HTTPException(status_code=400, detail='Boolean settings accept true or false')
        return lowered
    return setting_value



def process_background_job(job: Dict[str, Any]) -> Dict[str, Any]:
    payload = job['payload']
    if job['job_type'] == 'simulation.run':
        request_payload = SimulationRequest(**payload['simulation'])
        return run_simulation_and_persist(user_id=int(payload['user_id']), payload=request_payload)
    if job['job_type'] == 'monitoring.run_profile':
        return run_monitoring_profile(user_id=int(payload.get('user_id') or job.get('user_id') or 1), tenant_id=int(payload['tenant_id']), profile_id=int(payload['profile_id']), trigger=payload.get('triggered_by', 'job'))
    if job['job_type'] == 'webhook.deliver':
        return deliver_webhook(payload['webhook_id'], payload['event_type'], payload['event_payload'])
    raise RuntimeError(f"Unsupported job_type: {job['job_type']}")



def deliver_webhook(webhook_id: int, event_type: str, event_payload: Dict[str, Any]) -> Dict[str, Any]:
    with db() as conn:
        webhook = conn.execute('SELECT * FROM webhooks WHERE id = ?', (webhook_id,)).fetchone()
    if not webhook or int(webhook['is_active']) != 1:
        raise RuntimeError('Webhook not active or not found')
    body = {'event_type': event_type, 'sent_at': utc_now(), 'data': event_payload}
    raw_body = json.dumps(body, separators=(',', ':'))
    signature = hmac.new(webhook['secret_value'].encode('utf-8'), raw_body.encode('utf-8'), hashlib.sha256).hexdigest()
    headers = {
        'Content-Type': 'application/json',
        'X-Decoda-Event': event_type,
        'X-Decoda-Signature': signature,
    }
    status = 'delivered'
    response_code = None
    error_message = None
    try:
        with httpx.Client(timeout=settings.webhook_timeout_seconds) as client:
            response = client.post(webhook['url'], content=raw_body, headers=headers)
            response_code = response.status_code
            if response.status_code >= 300:
                status = 'failed'
                error_message = f'Webhook returned HTTP {response.status_code}'
    except Exception as exc:
        status = 'failed'
        error_message = str(exc)
    with db() as conn:
        conn.execute(
            '''
            INSERT INTO webhook_deliveries (webhook_id, event_type, request_body, response_code, status, attempt_count, last_error, created_at, delivered_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''',
            (webhook_id, event_type, raw_body, response_code, status, 1, error_message, utc_now(), utc_now() if status == 'delivered' else None),
        )
        conn.execute('UPDATE webhooks SET last_delivery_at = ?, updated_at = ? WHERE id = ?', (utc_now(), utc_now(), webhook_id))
    if status != 'delivered':
        raise RuntimeError(error_message or 'Webhook delivery failed')
    return {'ok': True, 'webhook_id': webhook_id, 'response_code': response_code}


@app.get('/')
def root(request: Request) -> Response:
    user = get_session_user(request.cookies.get(SESSION_COOKIE), request=request)
    if user:
        return RedirectResponse(url='/dashboard', status_code=303)
    return RedirectResponse(url='/login', status_code=303)


@app.get('/infra')
def infra_root(request: Request) -> Response:
    user = get_session_user(request.cookies.get(SESSION_COOKIE), request=request)
    return RedirectResponse(url='/dashboard' if user else '/login?next=/infra', status_code=302)


@app.get('/infra/')
def infra_root_slash(request: Request) -> Response:
    user = get_session_user(request.cookies.get(SESSION_COOKIE), request=request)
    return RedirectResponse(url='/dashboard' if user else '/login?next=/infra', status_code=302)


@app.get('/healthz')
def healthz() -> Dict[str, str]:
    return {'status': 'ok', 'app': APP_NAME, 'version': VERSION}


@app.get('/ready')
def ready() -> Dict[str, str]:
    with db() as conn:
        conn.execute('SELECT 1')
    return {'status': 'ready'}


@app.get('/login', response_class=HTMLResponse)
def login_page(request: Request, next: str = '/dashboard') -> HTMLResponse:
    user = get_session_user(request.cookies.get(SESSION_COOKIE), request=request)
    if user:
        return RedirectResponse(url=next, status_code=303)
    return templates.TemplateResponse(request, 'login.html', {'next': next, 'demo_email': DEMO_USER_EMAIL, 'demo_password': DEMO_USER_PASSWORD})


@app.post('/api/auth/login')
def api_login(payload: LoginRequest, request: Request) -> JSONResponse:
    email = payload.email.strip().lower()
    ip_hash = sha256_text(request_ip(request))
    if login_rate_limited(email, ip_hash):
        raise HTTPException(status_code=429, detail='Too many failed login attempts. Try again later.')
    with db() as conn:
        row = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
    if not row or not verify_password(payload.password, row['password_salt'], row['password_hash']):
        record_login_attempt(email, ip_hash, succeeded=False)
        raise HTTPException(status_code=401, detail='Invalid email or password')
    token = create_session(int(row['id']), request)
    record_login_attempt(email, ip_hash, succeeded=True)
    audit_event(None, int(row['id']), 'auth.login', 'user', str(row['id']), 'User logged in', {'email': row['email']})
    response = JSONResponse({'ok': True, 'redirect': '/dashboard'})
    response.set_cookie(
        SESSION_COOKIE,
        token,
        httponly=True,
        secure=settings.session_cookie_secure,
        samesite=settings.session_cookie_samesite,
        max_age=settings.session_absolute_minutes * 60,
        path='/',
    )
    return response


@app.post('/api/auth/logout')
def api_logout(request: Request, session_token: Optional[str] = Cookie(default=None, alias=SESSION_COOKIE)) -> JSONResponse:
    user = get_session_user(session_token, request=request)
    if user:
        audit_event(None, int(user['id']), 'auth.logout', 'user', str(user['id']), 'User logged out', {'email': user['email']})
    destroy_session(session_token)
    response = JSONResponse({'ok': True, 'redirect': '/login'})
    response.delete_cookie(SESSION_COOKIE, path='/')
    return response


@app.post('/api/auth/admin/verify')
def api_admin_verify(payload: AdminVerifyRequest, request: Request) -> Dict[str, Any]:
    user = require_user(request)
    ensure_admin_reauth(user, request, payload.tenant_id, admin_reauth=payload.password)
    audit_event(payload.tenant_id, int(user['id']), 'auth.admin.verify', 'session', request.cookies.get(SESSION_COOKIE), 'Admin re-verification completed', {})
    return {'ok': True, 'reauth_valid_for_minutes': settings.admin_reauth_minutes}


@app.get('/dashboard', response_class=HTMLResponse)
def dashboard_page(request: Request, tenant_id: Optional[int] = None) -> HTMLResponse:
    user = require_user(request)
    tenant = current_tenant_for(int(user['id']), tenant_id)
    permission_for_tenant(int(user['id']), tenant['id'], 'dashboard.read')
    latest_runs = list_simulation_runs(tenant['id'], limit=6)
    policies = list_policies(tenant['id'])
    context = {
        'tenant': tenant,
        'tenants': get_user_tenants(int(user['id'])),
        'stats': dashboard_stats(tenant['id']),
        'latest_runs': latest_runs,
        'latest_reports': list_reports(tenant['id'], limit=5),
        'incidents': list_incidents(tenant['id'])[:4],
        'focus': summarize_dashboard_focus(latest_runs, policies),
        'platform': platform_feature_summary(tenant['id']),
        'monitoring': monitoring_overview(tenant['id']),
        'scenario_catalog': scenario_catalog(),
        'short_addr': short_addr,
        'current_nav': 'dashboard',
    }
    return templates.TemplateResponse(request, 'dashboard.html', {'user': dict(user), **context})


@app.get('/policies', response_class=HTMLResponse)
def policies_page(request: Request, tenant_id: Optional[int] = None) -> HTMLResponse:
    user = require_user(request)
    tenant = current_tenant_for(int(user['id']), tenant_id)
    permission_for_tenant(int(user['id']), tenant['id'], 'policy.read')
    return templates.TemplateResponse(request, 'policies.html', {'user': dict(user), 'tenant': tenant, 'tenants': get_user_tenants(int(user['id'])), 'policies': list_policies(tenant['id']), 'scenario_catalog': scenario_catalog(), 'current_nav': 'policies'})


@app.get('/simulations', response_class=HTMLResponse)
def simulations_page(request: Request, tenant_id: Optional[int] = None) -> HTMLResponse:
    user = require_user(request)
    tenant = current_tenant_for(int(user['id']), tenant_id)
    permission_for_tenant(int(user['id']), tenant['id'], 'simulation.read')
    runs = list_simulation_runs(tenant['id'], limit=20)
    reports = list_reports(tenant['id'], limit=5)
    audits = list_audit_events(tenant['id'], limit=10)
    latest_run = runs[0] if runs else None
    latest_report = reports[0] if reports else None
    latest_audit = audits[0] if audits else None
    return templates.TemplateResponse(request, 'simulations.html', {'user': dict(user), 'tenant': tenant, 'tenants': get_user_tenants(int(user['id'])), 'runs': runs, 'latest_run': latest_run, 'latest_report': latest_report, 'latest_audit': latest_audit, 'initial_seed': build_simulation_seed(latest_run, latest_report, latest_audit), 'policies': list_policies(tenant['id']), 'current_nav': 'simulations'})


@app.get('/monitoring', response_class=HTMLResponse)
def monitoring_page(request: Request, tenant_id: Optional[int] = None) -> HTMLResponse:
    user = require_user(request)
    tenant = current_tenant_for(int(user['id']), tenant_id)
    permission_for_tenant(int(user['id']), tenant['id'], 'monitoring.read')
    overview = monitoring_workspace_overview(tenant['id'])
    return templates.TemplateResponse(request, 'monitoring.html', {'user': dict(user), 'tenant': tenant, 'tenants': get_user_tenants(int(user['id'])), 'overview': overview, 'monitoring_section': 'overview', 'current_nav': 'monitoring'})


@app.get('/monitoring/watch', response_class=HTMLResponse)
def monitoring_watch_page(request: Request, tenant_id: Optional[int] = None) -> HTMLResponse:
    user = require_user(request)
    tenant = current_tenant_for(int(user['id']), tenant_id)
    permission_for_tenant(int(user['id']), tenant['id'], 'monitoring.read')
    overview = monitoring_mode_dashboard(tenant['id'], 'auto_watch')
    return templates.TemplateResponse(request, 'monitoring_watch.html', {'user': dict(user), 'tenant': tenant, 'tenants': get_user_tenants(int(user['id'])), 'overview': overview, 'monitoring_section': 'watch', 'current_nav': 'monitoring'})


@app.get('/monitoring/review', response_class=HTMLResponse)
def monitoring_review_page(request: Request, tenant_id: Optional[int] = None) -> HTMLResponse:
    user = require_user(request)
    tenant = current_tenant_for(int(user['id']), tenant_id)
    permission_for_tenant(int(user['id']), tenant['id'], 'monitoring.read')
    overview = monitoring_mode_dashboard(tenant['id'], 'auto_review')
    return templates.TemplateResponse(request, 'monitoring_review.html', {'user': dict(user), 'tenant': tenant, 'tenants': get_user_tenants(int(user['id'])), 'overview': overview, 'monitoring_section': 'review', 'current_nav': 'monitoring'})


@app.get('/monitoring/enforce', response_class=HTMLResponse)
def monitoring_enforce_page(request: Request, tenant_id: Optional[int] = None) -> HTMLResponse:
    user = require_user(request)
    tenant = current_tenant_for(int(user['id']), tenant_id)
    permission_for_tenant(int(user['id']), tenant['id'], 'monitoring.read')
    overview = monitoring_mode_dashboard(tenant['id'], 'auto_enforce')
    return templates.TemplateResponse(request, 'monitoring_enforce.html', {'user': dict(user), 'tenant': tenant, 'tenants': get_user_tenants(int(user['id'])), 'overview': overview, 'monitoring_section': 'enforce', 'current_nav': 'monitoring'})


@app.get('/monitoring/profiles/new', response_class=HTMLResponse)
def monitoring_profile_new_page(request: Request, tenant_id: Optional[int] = None, mode: str = 'auto_watch') -> HTMLResponse:
    user = require_user(request)
    tenant = current_tenant_for(int(user['id']), tenant_id)
    permission_for_tenant(int(user['id']), tenant['id'], 'monitoring.manage')
    mode = mode if mode in MONITORING_MODES else 'auto_watch'
    seed = {
        'environment': tenant['environment'],
        'frequency_seconds': 300,
        'mode': mode,
        'asset_type': 'Treasury token',
        'contract_name': 'TreasuryTokenProxy',
        'admin_wallets': ['0xAUTO0000000000000000000000000000000WATCH'],
        'reserve_wallets': ['0xRESERVE00000000000000000000000000000001'],
        'oracle_endpoints': ['Bloomberg', 'Reuters', 'Fedwire'],
        'chain_list': ['ethereum', 'avalanche'],
        'notification_emails': [user['email']],
        'thresholds': DEFAULT_MONITORING_THRESHOLDS,
        'signal_overrides': DEFAULT_MONITORING_SIGNAL_OVERRIDES,
    }
    section_map = {'auto_watch': 'watch', 'auto_review': 'review', 'auto_enforce': 'enforce', 'off': 'overview'}
    return templates.TemplateResponse(request, 'monitoring_profile_new.html', {'user': dict(user), 'tenant': tenant, 'tenants': get_user_tenants(int(user['id'])), 'seed': seed, 'monitoring_section': section_map.get(mode, 'watch'), 'current_nav': 'monitoring'})


@app.get('/monitoring/profiles/{profile_id}', response_class=HTMLResponse)
def monitoring_profile_detail_page(profile_id: int, request: Request, tenant_id: Optional[int] = None) -> HTMLResponse:
    user = require_user(request)
    tenant = current_tenant_for(int(user['id']), tenant_id)
    permission_for_tenant(int(user['id']), tenant['id'], 'monitoring.read')
    profile = get_monitoring_profile(tenant['id'], profile_id)
    if not profile:
        raise HTTPException(status_code=404, detail='Monitoring profile not found')
    alerts = [item for item in list_alerts(tenant['id']) if item.get('details', {}).get('watch_profile_id') == profile_id][:12]
    section_map = {'auto_watch': 'watch', 'auto_review': 'review', 'auto_enforce': 'enforce', 'off': 'overview'}
    return templates.TemplateResponse(request, 'monitoring_profile_detail.html', {'user': dict(user), 'tenant': tenant, 'tenants': get_user_tenants(int(user['id'])), 'profile': profile, 'alerts': alerts, 'monitoring_section': section_map.get(profile.get('mode'), 'overview'), 'current_nav': 'monitoring'})


@app.get('/reports', response_class=HTMLResponse)
def reports_page(request: Request, tenant_id: Optional[int] = None) -> HTMLResponse:
    user = require_user(request)
    tenant = current_tenant_for(int(user['id']), tenant_id)
    permission_for_tenant(int(user['id']), tenant['id'], 'report.read')
    return templates.TemplateResponse(request, 'reports.html', {'user': dict(user), 'tenant': tenant, 'tenants': get_user_tenants(int(user['id'])), 'reports': list_reports(tenant['id'], limit=25), 'scenario_catalog': scenario_catalog(), 'short_addr': short_addr, 'current_nav': 'reports'})


@app.get('/audit', response_class=HTMLResponse)
def audit_page(request: Request, tenant_id: Optional[int] = None) -> HTMLResponse:
    user = require_user(request)
    tenant = current_tenant_for(int(user['id']), tenant_id)
    permission_for_tenant(int(user['id']), tenant['id'], 'audit.read')
    return templates.TemplateResponse(request, 'audit.html', {'user': dict(user), 'tenant': tenant, 'tenants': get_user_tenants(int(user['id'])), 'events': list_audit_events(tenant['id'], limit=50), 'current_nav': 'audit'})


@app.get('/admin', response_class=HTMLResponse)
def admin_page(request: Request, tenant_id: Optional[int] = None) -> HTMLResponse:
    user = require_user(request)
    tenant = current_tenant_for(int(user['id']), tenant_id)
    permission_for_tenant(int(user['id']), tenant['id'], 'settings.read')
    return templates.TemplateResponse(request, 'admin.html', {'user': dict(user), 'tenant': tenant, 'tenants': get_user_tenants(int(user['id'])), 'incidents': list_incidents(tenant['id']), 'webhooks': list_webhooks(tenant['id']), 'settings': list_admin_settings(tenant['id']), 'current_nav': 'admin'})



@app.get('/threat-defense', response_class=HTMLResponse)
def threat_defense_page(request: Request, tenant_id: Optional[int] = None) -> HTMLResponse:
    user = require_user(request)
    tenant = current_tenant_for(int(user['id']), tenant_id)
    permission_for_tenant(int(user['id']), tenant['id'], 'monitoring.read')
    events = list_market_surveillance_events(tenant['id'])
    runs = list_simulation_runs(tenant['id'], limit=12)
    return templates.TemplateResponse(request, 'threat_defense.html', {'user': dict(user), 'tenant': tenant, 'tenants': get_user_tenants(int(user['id'])), 'events': events, 'runs': runs, 'current_nav': 'threat-defense'})


@app.get('/oracle-integrity', response_class=HTMLResponse)
def oracle_integrity_page(request: Request, tenant_id: Optional[int] = None) -> HTMLResponse:
    user = require_user(request)
    tenant = current_tenant_for(int(user['id']), tenant_id)
    permission_for_tenant(int(user['id']), tenant['id'], 'monitoring.read')
    snapshots = list_oracle_integrity_snapshots(tenant['id'])
    provenance = list_provenance_records(tenant['id'])
    return templates.TemplateResponse(request, 'oracle_integrity.html', {'user': dict(user), 'tenant': tenant, 'tenants': get_user_tenants(int(user['id'])), 'snapshots': snapshots, 'provenance': provenance, 'current_nav': 'oracle-integrity'})


@app.get('/governance', response_class=HTMLResponse)
def governance_page(request: Request, tenant_id: Optional[int] = None) -> HTMLResponse:
    user = require_user(request)
    tenant = current_tenant_for(int(user['id']), tenant_id)
    permission_for_tenant(int(user['id']), tenant['id'], 'monitoring.read')
    controls = list_compliance_controls(tenant['id'])
    approvals = list_approval_requests(tenant['id'])[:8]
    return templates.TemplateResponse(request, 'governance.html', {'user': dict(user), 'tenant': tenant, 'tenants': get_user_tenants(int(user['id'])), 'controls': controls, 'approvals': approvals, 'current_nav': 'governance'})


@app.get('/resilience', response_class=HTMLResponse)
def resilience_page(request: Request, tenant_id: Optional[int] = None) -> HTMLResponse:
    user = require_user(request)
    tenant = current_tenant_for(int(user['id']), tenant_id)
    permission_for_tenant(int(user['id']), tenant['id'], 'monitoring.read')
    states = list_resilience_states(tenant['id'])
    alerts = list_alerts(tenant['id'])[:10]
    return templates.TemplateResponse(request, 'resilience.html', {'user': dict(user), 'tenant': tenant, 'tenants': get_user_tenants(int(user['id'])), 'states': states, 'alerts': alerts, 'current_nav': 'resilience'})


@app.get('/api/v1/me')
def api_me(request: Request) -> Dict[str, Any]:
    user = require_user(request)
    return {'user': {'id': user['id'], 'email': user['email'], 'full_name': user['full_name']}, 'tenants': get_user_tenants(int(user['id']))}


@app.get('/api/v1/tenants')
def api_tenants(request: Request) -> List[Dict[str, Any]]:
    user = require_user(request)
    return get_user_tenants(int(user['id']))


@app.get('/api/v1/policies')
def api_policies(request: Request, tenant_id: int) -> List[Dict[str, Any]]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'policy.read')
    return list_policies(tenant_id)


@app.post('/api/v1/policies/{policy_id}/toggle')
def api_toggle_policy(policy_id: int, payload: PolicyToggleRequest, request: Request) -> Dict[str, Any]:
    user = require_user(request)
    with db() as conn:
        row = conn.execute('SELECT * FROM policies WHERE id = ?', (policy_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail='Policy not found')
        permission_for_tenant(int(user['id']), int(row['tenant_id']), 'policy.manage')
        conn.execute('UPDATE policies SET enabled = ?, updated_at = ? WHERE id = ?', (1 if payload.enabled else 0, utc_now(), policy_id))
    audit_event(int(row['tenant_id']), int(user['id']), 'policy.toggle', 'policy', str(policy_id), 'Policy state updated', {'enabled': payload.enabled})
    return {'ok': True, 'policy_id': policy_id, 'enabled': payload.enabled}


@app.post('/api/v1/simulations/run')
def api_run_simulation(payload: SimulationRequest, request: Request) -> Dict[str, Any]:
    user = require_user(request)
    result = run_simulation_and_persist(int(user['id']), payload)
    return result


@app.post('/api/v1/simulations/queue')
def api_queue_simulation(payload: SimulationRequest, request: Request) -> Dict[str, Any]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), payload.tenant_id, 'simulation.queue')
    job_id = enqueue_job(job_type='simulation.run', payload={'user_id': int(user['id']), 'simulation': payload.model_dump()}, tenant_id=payload.tenant_id, user_id=int(user['id']), available_at=utc_now(), max_attempts=3)
    audit_event(payload.tenant_id, int(user['id']), 'simulation.queue', 'job', str(job_id), 'Simulation queued for background processing', {'tenant_id': payload.tenant_id})
    return {'ok': True, 'job_id': job_id, 'status': 'queued'}


@app.get('/api/v1/jobs/{job_id}')
def api_job_detail(job_id: int, request: Request) -> Dict[str, Any]:
    user = require_user(request)
    job = get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail='Job not found')
    if job.get('tenant_id'):
        permission_for_tenant(int(user['id']), int(job['tenant_id']), 'job.read')
    return job


@app.get('/api/v1/simulations')
def api_simulations(request: Request, tenant_id: int) -> List[Dict[str, Any]]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'simulation.read')
    return list_simulation_runs(tenant_id, limit=50)


@app.get('/api/v1/reports')
def api_reports(request: Request, tenant_id: int) -> List[Dict[str, Any]]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'report.read')
    return list_reports(tenant_id, limit=50)


@app.get('/api/v1/reports/{report_id}')
def api_export_report(report_id: int, request: Request, format: str = 'json') -> Response:
    user = require_user(request)
    with db() as conn:
        row = conn.execute('SELECT * FROM reports WHERE id = ?', (report_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail='Report not found')
    permission_for_tenant(int(user['id']), int(row['tenant_id']), 'report.read')
    content = json.loads(row['content_json'])
    audit_event(int(row['tenant_id']), int(user['id']), 'report.export', 'report', str(report_id), 'Report exported', {'format': format})
    if format == 'json':
        return JSONResponse(content=content)
    if format == 'md':
        decision = content['decision']
        payload = content['payload']
        md = [
            f"# {content['report_code']}",
            '',
            f"- Tenant: {content['tenant']}",
            f"- Asset: {content['asset_name']}",
            f"- Status: {decision['status']}",
            f"- Risk score: {decision['risk_score']}",
            f"- Severity: {decision['severity']}",
            f"- Generated at: {content['generated_at']}",
            '', '## Summary', decision['summary'], '', '## Explanations'
        ]
        for line in decision['explanations']:
            md.append(f'- {line}')
        md.extend(['', '## Payload', '```json', json.dumps(payload, indent=2), '```'])
        return PlainTextResponse('\n'.join(md), media_type='text/markdown')
    if format == 'csv':
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(['field', 'value'])
        writer.writerow(['report_code', content['report_code']])
        writer.writerow(['tenant', content['tenant']])
        writer.writerow(['asset_name', content['asset_name']])
        for key, value in content['decision'].items():
            if key == 'explanations':
                continue
            writer.writerow([f'decision_{key}', value])
        for idx, explanation in enumerate(content['decision']['explanations'], start=1):
            writer.writerow([f'explanation_{idx}', explanation])
        data = io.BytesIO(buf.getvalue().encode('utf-8'))
        headers = {'Content-Disposition': f'attachment; filename="{content["report_code"].lower()}.csv"'}
        return StreamingResponse(data, media_type='text/csv', headers=headers)
    raise HTTPException(status_code=400, detail='Unsupported format')


@app.get('/api/v1/audit')
def api_audit(request: Request, tenant_id: int) -> List[Dict[str, Any]]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'audit.read')
    return list_audit_events(tenant_id, limit=100)


@app.get('/api/v1/incidents')
def api_incidents(request: Request, tenant_id: int) -> List[Dict[str, Any]]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'incident.read')
    return list_incidents(tenant_id)


@app.post('/api/v1/incidents')
def api_create_incident(payload: IncidentCreateRequest, request: Request) -> Dict[str, Any]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), payload.tenant_id, 'incident.create')
    incident_id = create_incident_record(payload.tenant_id, int(user['id']), title=payload.title, severity=payload.severity, status=payload.status, summary=payload.summary, source=payload.source, assignee=payload.assignee, external_ticket=payload.external_ticket)
    audit_event(payload.tenant_id, int(user['id']), 'incident.create', 'incident', str(incident_id), 'Incident created', payload.model_dump())
    return {'ok': True, 'incident_id': incident_id}


@app.patch('/api/v1/incidents/{incident_id}')
def api_update_incident(incident_id: int, payload: IncidentUpdateRequest, request: Request) -> Dict[str, Any]:
    user = require_user(request)
    with db() as conn:
        incident = conn.execute('SELECT * FROM incidents WHERE id = ?', (incident_id,)).fetchone()
        if not incident:
            raise HTTPException(status_code=404, detail='Incident not found')
    permission_for_tenant(int(user['id']), int(incident['tenant_id']), 'incident.manage')
    ensure_admin_reauth(user, request, int(incident['tenant_id']))
    fields = payload.model_dump(exclude_none=True)
    if not fields:
        raise HTTPException(status_code=400, detail='No incident changes supplied')
    updates = []
    values: list[Any] = []
    for key, value in fields.items():
        updates.append(f'{key} = ?')
        values.append(value)
    updates.append('updated_at = ?')
    values.append(utc_now())
    values.append(incident_id)
    with db() as conn:
        conn.execute(f"UPDATE incidents SET {', '.join(updates)} WHERE id = ?", tuple(values))
        conn.execute('INSERT INTO incident_events (incident_id, actor_user_id, event_type, details_json, created_at) VALUES (?, ?, ?, ?, ?)', (incident_id, int(user['id']), 'incident.updated', json.dumps(fields), utc_now()))
    audit_event(int(incident['tenant_id']), int(user['id']), 'incident.update', 'incident', str(incident_id), 'Incident updated', fields)
    return {'ok': True, 'incident_id': incident_id}


@app.get('/api/v1/webhooks')
def api_webhooks(request: Request, tenant_id: int) -> List[Dict[str, Any]]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'webhook.read')
    return list_webhooks(tenant_id)


@app.post('/api/v1/webhooks')
def api_create_webhook(payload: WebhookCreateRequest, request: Request) -> Dict[str, Any]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), payload.tenant_id, 'webhook.manage')
    ensure_admin_reauth(user, request, payload.tenant_id)
    secret_value = f"whsec_{secrets.token_urlsafe(24)}"
    secret_preview = f"{secret_value[:12]}****"
    with db() as conn:
        webhook_id = int(conn.execute(
            '''
            INSERT INTO webhooks (tenant_id, name, url, event_type, secret_value, secret_hash, secret_preview, is_active, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''',
            (payload.tenant_id, payload.name, payload.url, payload.event_type, secret_value, sha256_text(secret_value), secret_preview, 1, utc_now(), utc_now()),
        ).lastrowid)
    audit_event(payload.tenant_id, int(user['id']), 'webhook.create', 'webhook', str(webhook_id), 'Webhook created', payload.model_dump())
    return {'ok': True, 'webhook_id': webhook_id, 'secret_preview': secret_preview, 'secret_once': secret_value}


@app.patch('/api/v1/webhooks/{webhook_id}')
def api_update_webhook(webhook_id: int, payload: WebhookUpdateRequest, request: Request) -> Dict[str, Any]:
    user = require_user(request)
    with db() as conn:
        webhook = conn.execute('SELECT * FROM webhooks WHERE id = ?', (webhook_id,)).fetchone()
        if not webhook:
            raise HTTPException(status_code=404, detail='Webhook not found')
    permission_for_tenant(int(user['id']), int(webhook['tenant_id']), 'webhook.manage')
    ensure_admin_reauth(user, request, int(webhook['tenant_id']))
    with db() as conn:
        conn.execute('UPDATE webhooks SET is_active = ?, updated_at = ? WHERE id = ?', (1 if payload.is_active else 0, utc_now(), webhook_id))
    audit_event(int(webhook['tenant_id']), int(user['id']), 'webhook.update', 'webhook', str(webhook_id), 'Webhook state updated', {'is_active': payload.is_active})
    return {'ok': True, 'webhook_id': webhook_id, 'is_active': payload.is_active}


@app.post('/api/v1/webhooks/{webhook_id}/test')
def api_test_webhook(webhook_id: int, request: Request) -> Dict[str, Any]:
    user = require_user(request)
    with db() as conn:
        webhook = conn.execute('SELECT * FROM webhooks WHERE id = ?', (webhook_id,)).fetchone()
        if not webhook:
            raise HTTPException(status_code=404, detail='Webhook not found')
    permission_for_tenant(int(user['id']), int(webhook['tenant_id']), 'webhook.manage')
    ensure_admin_reauth(user, request, int(webhook['tenant_id']))
    job_id = enqueue_job(job_type='webhook.deliver', tenant_id=int(webhook['tenant_id']), user_id=int(user['id']), available_at=utc_now(), payload={'webhook_id': webhook_id, 'event_type': 'webhook.test', 'event_payload': {'message': 'Decoda test event', 'webhook_id': webhook_id}}, max_attempts=settings.webhook_max_retries)
    audit_event(int(webhook['tenant_id']), int(user['id']), 'webhook.test.queue', 'job', str(job_id), 'Webhook test delivery queued', {'webhook_id': webhook_id})
    return {'ok': True, 'job_id': job_id}


@app.get('/api/v1/webhooks/{webhook_id}/deliveries')
def api_webhook_deliveries(webhook_id: int, request: Request) -> List[Dict[str, Any]]:
    user = require_user(request)
    with db() as conn:
        webhook = conn.execute('SELECT * FROM webhooks WHERE id = ?', (webhook_id,)).fetchone()
        if not webhook:
            raise HTTPException(status_code=404, detail='Webhook not found')
    permission_for_tenant(int(user['id']), int(webhook['tenant_id']), 'webhook.read')
    return list_webhook_deliveries(webhook_id)


@app.get('/api/v1/admin/settings')
def api_admin_settings(request: Request, tenant_id: int) -> List[Dict[str, Any]]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'settings.read')
    return list_admin_settings(tenant_id)


@app.post('/api/v1/admin/settings')
def api_admin_settings_update(payload: AdminSettingUpdateRequest, request: Request) -> Dict[str, Any]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), payload.tenant_id, 'settings.manage')
    ensure_admin_reauth(user, request, payload.tenant_id)
    normalized = validate_setting(payload.setting_key, payload.setting_value)
    with db() as conn:
        existing = conn.execute('SELECT id FROM admin_settings WHERE tenant_id = ? AND setting_key = ?', (payload.tenant_id, payload.setting_key)).fetchone()
        if existing:
            conn.execute('UPDATE admin_settings SET setting_value = ?, updated_at = ? WHERE tenant_id = ? AND setting_key = ?', (normalized, utc_now(), payload.tenant_id, payload.setting_key))
        else:
            conn.execute('INSERT INTO admin_settings (tenant_id, setting_key, setting_value, updated_at) VALUES (?, ?, ?, ?)', (payload.tenant_id, payload.setting_key, normalized, utc_now()))
    audit_event(payload.tenant_id, int(user['id']), 'admin.setting.update', 'admin_setting', payload.setting_key, 'Admin setting updated', {'setting_value': normalized})
    return {'ok': True, 'setting_key': payload.setting_key, 'setting_value': normalized}


def seed_enterprise_data() -> None:
    now_value = utc_now()
    with db() as conn:
        provider = conn.execute('SELECT * FROM oidc_providers WHERE slug = ?', (settings.oidc_default_provider_slug,)).fetchone()
        if not provider:
            conn.execute(
                '''
                INSERT INTO oidc_providers (slug, name, issuer, authorization_endpoint, token_endpoint, userinfo_endpoint, client_id, client_secret, scopes, mode, is_active, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''',
                (
                    settings.oidc_default_provider_slug,
                    'Mock Enterprise SSO',
                    'https://mock.decoda.local',
                    '/api/auth/oidc/mock/authorize',
                    '/api/auth/oidc/mock/token',
                    '/api/auth/oidc/mock/userinfo',
                    'decoda-mock-client',
                    'decoda-mock-secret',
                    'openid profile email',
                    'mock',
                    1,
                    now_value,
                    now_value,
                ),
            )
        seeded_users = [
            (settings.oidc_mock_default_email, 'Decoda SSO Admin', 'tenant_admin'),
            ('analyst@decoda.local', 'Decoda Analyst', 'analyst'),
            ('reviewer@decoda.local', 'Decoda Reviewer', 'governance_reviewer'),
        ]
        tenants = conn.execute('SELECT * FROM tenants ORDER BY id').fetchall()
        for email, full_name, role_name in seeded_users:
            row = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
            if not row:
                salt = secrets.token_hex(16)
                user_id = int(conn.execute(
                    'INSERT INTO users (email, full_name, password_salt, password_hash, created_at) VALUES (?, ?, ?, ?, ?)',
                    (email, full_name, salt, hash_password('Decoda123!', salt), now_value),
                ).lastrowid)
            else:
                user_id = int(row['id'])
            for tenant in tenants:
                membership = conn.execute('SELECT * FROM user_tenants WHERE user_id = ? AND tenant_id = ?', (user_id, tenant['id'])).fetchone()
                if not membership:
                    conn.execute('INSERT INTO user_tenants (user_id, tenant_id, role_name) VALUES (?, ?, ?)', (user_id, tenant['id'], role_name))
        if conn.execute('SELECT COUNT(*) AS count FROM approval_requests').fetchone()['count'] == 0:
            sample_payload = {
                'simulation': {
                    'tenant_id': 1,
                    'asset_name': 'TreasuryToken 2026-A',
                    'environment': 'production',
                    'action': 'upgrade_proxy_implementation',
                    'contract_name': 'TreasuryTokenProxy',
                    'requested_by': '0xA11CE0000000000000000000000000000000A11C',
                    'new_implementation': '0x7777777777777777777777777777777777777777',
                    'change_window': 'open',
                    'dual_approval': True,
                    'implementation_preapproved': True,
                    'allowlisted_signer': True,
                    'touches_mint_redeem_logic': True,
                    'ai_zero_day_score': 22,
                    'market_anomaly_score': 18,
                    'oracle_source_count': 3,
                    'oracle_healthy_sources': 3,
                    'oracle_max_drift_bps': 3,
                    'collateral_ratio_pct': 100,
                    'kyc_wrapper_enabled': True,
                    'travel_rule_enabled': True,
                    'chain_count': 2,
                    'circuit_breaker_armed': True,
                    'liquidity_backstop_ready': True,
                    'notes': 'Seeded approval workflow example',
                }
            }
            conn.execute(
                '''
                INSERT INTO approval_requests (
                    tenant_id, requester_user_id, approval_type, title, status, target_type, target_payload_json,
                    required_approvals, approved_count, decision_summary, execute_job_type, execute_payload_json,
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''',
                (1, 1, 'simulation.execution', 'Approve TreasuryTokenProxy upgrade', 'pending', 'simulation', json.dumps(sample_payload), 2, 0, None, 'simulation.run', json.dumps(sample_payload), now_value, now_value),
            )


def list_tenant_members(tenant_id: int) -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute(
            '''
            SELECT u.id, u.email, u.full_name, u.is_active, ut.tenant_id, ut.role_name
            FROM user_tenants ut
            JOIN users u ON u.id = ut.user_id
            WHERE ut.tenant_id = ?
            ORDER BY u.email
            ''',
            (tenant_id,),
        ).fetchall()
    return rows


def list_approval_requests(tenant_id: int) -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute('SELECT * FROM approval_requests WHERE tenant_id = ? ORDER BY id DESC', (tenant_id,)).fetchall()
        actions_by_id = {
            row['approval_request_id']: []
            for row in conn.execute('SELECT * FROM approval_actions WHERE approval_request_id IN (SELECT id FROM approval_requests WHERE tenant_id = ?) ORDER BY id ASC', (tenant_id,)).fetchall()
        }
    with db() as conn:
        actions = conn.execute('SELECT * FROM approval_actions WHERE approval_request_id IN (SELECT id FROM approval_requests WHERE tenant_id = ?) ORDER BY id ASC', (tenant_id,)).fetchall()
    for action in actions:
        actions_by_id.setdefault(action['approval_request_id'], []).append(action)
    for row in rows:
        row['target_payload'] = json.loads(row['target_payload_json'])
        row['execute_payload'] = json.loads(row['execute_payload_json']) if row.get('execute_payload_json') else None
        row['actions'] = actions_by_id.get(row['id'], [])
    return rows


def create_or_update_alert(tenant_id: int, alert_key: str, severity: str, source: str, summary: str, details: Dict[str, Any]) -> int:
    now_value = utc_now()
    with db() as conn:
        existing = conn.execute('SELECT * FROM monitoring_alerts WHERE tenant_id = ? AND alert_key = ?', (tenant_id, alert_key)).fetchone()
        if existing:
            conn.execute(
                'UPDATE monitoring_alerts SET severity = ?, status = ?, source = ?, summary = ?, details_json = ?, updated_at = ? WHERE id = ?',
                (severity, 'open', source, summary, json.dumps(details), now_value, existing['id']),
            )
            return int(existing['id'])
        return int(conn.execute(
            'INSERT INTO monitoring_alerts (tenant_id, alert_key, severity, status, source, summary, details_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            (tenant_id, alert_key, severity, 'open', source, summary, json.dumps(details), now_value, now_value),
        ).lastrowid)


def list_alerts(tenant_id: int) -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute('SELECT * FROM monitoring_alerts WHERE tenant_id = ? ORDER BY id DESC', (tenant_id,)).fetchall()
    for row in rows:
        row['details'] = json.loads(row['details_json'])
    return rows


def _parse_json_blob(value: Any, default: Any) -> Any:
    if value in (None, ''):
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(value)
    except Exception:
        return default


def _inflate_monitoring_profile(row: Dict[str, Any]) -> Dict[str, Any]:
    row = dict(row)
    row['admin_wallets'] = _parse_json_blob(row.get('admin_wallets_json'), [])
    row['reserve_wallets'] = _parse_json_blob(row.get('reserve_wallets_json'), [])
    row['oracle_endpoints'] = _parse_json_blob(row.get('oracle_endpoints_json'), [])
    row['chain_list'] = _parse_json_blob(row.get('chain_list_json'), [])
    row['notification_emails'] = _parse_json_blob(row.get('notification_emails_json'), [])
    row['thresholds'] = _parse_json_blob(row.get('thresholds_json'), dict(DEFAULT_MONITORING_THRESHOLDS))
    row['signal_overrides'] = _parse_json_blob(row.get('signal_overrides_json'), dict(DEFAULT_MONITORING_SIGNAL_OVERRIDES))
    row['is_active'] = bool(int(row.get('is_active', 0)))
    return row




def normalize_wallet_address(value: str) -> str:
    return (value or '').strip()



def upsert_wallet_activity_snapshot(tenant_id: int, wallet_address: str, wallet_role: str, chain_name: str, source_mode: str, *, tx_count_24h: int = 0, incoming_tx_count_24h: int = 0, outgoing_tx_count_24h: int = 0, outgoing_native_amount_24h: float = 0.0, last_seen_at: str | None = None, burst_score: int = 0, details: Dict[str, Any] | None = None) -> int:
    now_value = utc_now()
    wallet_address = normalize_wallet_address(wallet_address)
    details = details or {}
    with db() as conn:
        existing = conn.execute(
            'SELECT * FROM wallet_activity_snapshots WHERE tenant_id = ? AND wallet_address = ? AND wallet_role = ? AND chain_name = ?',
            (tenant_id, wallet_address, wallet_role, chain_name),
        ).fetchone()
        if existing:
            conn.execute(
                """
                UPDATE wallet_activity_snapshots
                SET source_mode = ?, tx_count_24h = ?, incoming_tx_count_24h = ?, outgoing_tx_count_24h = ?, outgoing_native_amount_24h = ?, last_seen_at = ?, burst_score = ?, details_json = ?, updated_at = ?
                WHERE id = ?
                """,
                (source_mode, tx_count_24h, incoming_tx_count_24h, outgoing_tx_count_24h, float(outgoing_native_amount_24h), last_seen_at, burst_score, json.dumps(details), now_value, existing['id']),
            )
            return int(existing['id'])
        return int(conn.execute(
            """
            INSERT INTO wallet_activity_snapshots (
                tenant_id, wallet_address, wallet_role, chain_name, source_mode,
                tx_count_24h, incoming_tx_count_24h, outgoing_tx_count_24h, outgoing_native_amount_24h,
                last_seen_at, burst_score, details_json, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (tenant_id, wallet_address, wallet_role, chain_name, source_mode, tx_count_24h, incoming_tx_count_24h, outgoing_tx_count_24h, float(outgoing_native_amount_24h), last_seen_at, burst_score, json.dumps(details), now_value, now_value),
        ).lastrowid)



def list_wallet_activity_snapshots(tenant_id: int, *, wallet_addresses: List[str] | None = None) -> List[Dict[str, Any]]:
    wallet_addresses = [normalize_wallet_address(item) for item in (wallet_addresses or []) if normalize_wallet_address(item)]
    with db() as conn:
        if wallet_addresses:
            placeholders = ','.join(['?'] * len(wallet_addresses))
            rows = conn.execute(
                f'SELECT * FROM wallet_activity_snapshots WHERE tenant_id = ? AND wallet_address IN ({placeholders}) ORDER BY updated_at DESC',
                [tenant_id, *wallet_addresses],
            ).fetchall()
        else:
            rows = conn.execute('SELECT * FROM wallet_activity_snapshots WHERE tenant_id = ? ORDER BY updated_at DESC', (tenant_id,)).fetchall()
    for row in rows:
        row['details'] = _parse_json_blob(row.get('details_json'), {})
    return rows



def _wallet_activity_source_for_chain(profile: Dict[str, Any], chain_name: str) -> Dict[str, Any] | None:
    overrides = profile.get('signal_overrides', {}) or {}
    sources = overrides.get('wallet_activity_sources') or {}
    source = sources.get(chain_name) or sources.get(chain_name.lower())
    if isinstance(source, str):
        source = {'mode': 'etherscan_compatible', 'base_url': source}
    if not isinstance(source, dict):
        return None
    if source.get('enabled', True) in {False, 'false', 'False', 0}:
        return None
    return source



def _tx_timestamp(value: Any) -> datetime | None:
    if value in (None, ''):
        return None
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(float(value), tz=timezone.utc)
    if isinstance(value, str) and value.isdigit():
        return datetime.fromtimestamp(float(value), tz=timezone.utc)
    parsed = parse_utc(str(value))
    if parsed:
        return parsed
    try:
        return datetime.fromisoformat(str(value).replace('Z', '+00:00')).astimezone(timezone.utc)
    except Exception:
        return None



def _extract_wallet_activity_metrics(transactions: List[Dict[str, Any]], wallet_address: str) -> Dict[str, Any]:
    wallet = wallet_address.lower()
    cutoff = utc_dt() - timedelta(hours=24)
    tx_count_24h = 0
    incoming = 0
    outgoing = 0
    outgoing_native = 0.0
    timestamps: List[datetime] = []
    recent_hashes: List[str] = []
    for tx in transactions:
        when = _tx_timestamp(tx.get('timeStamp') or tx.get('timestamp') or tx.get('block_timestamp'))
        if when:
            timestamps.append(when)
        if not when or when < cutoff:
            continue
        tx_count_24h += 1
        from_value = str(tx.get('from') or tx.get('from_address') or '').lower()
        to_value = str(tx.get('to') or tx.get('to_address') or '').lower()
        if to_value == wallet:
            incoming += 1
        if from_value == wallet:
            outgoing += 1
            raw_value = tx.get('value') or tx.get('valueWei') or tx.get('value_wei') or 0
            try:
                numeric = float(raw_value)
                if numeric > 1e12:
                    numeric = numeric / 1e18
            except Exception:
                numeric = 0.0
            outgoing_native += numeric
        if tx.get('hash'):
            recent_hashes.append(str(tx['hash']))
    last_seen = max(timestamps).strftime('%Y-%m-%d %H:%M:%S UTC') if timestamps else None
    burst_score = min(100, tx_count_24h * 10)
    return {
        'tx_count_24h': tx_count_24h,
        'incoming_tx_count_24h': incoming,
        'outgoing_tx_count_24h': outgoing,
        'outgoing_native_amount_24h': round(outgoing_native, 8),
        'last_seen_at': last_seen,
        'burst_score': burst_score,
        'details': {'sample_hashes': recent_hashes[:5], 'fetched_transactions': len(transactions)},
    }



def fetch_wallet_activity_from_source(wallet_address: str, chain_name: str, source: Dict[str, Any]) -> Dict[str, Any]:
    mode = str(source.get('mode') or 'etherscan_compatible').strip().lower()
    if mode != 'etherscan_compatible':
        raise ValueError(f'Unsupported wallet activity source mode: {mode}')
    base_url = str(source.get('base_url') or '').strip()
    if not base_url:
        raise ValueError('wallet activity source base_url is required')
    params = {
        'module': 'account',
        'action': 'txlist',
        'address': wallet_address,
        'sort': 'desc',
        'page': 1,
        'offset': int(source.get('offset') or settings.wallet_connector_max_txs),
    }
    if source.get('startblock') is not None:
        params['startblock'] = source['startblock']
    api_key = source.get('api_key')
    if api_key:
        params['apikey'] = api_key
    with httpx.Client(timeout=settings.wallet_connector_timeout_seconds) as client:
        response = client.get(base_url, params=params)
        response.raise_for_status()
        payload = response.json()
    transactions = payload.get('result') if isinstance(payload, dict) else payload
    if not isinstance(transactions, list):
        raise ValueError('wallet activity source did not return a transaction list')
    metrics = _extract_wallet_activity_metrics(transactions, wallet_address)
    metrics['source_mode'] = mode
    metrics['details']['chain_name'] = chain_name
    metrics['details']['source_base_url'] = base_url
    return metrics



def refresh_wallet_activity_for_profile(user_id: int, tenant_id: int, profile_id: int) -> Dict[str, Any]:
    permission_for_tenant(user_id, tenant_id, 'monitoring.manage')
    profile = get_monitoring_profile(tenant_id, profile_id)
    if not profile:
        raise HTTPException(status_code=404, detail='Monitoring profile not found')
    refreshed: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []
    chain_list = profile.get('chain_list') or ['base']
    wallet_groups = [('admin', profile.get('admin_wallets') or []), ('reserve', profile.get('reserve_wallets') or [])]
    for wallet_role, wallets in wallet_groups:
        for wallet in wallets:
            wallet = normalize_wallet_address(wallet)
            if not wallet:
                continue
            for chain_name in chain_list:
                source = _wallet_activity_source_for_chain(profile, chain_name)
                if not source:
                    continue
                try:
                    metrics = fetch_wallet_activity_from_source(wallet, chain_name, source)
                    snapshot_id = upsert_wallet_activity_snapshot(
                        tenant_id,
                        wallet,
                        wallet_role,
                        chain_name,
                        metrics.pop('source_mode', str(source.get('mode') or 'etherscan_compatible')),
                        **metrics,
                    )
                    refreshed.append({'snapshot_id': snapshot_id, 'wallet_address': wallet, 'wallet_role': wallet_role, 'chain_name': chain_name})
                except Exception as exc:
                    errors.append({'wallet_address': wallet, 'wallet_role': wallet_role, 'chain_name': chain_name, 'error': str(exc)})
    if refreshed or errors:
        audit_event(tenant_id, user_id, 'monitoring.wallet.refresh', 'watch_profile', str(profile_id), 'Wallet activity refresh attempted for monitoring profile', {'refreshed': refreshed, 'errors': errors})
    return {'profile_id': profile_id, 'refreshed': refreshed, 'errors': errors}



def evaluate_wallet_activity(profile: Dict[str, Any]) -> Dict[str, Any]:
    wallet_addresses = [*profile.get('admin_wallets', []), *profile.get('reserve_wallets', [])]
    snapshots = list_wallet_activity_snapshots(int(profile['tenant_id']), wallet_addresses=wallet_addresses)
    chains = {str(chain).lower() for chain in (profile.get('chain_list') or [])}
    if chains:
        snapshots = [item for item in snapshots if str(item.get('chain_name') or '').lower() in chains]
    thresholds = {**DEFAULT_MONITORING_SIGNAL_OVERRIDES, **(profile.get('signal_overrides') or {})}
    warning_admin = int(thresholds.get('wallet_admin_burst_warning_txs', 6) or 6)
    critical_admin = int(thresholds.get('wallet_admin_burst_critical_txs', 12) or 12)
    warning_outflow = float(thresholds.get('wallet_reserve_outflow_warning_native', 0.5) or 0.5)
    critical_outflow = float(thresholds.get('wallet_reserve_outflow_critical_native', 2.0) or 2.0)
    stale_minutes = int(thresholds.get('wallet_stale_minutes', 1440) or 1440)

    layer_summary: List[str] = []
    explanations: List[str] = []
    alert_candidates: List[Dict[str, Any]] = []
    risk_delta = 0
    hard_failures = 0
    admin_burst_detected = False
    reserve_outflow_detected = False
    stale_wallets = 0
    latest_seen: datetime | None = None
    total_tx_count = 0

    if not snapshots:
        layer_summary.append('No wallet activity snapshots available yet; profile is tracking public addresses only.')
        return {
            'layer_summary': layer_summary,
            'explanations': explanations,
            'alert_candidates': alert_candidates,
            'risk_delta': 0,
            'hard_failures': 0,
            'snapshots': [],
            'signals': {'wallet_snapshots': 0, 'coverage': 'configured_only'},
        }

    for snapshot in snapshots:
        total_tx_count += int(snapshot.get('tx_count_24h') or 0)
        seen = parse_utc(snapshot.get('last_seen_at'))
        if seen and (latest_seen is None or seen > latest_seen):
            latest_seen = seen
        age_minutes = int((utc_dt() - seen).total_seconds() // 60) if seen else None
        snapshot['age_minutes'] = age_minutes
        if age_minutes is not None and age_minutes >= stale_minutes:
            stale_wallets += 1
        if snapshot.get('wallet_role') == 'admin' and int(snapshot.get('tx_count_24h') or 0) >= warning_admin:
            admin_burst_detected = True
            severity = 'high' if int(snapshot.get('tx_count_24h') or 0) >= critical_admin else 'medium'
            risk_delta += 22 if severity == 'high' else 12
            explanations.append(f"Admin wallet burst activity detected on {snapshot['chain_name']}: {snapshot['tx_count_24h']} tx in the last 24h.")
            alert_candidates.append({'alert_key': f"wallet_admin_burst_{snapshot['chain_name']}_{snapshot['wallet_address'][-6:]}", 'severity': severity, 'source': 'wallet.connector', 'summary': f"Admin wallet burst on {snapshot['chain_name']}", 'details': {'wallet_address': snapshot['wallet_address'], 'wallet_role': snapshot['wallet_role'], 'tx_count_24h': snapshot['tx_count_24h'], 'chain_name': snapshot['chain_name']}})
        if snapshot.get('wallet_role') == 'reserve' and float(snapshot.get('outgoing_native_amount_24h') or 0.0) >= warning_outflow:
            reserve_outflow_detected = True
            outgoing = float(snapshot.get('outgoing_native_amount_24h') or 0.0)
            severity = 'high' if outgoing >= critical_outflow else 'medium'
            risk_delta += 24 if severity == 'high' else 14
            if severity == 'high':
                hard_failures += 1
            explanations.append(f"Reserve wallet outflow on {snapshot['chain_name']} reached {outgoing:.4f} native units in the last 24h.")
            alert_candidates.append({'alert_key': f"wallet_reserve_outflow_{snapshot['chain_name']}_{snapshot['wallet_address'][-6:]}", 'severity': severity, 'source': 'wallet.connector', 'summary': f"Reserve wallet outflow above threshold on {snapshot['chain_name']}", 'details': {'wallet_address': snapshot['wallet_address'], 'wallet_role': snapshot['wallet_role'], 'outgoing_native_amount_24h': outgoing, 'chain_name': snapshot['chain_name']}})

    if admin_burst_detected:
        layer_summary.append('Admin wallet activity is above the configured burst threshold.')
    if reserve_outflow_detected:
        layer_summary.append('Reserve wallet movement exceeded the configured outflow threshold.')
    if stale_wallets:
        risk_delta += min(10, stale_wallets * 2)
        layer_summary.append(f'{stale_wallets} watched wallet snapshots are stale relative to the configured freshness window.')
        explanations.append('One or more watched wallets have not produced fresh telemetry within the configured stale window.')
    if not layer_summary:
        layer_summary.append('Wallet activity telemetry is healthy across the watched addresses.')
    return {
        'layer_summary': layer_summary,
        'explanations': explanations,
        'alert_candidates': alert_candidates,
        'risk_delta': risk_delta,
        'hard_failures': hard_failures,
        'snapshots': snapshots,
        'signals': {
            'wallet_snapshots': len(snapshots),
            'total_tx_count_24h': total_tx_count,
            'admin_burst_detected': admin_burst_detected,
            'reserve_outflow_detected': reserve_outflow_detected,
            'stale_wallets': stale_wallets,
            'latest_seen_at': latest_seen.strftime('%Y-%m-%d %H:%M:%S UTC') if latest_seen else None,
        },
    }



def apply_wallet_activity_to_decision(decision: Dict[str, Any], wallet_eval: Dict[str, Any]) -> Dict[str, Any]:
    updated = dict(decision)
    updated['explanations'] = list(decision.get('explanations', []))
    updated['headline_findings'] = list(decision.get('headline_findings', []))
    updated['alert_candidates'] = list(decision.get('alert_candidates', []))
    updated['control_layers'] = dict(decision.get('control_layers', {}))
    updated['control_layers']['wallet_activity'] = wallet_eval.get('layer_summary', [])
    updated['wallet_activity'] = {'signals': wallet_eval.get('signals', {}), 'snapshots': wallet_eval.get('snapshots', [])}
    updated['explanations'].extend(wallet_eval.get('explanations', []))
    updated['alert_candidates'].extend(wallet_eval.get('alert_candidates', []))
    if wallet_eval.get('layer_summary'):
        updated['headline_findings'].append(f"Wallet Activity: {wallet_eval['layer_summary'][0]}")
    risk_score = min(100, int(updated.get('risk_score', 0)) + int(wallet_eval.get('risk_delta', 0) or 0))
    updated['risk_score'] = risk_score
    status = updated.get('status', 'allowed')
    if status != 'blocked':
        status = status_for(risk_score)
    if wallet_eval.get('hard_failures') and risk_score >= 75:
        status = 'blocked'
    updated['status'] = status
    updated['severity'] = severity_for(risk_score)
    updated['summary'] = {
        'blocked': 'Privileged change or monitored environment blocked because platform and wallet telemetry flagged unacceptable risk.',
        'review': 'Monitored environment requires analyst review before execution can continue.',
        'allowed': 'Monitored environment remains within configured wallet, platform, and resilience thresholds.',
    }[status]
    return updated


def list_monitoring_runs(tenant_id: int, profile_id: int | None = None, limit: int = 25) -> List[Dict[str, Any]]:
    with db() as conn:
        if profile_id is None:
            rows = conn.execute('SELECT * FROM monitoring_runs WHERE tenant_id = ? ORDER BY id DESC LIMIT ?', (tenant_id, limit)).fetchall()
        else:
            rows = conn.execute('SELECT * FROM monitoring_runs WHERE tenant_id = ? AND watch_profile_id = ? ORDER BY id DESC LIMIT ?', (tenant_id, profile_id, limit)).fetchall()
    for row in rows:
        row['decision'] = _parse_json_blob(row.get('decision_json'), {})
        row['raw_signals'] = _parse_json_blob(row.get('raw_signals_json'), {})
    return rows


def monitoring_profile_due(profile: Dict[str, Any]) -> bool:
    if not profile.get('is_active') or profile.get('mode') != 'auto_watch':
        return False
    last_checked_at = parse_utc(profile.get('last_checked_at'))
    if not last_checked_at:
        return True
    frequency_seconds = int(profile.get('frequency_seconds') or 300)
    return utc_dt() >= last_checked_at + timedelta(seconds=frequency_seconds)


def list_monitoring_profiles(tenant_id: int, mode: str | None = None) -> List[Dict[str, Any]]:
    with db() as conn:
        if mode:
            rows = conn.execute('SELECT * FROM watch_profiles WHERE tenant_id = ? AND mode = ? ORDER BY id DESC', (tenant_id, mode)).fetchall()
        else:
            rows = conn.execute('SELECT * FROM watch_profiles WHERE tenant_id = ? ORDER BY id DESC', (tenant_id,)).fetchall()
    profiles = [_inflate_monitoring_profile(row) for row in rows]
    latest_by_profile: Dict[int, Dict[str, Any]] = {}
    for run in list_monitoring_runs(tenant_id, limit=100):
        latest_by_profile.setdefault(int(run['watch_profile_id']), run)
    for profile in profiles:
        profile['latest_run'] = latest_by_profile.get(int(profile['id']))
        profile['is_due'] = monitoring_profile_due(profile)
    return profiles


def get_monitoring_profile(tenant_id: int, profile_id: int) -> Dict[str, Any] | None:
    with db() as conn:
        row = conn.execute('SELECT * FROM watch_profiles WHERE tenant_id = ? AND id = ?', (tenant_id, profile_id)).fetchone()
    if not row:
        return None
    profile = _inflate_monitoring_profile(row)
    runs = list_monitoring_runs(tenant_id, profile_id=profile_id, limit=10)
    profile['latest_run'] = runs[0] if runs else None
    profile['recent_runs'] = runs
    profile['is_due'] = monitoring_profile_due(profile)
    profile['wallet_snapshots'] = list_wallet_activity_snapshots(tenant_id, wallet_addresses=[*profile.get('admin_wallets', []), *profile.get('reserve_wallets', [])])
    return profile


def create_monitoring_profile(user_id: int, payload: MonitoringProfileCreateRequest) -> int:
    permission_for_tenant(user_id, payload.tenant_id, 'monitoring.manage')
    now_value = utc_now()
    thresholds = {**DEFAULT_MONITORING_THRESHOLDS, **payload.thresholds}
    signal_overrides = {**DEFAULT_MONITORING_SIGNAL_OVERRIDES, **payload.signal_overrides}
    with db() as conn:
        profile_id = int(conn.execute(
            '''
            INSERT INTO watch_profiles (
                tenant_id, name, description, environment, asset_type, mode, frequency_seconds,
                contract_name, admin_wallets_json, reserve_wallets_json, oracle_endpoints_json, chain_list_json,
                notification_emails_json, webhook_url, thresholds_json, signal_overrides_json, is_active,
                last_checked_at, last_status, last_risk_score, created_by_user_id, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''',
            (
                payload.tenant_id,
                payload.name.strip(),
                payload.description.strip(),
                payload.environment.strip().lower(),
                payload.asset_type.strip(),
                payload.mode,
                payload.frequency_seconds,
                payload.contract_name.strip(),
                json.dumps(payload.admin_wallets),
                json.dumps(payload.reserve_wallets),
                json.dumps(payload.oracle_endpoints),
                json.dumps(payload.chain_list),
                json.dumps(payload.notification_emails),
                payload.webhook_url.strip() if payload.webhook_url else None,
                json.dumps(thresholds),
                json.dumps(signal_overrides),
                1 if payload.is_active else 0,
                None,
                'never',
                0,
                user_id,
                now_value,
                now_value,
            ),
        ).lastrowid)
    audit_event(payload.tenant_id, user_id, 'monitoring.profile.create', 'watch_profile', str(profile_id), 'Auto Watch profile created', {'name': payload.name, 'mode': payload.mode})
    return profile_id


def set_monitoring_profile_state(tenant_id: int, profile_id: int, user_id: int, is_active: bool) -> Dict[str, Any]:
    permission_for_tenant(user_id, tenant_id, 'monitoring.manage')
    now_value = utc_now()
    with db() as conn:
        existing = conn.execute('SELECT * FROM watch_profiles WHERE tenant_id = ? AND id = ?', (tenant_id, profile_id)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail='Monitoring profile not found')
        conn.execute('UPDATE watch_profiles SET is_active = ?, updated_at = ? WHERE id = ?', (1 if is_active else 0, now_value, profile_id))
    audit_event(tenant_id, user_id, 'monitoring.profile.state', 'watch_profile', str(profile_id), 'Monitoring profile state updated', {'is_active': is_active})
    return get_monitoring_profile(tenant_id, profile_id) or {}


def build_monitoring_simulation_payload(profile: Dict[str, Any]) -> SimulationRequest:
    signal_overrides = {**DEFAULT_MONITORING_SIGNAL_OVERRIDES, **profile.get('signal_overrides', {})}
    oracle_count = max(1, len(profile.get('oracle_endpoints', [])) or int(signal_overrides.get('oracle_source_count', 3) or 3))
    chain_count = max(1, len(profile.get('chain_list', [])) or int(signal_overrides.get('chain_count', 2) or 2))
    admin_wallets = profile.get('admin_wallets') or []
    payload = {
        'tenant_id': int(profile['tenant_id']),
        'asset_name': profile['name'],
        'environment': profile.get('environment', 'production'),
        'action': 'auto_watch_scan',
        'contract_name': profile.get('contract_name') or 'TreasuryTokenProxy',
        'requested_by': admin_wallets[0] if admin_wallets else '0xAUTO0000000000000000000000000000000WATCH',
        'notes': f"Auto Watch run for profile #{profile['id']}",
        'oracle_source_count': oracle_count,
        'oracle_healthy_sources': min(int(signal_overrides.get('oracle_healthy_sources', oracle_count) or oracle_count), oracle_count),
        'chain_count': chain_count,
        **{k: v for k, v in signal_overrides.items() if k != 'wallet_activity_sources'},
    }
    return SimulationRequest(**payload)


def run_monitoring_profile(user_id: int, tenant_id: int, profile_id: int, trigger: str = 'manual') -> Dict[str, Any]:
    permission_for_tenant(user_id, tenant_id, 'monitoring.manage')
    profile = get_monitoring_profile(tenant_id, profile_id)
    if not profile:
        raise HTTPException(status_code=404, detail='Monitoring profile not found')
    refresh_wallet_activity_for_profile(user_id, tenant_id, profile_id)
    profile = get_monitoring_profile(tenant_id, profile_id) or profile
    payload = build_monitoring_simulation_payload(profile)
    policies = list_policies(tenant_id)
    decision = evaluate_policies(policies, payload)
    wallet_eval = evaluate_wallet_activity(profile)
    decision = apply_wallet_activity_to_decision(decision, wallet_eval)
    now_value = utc_now()
    raw_signals = {'simulation_payload': payload.model_dump(), 'wallet_activity': wallet_eval.get('signals', {}), 'wallet_snapshots': wallet_eval.get('snapshots', [])}
    with db() as conn:
        monitoring_run_id = int(conn.execute(
            '''
            INSERT INTO monitoring_runs (
                tenant_id, watch_profile_id, triggered_by, status, overall_risk, severity, summary,
                decision_json, raw_signals_json, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''',
            (
                tenant_id,
                profile_id,
                trigger,
                decision['status'],
                decision['risk_score'],
                decision['severity'],
                decision['summary'],
                json.dumps(decision),
                json.dumps(raw_signals),
                now_value,
            ),
        ).lastrowid)
        conn.execute(
            'UPDATE watch_profiles SET last_checked_at = ?, last_status = ?, last_risk_score = ?, updated_at = ? WHERE id = ?',
            (now_value, decision['status'], decision['risk_score'], now_value, profile_id),
        )
    audit_event(tenant_id, user_id, 'monitoring.profile.run', 'watch_profile', str(profile_id), 'Monitoring profile evaluated', {'monitoring_run_id': monitoring_run_id, 'status': decision['status'], 'risk_score': decision['risk_score'], 'trigger': trigger, 'wallet_signals': wallet_eval.get('signals', {})})
    state_key = f'watch_profile_{profile_id}_status'
    if decision['status'] in {'review', 'blocked'}:
        create_or_update_alert(tenant_id, state_key, 'high' if decision['status'] == 'blocked' else 'medium', 'monitoring.auto_watch', f"Auto Watch profile {profile['name']} entered {decision['status']}", {'watch_profile_id': profile_id, 'monitoring_run_id': monitoring_run_id, 'risk_score': decision['risk_score'], 'trigger': trigger})
    for candidate in decision.get('alert_candidates', []):
        create_or_update_alert(tenant_id, f"profile_{profile_id}_{candidate['alert_key']}", candidate['severity'], candidate['source'], candidate['summary'], {**candidate['details'], 'watch_profile_id': profile_id, 'monitoring_run_id': monitoring_run_id})
    incident_id = None
    threshold = int(get_admin_setting_map(tenant_id).get('auto_incident_min_risk', '80'))
    if decision['status'] == 'blocked' and decision['risk_score'] >= threshold:
        incident_id = create_incident_record(tenant_id, user_id, title=f"Auto Watch escalation for {profile['name']}", severity=decision['severity'], status='open', summary=decision['summary'], source='auto_watch')
        audit_event(tenant_id, user_id, 'incident.create.auto_watch', 'incident', str(incident_id), 'Auto-created incident from Auto Watch profile', {'watch_profile_id': profile_id, 'monitoring_run_id': monitoring_run_id})
    return {
        'monitoring_run_id': monitoring_run_id,
        'watch_profile_id': profile_id,
        'incident_id': incident_id,
        'profile_name': profile['name'],
        'trigger': trigger,
        'wallet_activity': wallet_eval,
        **decision,
    }


def queue_due_monitoring_profiles(user_id: int, tenant_id: int) -> Dict[str, Any]:
    permission_for_tenant(user_id, tenant_id, 'monitoring.manage')
    queued_profile_ids: List[int] = []
    for profile in list_monitoring_profiles(tenant_id):
        if not profile['is_due']:
            continue
        enqueue_job(job_type='monitoring.run_profile', tenant_id=tenant_id, user_id=user_id, available_at=utc_now(), payload={'profile_id': int(profile['id']), 'tenant_id': tenant_id, 'user_id': user_id, 'triggered_by': 'auto_watch.dispatch'}, max_attempts=settings.webhook_max_retries)
        queued_profile_ids.append(int(profile['id']))
    audit_event(tenant_id, user_id, 'monitoring.dispatch', 'tenant', str(tenant_id), 'Queued due monitoring profiles', {'queued_profile_ids': queued_profile_ids})
    return {'queued_profiles': len(queued_profile_ids), 'profile_ids': queued_profile_ids}



def monitoring_mode_dashboard(tenant_id: int, mode: str) -> Dict[str, Any]:
    profiles = list_monitoring_profiles(tenant_id, mode=mode)
    profile_ids = {int(item['id']) for item in profiles}
    runs = [item for item in list_monitoring_runs(tenant_id, limit=50) if int(item['watch_profile_id']) in profile_ids]
    alerts = [item for item in list_alerts(tenant_id) if int(item.get('details', {}).get('watch_profile_id') or 0) in profile_ids]
    return {
        'mode': mode,
        'profiles': profiles,
        'recent_runs': runs[:10],
        'recent_alerts': alerts[:10],
        'profiles_count': len(profiles),
        'active_profiles': sum(1 for item in profiles if item['is_active']),
        'due_profiles': sum(1 for item in profiles if item.get('is_due')),
        'open_alerts': sum(1 for item in alerts if item['status'] == 'open'),
        'critical_alerts': sum(1 for item in alerts if item['status'] == 'open' and item['severity'] == 'critical'),
        'blocked_runs': sum(1 for item in runs if item['status'] == 'blocked'),
        'review_runs': sum(1 for item in runs if item['status'] == 'review'),
        'last_scan_at': runs[0]['created_at'] if runs else None,
    }


def monitoring_workspace_overview(tenant_id: int) -> Dict[str, Any]:
    watch = monitoring_mode_dashboard(tenant_id, 'auto_watch')
    review = monitoring_mode_dashboard(tenant_id, 'auto_review')
    enforce = monitoring_mode_dashboard(tenant_id, 'auto_enforce')
    incidents = list_incidents(tenant_id)[:8]
    return {
        'watch': watch,
        'review': review,
        'enforce': enforce,
        'profiles_count': watch['profiles_count'] + review['profiles_count'] + enforce['profiles_count'],
        'active_profiles': watch['active_profiles'] + review['active_profiles'] + enforce['active_profiles'],
        'open_alerts': watch['open_alerts'] + review['open_alerts'] + enforce['open_alerts'],
        'critical_alerts': watch['critical_alerts'] + review['critical_alerts'] + enforce['critical_alerts'],
        'pending_reviews': review['review_runs'] + review['blocked_runs'],
        'active_enforcements': enforce['blocked_runs'],
        'recent_incidents': incidents[:6],
        'last_scan_at': watch['last_scan_at'] or review['last_scan_at'] or enforce['last_scan_at'],
    }


def monitoring_overview(tenant_id: int) -> Dict[str, Any]:
    return monitoring_mode_dashboard(tenant_id, 'auto_watch')


def seed_auto_watch_data() -> None:
    with db() as conn:
        existing = conn.execute('SELECT COUNT(*) AS count FROM watch_profiles').fetchone()['count']
        tenants = conn.execute('SELECT * FROM tenants ORDER BY id').fetchall()
        admin_user = conn.execute('SELECT * FROM users WHERE email = ?', (DEMO_USER_EMAIL,)).fetchone()
        if existing == 0:
            for tenant in tenants:
                conn.execute(
                    '''
                    INSERT INTO watch_profiles (
                        tenant_id, name, description, environment, asset_type, mode, frequency_seconds,
                        contract_name, admin_wallets_json, reserve_wallets_json, oracle_endpoints_json, chain_list_json,
                        notification_emails_json, webhook_url, thresholds_json, signal_overrides_json, is_active,
                        last_checked_at, last_status, last_risk_score, created_by_user_id, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''',
                    (
                        tenant['id'],
                        f"{tenant['name']} Auto Watch",
                        'Live-style monitoring profile seeded for Decoda Auto Watch Mode.',
                        tenant['environment'],
                        'Treasury token',
                        'auto_watch',
                        300,
                        'TreasuryTokenProxy',
                        json.dumps(['0xAUTO0000000000000000000000000000000WATCH']),
                        json.dumps(['0xRESERVE00000000000000000000000000000001']),
                        json.dumps(['Bloomberg', 'Reuters', 'Fedwire']),
                        json.dumps(['ethereum', 'avalanche']),
                        json.dumps([DEMO_USER_EMAIL]),
                        None,
                        json.dumps(DEFAULT_MONITORING_THRESHOLDS),
                        json.dumps(DEFAULT_MONITORING_SIGNAL_OVERRIDES),
                        1,
                        None,
                        'never',
                        0,
                        int(admin_user['id']) if admin_user else None,
                        utc_now(),
                        utc_now(),
                    ),
                )
    with db() as conn:
        run_count = conn.execute('SELECT COUNT(*) AS count FROM monitoring_runs').fetchone()['count']
        first_profile = conn.execute('SELECT * FROM watch_profiles ORDER BY id ASC LIMIT 1').fetchone()
        admin_user = conn.execute('SELECT * FROM users WHERE email = ?', (DEMO_USER_EMAIL,)).fetchone()
    if run_count == 0 and first_profile and admin_user:
        run_monitoring_profile(int(admin_user['id']), int(first_profile['tenant_id']), int(first_profile['id']), trigger='seed')


def monitoring_summary(tenant_id: int) -> Dict[str, Any]:
    runs = list_simulation_runs(tenant_id, limit=200)
    alerts = list_alerts(tenant_id)
    monitor = monitoring_overview(tenant_id)
    with db() as conn:
        failed_jobs = conn.execute('SELECT COUNT(*) AS count FROM jobs WHERE tenant_id = ? AND status = ?', (tenant_id, 'failed')).fetchone()['count']
        queued_jobs = conn.execute('SELECT COUNT(*) AS count FROM jobs WHERE tenant_id = ? AND status = ?', (tenant_id, 'queued')).fetchone()['count']
        failed_deliveries = conn.execute(
            '''
            SELECT COUNT(*) AS count
            FROM webhook_deliveries wd
            JOIN webhooks w ON w.id = wd.webhook_id
            WHERE w.tenant_id = ? AND wd.status = ?
            ''',
            (tenant_id, 'failed'),
        ).fetchone()['count']
    blocked_runs = sum(1 for item in runs if item['status'] == 'blocked')
    return {
        'tenant_id': tenant_id,
        'queued_jobs': queued_jobs,
        'failed_jobs': failed_jobs,
        'failed_webhook_deliveries': failed_deliveries,
        'open_alerts': sum(1 for item in alerts if item['status'] == 'open'),
        'blocked_runs': blocked_runs,
        'latest_alerts': alerts[:5],
        'watch_profiles': monitor['profiles_count'],
        'active_watch_profiles': monitor['active_profiles'],
        'due_watch_profiles': monitor['due_profiles'],
        'recent_monitoring_runs': monitor['recent_runs'][:5],
        'last_monitoring_scan_at': monitor['last_scan_at'],
        'wallet_activity_snapshots': len(list_wallet_activity_snapshots(tenant_id)),
    }

def metrics_text() -> str:
    with db() as conn:
        tenant_ids = [row['tenant_id'] for row in conn.execute('SELECT DISTINCT tenant_id FROM user_tenants ORDER BY tenant_id').fetchall()]
    lines = ['# HELP decoda_jobs_total Jobs by status and tenant', '# TYPE decoda_jobs_total gauge']
    for tenant_id in tenant_ids:
        with db() as conn:
            statuses = conn.execute('SELECT status, COUNT(*) AS count FROM jobs WHERE tenant_id = ? GROUP BY status', (tenant_id,)).fetchall()
        for row in statuses:
            lines.append(f'decoda_jobs_total{{tenant_id="{tenant_id}",status="{row["status"]}"}} {row["count"]}')
    lines.extend(['# HELP decoda_alerts_open Open monitoring alerts by tenant', '# TYPE decoda_alerts_open gauge'])
    for tenant_id in tenant_ids:
        lines.append(f'decoda_alerts_open{{tenant_id="{tenant_id}"}} {sum(1 for item in list_alerts(int(tenant_id)) if item["status"] == "open")}')
    return '\n'.join(lines) + '\n'


def create_approval_request(user_id: int, payload: ApprovalCreateRequest) -> int:
    permission_for_tenant(user_id, payload.tenant_id, 'approval.request')
    now_value = utc_now()
    execute_job_type = payload.execute_job_type
    execute_payload = payload.execute_payload
    if payload.execute_on_approval and not execute_job_type and payload.target_type == 'simulation':
        execute_job_type = 'simulation.run'
        execute_payload = payload.target_payload
    with db() as conn:
        approval_id = int(conn.execute(
            '''
            INSERT INTO approval_requests (
                tenant_id, requester_user_id, approval_type, title, status, target_type, target_payload_json,
                required_approvals, approved_count, decision_summary, execute_job_type, execute_payload_json,
                created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''',
            (
                payload.tenant_id,
                user_id,
                payload.approval_type,
                payload.title,
                'pending',
                payload.target_type,
                json.dumps(payload.target_payload),
                payload.required_approvals,
                0,
                None,
                execute_job_type,
                json.dumps(execute_payload) if execute_payload is not None else None,
                now_value,
                now_value,
            ),
        ).lastrowid)
    audit_event(payload.tenant_id, user_id, 'approval.request', 'approval_request', str(approval_id), 'Approval request created', payload.model_dump())
    return approval_id


def apply_approval_decision(approval_id: int, actor_user_id: int, decision: str, notes: str | None = None) -> Dict[str, Any]:
    with db() as conn:
        approval = conn.execute('SELECT * FROM approval_requests WHERE id = ?', (approval_id,)).fetchone()
        if not approval:
            raise HTTPException(status_code=404, detail='Approval request not found')
    permission_for_tenant(actor_user_id, int(approval['tenant_id']), 'approval.approve')
    if int(approval['requester_user_id']) == actor_user_id:
        raise HTTPException(status_code=403, detail='Requester cannot approve their own request')
    if approval['status'] != 'pending':
        raise HTTPException(status_code=400, detail='Approval request is already resolved')
    now_value = utc_now()
    with db() as conn:
        existing = conn.execute('SELECT * FROM approval_actions WHERE approval_request_id = ? AND actor_user_id = ?', (approval_id, actor_user_id)).fetchone()
        if existing:
            raise HTTPException(status_code=400, detail='Actor already decided this request')
        conn.execute('INSERT INTO approval_actions (approval_request_id, actor_user_id, decision, notes, created_at) VALUES (?, ?, ?, ?, ?)', (approval_id, actor_user_id, decision, notes, now_value))
        if decision == 'reject':
            conn.execute('UPDATE approval_requests SET status = ?, decision_summary = ?, updated_at = ?, resolved_at = ? WHERE id = ?', ('rejected', notes or 'Rejected', now_value, now_value, approval_id))
            create_or_update_alert(int(approval['tenant_id']), f'approval_rejected_{approval_id}', 'medium', 'approval.workflow', f'Approval request #{approval_id} was rejected', {'notes': notes})
            audit_event(int(approval['tenant_id']), actor_user_id, 'approval.reject', 'approval_request', str(approval_id), 'Approval request rejected', {'notes': notes})
            return {'approval_id': approval_id, 'status': 'rejected'}
        approved_count = conn.execute('SELECT COUNT(*) AS count FROM approval_actions WHERE approval_request_id = ? AND decision = ?', (approval_id, 'approve')).fetchone()['count']
        status = 'approved' if approved_count >= int(approval['required_approvals']) else 'pending'
        resolved_at = now_value if status == 'approved' else None
        conn.execute('UPDATE approval_requests SET approved_count = ?, status = ?, updated_at = ?, resolved_at = ?, decision_summary = ? WHERE id = ?', (approved_count, status, now_value, resolved_at, 'Threshold satisfied' if status == 'approved' else None, approval_id))
    job_id = None
    if status == 'approved' and approval.get('execute_job_type') and approval.get('execute_payload_json'):
        exec_payload = json.loads(approval['execute_payload_json'])
        if approval['execute_job_type'] == 'simulation.run' and 'simulation' in exec_payload:
            exec_payload = {'simulation': exec_payload['simulation'], 'user_id': approval['requester_user_id']}
        elif approval['execute_job_type'] == 'simulation.run' and 'tenant_id' in exec_payload:
            exec_payload = {'simulation': exec_payload, 'user_id': approval['requester_user_id']}
        job_id = enqueue_job(job_type=approval['execute_job_type'], tenant_id=int(approval['tenant_id']), user_id=int(approval['requester_user_id']), available_at=utc_now(), payload=exec_payload, max_attempts=settings.webhook_max_retries)
    audit_event(int(approval['tenant_id']), actor_user_id, 'approval.approve', 'approval_request', str(approval_id), 'Approval request decision recorded', {'decision': decision, 'job_id': job_id})
    return {'approval_id': approval_id, 'status': status, 'approved_count': approved_count, 'job_id': job_id}


def export_package_bytes(tenant_id: int) -> bytes:
    reports = list_reports(tenant_id, limit=500)
    audits = list_audit_events(tenant_id, limit=1000)
    incidents = list_incidents(tenant_id)
    approvals = list_approval_requests(tenant_id)
    alerts = list_alerts(tenant_id)
    members = list_tenant_members(tenant_id)
    summary = monitoring_summary(tenant_id)
    market_events = list_market_surveillance_events(tenant_id)
    oracle_snapshots = list_oracle_integrity_snapshots(tenant_id)
    provenance_records = list_provenance_records(tenant_id)
    governance_controls = list_compliance_controls(tenant_id)
    resilience_states = list_resilience_states(tenant_id)
    wallet_snapshots = list_wallet_activity_snapshots(tenant_id)
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('summary.json', json.dumps(summary, indent=2))
        zf.writestr('reports.json', json.dumps(reports, indent=2))
        zf.writestr('audit.jsonl', '\n'.join(json.dumps(item) for item in audits))
        zf.writestr('incidents.json', json.dumps(incidents, indent=2))
        zf.writestr('approvals.json', json.dumps(approvals, indent=2))
        zf.writestr('alerts.json', json.dumps(alerts, indent=2))
        zf.writestr('market_events.json', json.dumps(market_events, indent=2))
        zf.writestr('oracle_snapshots.json', json.dumps(oracle_snapshots, indent=2))
        zf.writestr('provenance_records.json', json.dumps(provenance_records, indent=2))
        zf.writestr('governance_controls.json', json.dumps(governance_controls, indent=2))
        zf.writestr('resilience_states.json', json.dumps(resilience_states, indent=2))
        zf.writestr('wallet_activity_snapshots.json', json.dumps(wallet_snapshots, indent=2))
        zf.writestr('members.json', json.dumps(members, indent=2))
        csv_buf = io.StringIO()
        writer = csv.writer(csv_buf)
        writer.writerow(['report_code', 'asset_name', 'status', 'risk_score', 'generated_at'])
        for report in reports:
            writer.writerow([report['report_code'], report['content']['asset_name'], report['content']['decision']['status'], report['content']['decision']['risk_score'], report['created_at']])
        zf.writestr('reports.csv', csv_buf.getvalue())
    return buffer.getvalue()


def oidc_redirect_uri() -> str:
    return f"{settings.public_base_url}{settings.oidc_redirect_path}"


def oidc_start(provider_slug: str, next_path: str, login_hint: str | None = None) -> Dict[str, str]:
    with db() as conn:
        provider = conn.execute('SELECT * FROM oidc_providers WHERE slug = ? AND is_active = 1', (provider_slug,)).fetchone()
    if not provider:
        raise HTTPException(status_code=404, detail='OIDC provider not found')
    state_token = secrets.token_urlsafe(32)
    nonce_value = secrets.token_urlsafe(24)
    code_verifier = secrets.token_urlsafe(48)
    expires_at = (utc_dt() + timedelta(minutes=10)).strftime('%Y-%m-%d %H:%M:%S UTC')
    with db() as conn:
        conn.execute(
            'INSERT INTO oidc_states (provider_id, state_token, code_verifier, nonce_value, redirect_path, expires_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
            (provider['id'], state_token, code_verifier, nonce_value, next_path, expires_at, utc_now()),
        )
    provider_mode = (provider.get('mode') or 'mock').strip().lower()
    login_hint_value = (login_hint or settings.oidc_mock_default_email).strip().lower()
    if provider_mode == 'live':
        if not provider.get('client_id') or not provider.get('authorization_endpoint'):
            raise HTTPException(status_code=400, detail='OIDC provider is missing live-mode configuration')
        params = {
            'response_type': 'code',
            'client_id': provider['client_id'],
            'redirect_uri': oidc_redirect_uri(),
            'scope': provider.get('scopes') or 'openid profile email',
            'state': state_token,
            'nonce': nonce_value,
        }
        if login_hint_value:
            params['login_hint'] = login_hint_value
        authorize_url = f"{provider['authorization_endpoint']}?{urlencode(params)}"
    else:
        authorize_url = f"{provider['authorization_endpoint']}?state={state_token}&nonce={nonce_value}&login_hint={login_hint_value}"
    return {'provider': provider['name'], 'authorization_url': authorize_url, 'state': state_token, 'mode': provider_mode}

def oidc_complete_callback(state: str, code: str, request: Request) -> JSONResponse:
    with db() as conn:
        state_row = conn.execute(
            """
            SELECT os.*, op.slug AS provider_slug, op.name AS provider_name, op.mode AS provider_mode,
                   op.token_endpoint AS provider_token_endpoint, op.userinfo_endpoint AS provider_userinfo_endpoint,
                   op.client_id AS provider_client_id, op.client_secret AS provider_client_secret, op.scopes AS provider_scopes
            FROM oidc_states os JOIN oidc_providers op ON op.id = os.provider_id
            WHERE os.state_token = ?
            """,
            (state,),
        ).fetchone()
    if not state_row:
        raise HTTPException(status_code=400, detail='Invalid OIDC state')
    if state_row.get('consumed_at'):
        raise HTTPException(status_code=400, detail='OIDC state already used')
    expires_at = parse_utc(state_row['expires_at'])
    if expires_at and utc_dt() > expires_at:
        raise HTTPException(status_code=400, detail='OIDC state expired')

    provider_mode = (state_row.get('provider_mode') or 'mock').strip().lower()
    if provider_mode == 'live':
        token_endpoint = state_row.get('provider_token_endpoint')
        userinfo_endpoint = state_row.get('provider_userinfo_endpoint')
        client_id = state_row.get('provider_client_id')
        client_secret = state_row.get('provider_client_secret')
        if not token_endpoint or not userinfo_endpoint or not client_id or not client_secret:
            raise HTTPException(status_code=400, detail='OIDC live provider configuration is incomplete')
        try:
            with httpx.Client(timeout=settings.webhook_timeout_seconds + 5) as client:
                token_response = client.post(
                    token_endpoint,
                    data={
                        'grant_type': 'authorization_code',
                        'code': code,
                        'client_id': client_id,
                        'client_secret': client_secret,
                        'redirect_uri': oidc_redirect_uri(),
                        'code_verifier': state_row.get('code_verifier') or '',
                    },
                    headers={'Accept': 'application/json'},
                )
                token_response.raise_for_status()
                token_payload = token_response.json()
                access_token = token_payload.get('access_token')
                if not access_token:
                    raise RuntimeError('OIDC token response did not include access_token')
                userinfo_response = client.get(
                    userinfo_endpoint,
                    headers={'Authorization': f'Bearer {access_token}', 'Accept': 'application/json'},
                )
                userinfo_response.raise_for_status()
                userinfo = userinfo_response.json()
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f'OIDC callback exchange failed: {exc}') from exc
        email = (userinfo.get('email') or userinfo.get('preferred_username') or '').strip().lower()
        if not email:
            raise HTTPException(status_code=400, detail='OIDC userinfo did not include an email-like identifier')
        full_name = (userinfo.get('name') or userinfo.get('given_name') or email.split('@')[0].replace('.', ' ').title()).strip()
    else:
        email = code.strip().lower() if '@' in code else settings.oidc_mock_default_email
        full_name = email.split('@')[0].replace('.', ' ').title()

    now_value = utc_now()
    with db() as conn:
        user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
        if not user:
            salt = secrets.token_hex(16)
            user_id = int(conn.execute('INSERT INTO users (email, full_name, password_salt, password_hash, created_at) VALUES (?, ?, ?, ?, ?)', (email, full_name, salt, hash_password(secrets.token_urlsafe(24), salt), now_value)).lastrowid)
            user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
            tenant = conn.execute('SELECT * FROM tenants ORDER BY id LIMIT 1').fetchone()
            conn.execute('INSERT INTO user_tenants (user_id, tenant_id, role_name) VALUES (?, ?, ?)', (user_id, tenant['id'], 'reviewer'))
        conn.execute('UPDATE oidc_states SET consumed_at = ? WHERE id = ?', (now_value, state_row['id']))
    token = create_session(int(user['id']), request)
    audit_event(None, int(user['id']), 'auth.oidc.login', 'user', str(user['id']), f"OIDC login via {state_row['provider_name']}", {'provider_slug': state_row['provider_slug'], 'email': email, 'provider_mode': provider_mode})
    response = JSONResponse({'ok': True, 'redirect': state_row['redirect_path'], 'provider': state_row['provider_name'], 'mode': provider_mode})
    response.set_cookie(SESSION_COOKIE, token, httponly=True, secure=settings.session_cookie_secure, samesite=settings.session_cookie_samesite, max_age=settings.session_absolute_minutes * 60, path='/')
    return response

def deliver_webhook(webhook_id: int, event_type: str, event_payload: Dict[str, Any]) -> Dict[str, Any]:
    with db() as conn:
        webhook = conn.execute('SELECT * FROM webhooks WHERE id = ?', (webhook_id,)).fetchone()
        attempt_count = conn.execute('SELECT COUNT(*) AS count FROM webhook_deliveries WHERE webhook_id = ? AND event_type = ?', (webhook_id, event_type)).fetchone()['count'] + 1
    if not webhook or int(webhook['is_active']) != 1:
        raise RuntimeError('Webhook not active or not found')
    sent_at = utc_now()
    delivery_id = f'dlv_{secrets.token_hex(8)}'
    body = {'event_type': event_type, 'sent_at': sent_at, 'delivery_id': delivery_id, 'data': event_payload}
    raw_body = json.dumps(body, separators=(',', ':'))
    timestamp = str(int(datetime.now(timezone.utc).timestamp()))
    signed_payload = f'{timestamp}.{raw_body}'
    signature = hmac.new(webhook['secret_value'].encode('utf-8'), signed_payload.encode('utf-8'), hashlib.sha256).hexdigest()
    headers = {'Content-Type': 'application/json', 'X-Decoda-Event': event_type, 'X-Decoda-Delivery': delivery_id, 'X-Decoda-Attempt': str(attempt_count), 'X-Decoda-Signature': f't={timestamp},v1={signature}'}
    status = 'delivered'
    response_code = 200
    error_message = None
    try:
        if webhook['url'].startswith('mock://success'):
            response_code = 204
        elif webhook['url'].startswith('mock://fail'):
            response_code = 500
            raise RuntimeError('Mock webhook failure')
        else:
            with httpx.Client(timeout=settings.webhook_timeout_seconds) as client:
                response = client.post(webhook['url'], content=raw_body, headers=headers)
                response_code = response.status_code
                if response.status_code >= 300:
                    raise RuntimeError(f'Webhook returned HTTP {response.status_code}')
    except Exception as exc:
        status = 'failed'
        error_message = str(exc)
    with db() as conn:
        conn.execute('INSERT INTO webhook_deliveries (webhook_id, event_type, request_body, response_code, status, attempt_count, last_error, created_at, delivered_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', (webhook_id, event_type, raw_body, response_code, status, attempt_count, error_message, sent_at, sent_at if status == 'delivered' else None))
        conn.execute('UPDATE webhooks SET last_delivery_at = ?, updated_at = ? WHERE id = ?', (sent_at, sent_at, webhook_id))
    if status != 'delivered':
        create_or_update_alert(int(webhook['tenant_id']), f'webhook_failure_{webhook_id}', 'high', 'webhook.delivery', f'Webhook delivery failed for {webhook["name"]}', {'event_type': event_type, 'attempt_count': attempt_count, 'error': error_message})
        raise RuntimeError(error_message or 'Webhook delivery failed')
    return {'ok': True, 'webhook_id': webhook_id, 'response_code': response_code, 'delivery_id': delivery_id, 'attempt_count': attempt_count}


@app.get('/metrics')
def prometheus_metrics() -> PlainTextResponse:
    return PlainTextResponse(metrics_text(), media_type='text/plain; version=0.0.4')


@app.get('/api/v1/rbac/matrix')
def api_rbac_matrix(request: Request, tenant_id: int) -> Dict[str, Any]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'rbac.read')
    return {'tenant_id': tenant_id, 'roles': {name: sorted(list(perms)) for name, perms in ROLE_PERMISSIONS.items()}, 'members': list_tenant_members(tenant_id)}


@app.get('/api/auth/oidc/providers')
def api_oidc_providers() -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute('SELECT slug, name, issuer, authorization_endpoint, mode FROM oidc_providers WHERE is_active = 1 ORDER BY id').fetchall()
    return rows


@app.post('/api/auth/oidc/start')
def api_oidc_start(payload: OIDCStartRequest) -> Dict[str, str]:
    provider_slug = (payload.provider_slug or settings.oidc_default_provider_slug).strip().lower()
    return oidc_start(provider_slug, payload.next_path, payload.login_hint)


@app.get('/api/auth/oidc/mock/authorize')
def api_oidc_mock_authorize(state: str, nonce: str, login_hint: Optional[str] = None) -> Response:
    code = (login_hint or settings.oidc_mock_default_email).strip().lower()
    return RedirectResponse(url=f'/api/auth/oidc/callback?state={state}&code={code}', status_code=302)


@app.get('/api/auth/oidc/callback')
def api_oidc_callback(state: str, code: str, request: Request) -> JSONResponse:
    return oidc_complete_callback(state, code, request)


@app.get('/api/v1/tenant-users')
def api_tenant_users(request: Request, tenant_id: int) -> List[Dict[str, Any]]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'tenant_user.read')
    return list_tenant_members(tenant_id)


@app.post('/api/v1/tenant-users')
def api_tenant_users_create(payload: TenantUserCreateRequest, request: Request) -> Dict[str, Any]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), payload.tenant_id, 'tenant_user.manage')
    ensure_admin_reauth(user, request, payload.tenant_id)
    role_name = payload.role_name.strip().lower()
    if role_name not in ROLE_PERMISSIONS:
        raise HTTPException(status_code=400, detail='Unknown role')
    email = payload.email.strip().lower()
    temp_password = payload.temporary_password or 'Decoda123!'
    existing_user = None
    with db() as conn:
        existing_user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
        if not existing_user:
            salt = secrets.token_hex(16)
            user_id = int(conn.execute('INSERT INTO users (email, full_name, password_salt, password_hash, created_at) VALUES (?, ?, ?, ?, ?)', (email, payload.full_name.strip(), salt, hash_password(temp_password, salt), utc_now())).lastrowid)
        else:
            user_id = int(existing_user['id'])
        membership = conn.execute('SELECT * FROM user_tenants WHERE user_id = ? AND tenant_id = ?', (user_id, payload.tenant_id)).fetchone()
        if membership:
            conn.execute('UPDATE user_tenants SET role_name = ? WHERE user_id = ? AND tenant_id = ?', (role_name, user_id, payload.tenant_id))
        else:
            conn.execute('INSERT INTO user_tenants (user_id, tenant_id, role_name) VALUES (?, ?, ?)', (user_id, payload.tenant_id, role_name))
    audit_event(payload.tenant_id, int(user['id']), 'tenant_user.create', 'user', str(user_id), 'Tenant user created or assigned', {'email': email, 'role_name': role_name})
    return {'ok': True, 'user_id': user_id, 'email': email, 'role_name': role_name, 'temporary_password': temp_password if not existing_user else None}


@app.patch('/api/v1/tenant-users/{target_user_id}')
def api_tenant_users_update(target_user_id: int, payload: TenantUserUpdateRequest, request: Request, tenant_id: int) -> Dict[str, Any]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'tenant_user.manage')
    ensure_admin_reauth(user, request, tenant_id)
    with db() as conn:
        membership = conn.execute('SELECT * FROM user_tenants WHERE user_id = ? AND tenant_id = ?', (target_user_id, tenant_id)).fetchone()
        target_user = conn.execute('SELECT * FROM users WHERE id = ?', (target_user_id,)).fetchone()
        if not membership or not target_user:
            raise HTTPException(status_code=404, detail='Tenant user not found')
        if payload.role_name:
            role_name = payload.role_name.strip().lower()
            if role_name not in ROLE_PERMISSIONS:
                raise HTTPException(status_code=400, detail='Unknown role')
            conn.execute('UPDATE user_tenants SET role_name = ? WHERE user_id = ? AND tenant_id = ?', (role_name, target_user_id, tenant_id))
        if payload.user_active is not None:
            conn.execute('UPDATE users SET is_active = ? WHERE id = ?', (1 if payload.user_active else 0, target_user_id))
        if payload.membership_active is False:
            conn.execute('DELETE FROM user_tenants WHERE user_id = ? AND tenant_id = ?', (target_user_id, tenant_id))
    audit_event(tenant_id, int(user['id']), 'tenant_user.update', 'user', str(target_user_id), 'Tenant user updated', payload.model_dump(exclude_none=True))
    return {'ok': True, 'user_id': target_user_id}


@app.get('/api/v1/approvals')
def api_approvals(request: Request, tenant_id: int) -> List[Dict[str, Any]]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'approval.read')
    return list_approval_requests(tenant_id)


@app.post('/api/v1/approvals')
def api_approval_create(payload: ApprovalCreateRequest, request: Request) -> Dict[str, Any]:
    user = require_user(request)
    approval_id = create_approval_request(int(user['id']), payload)
    return {'ok': True, 'approval_id': approval_id}


@app.post('/api/v1/approvals/{approval_id}/decision')
def api_approval_decision(approval_id: int, payload: ApprovalDecisionRequest, request: Request) -> Dict[str, Any]:
    user = require_user(request)
    return apply_approval_decision(approval_id, int(user['id']), payload.decision, payload.notes)


@app.get('/api/v1/monitoring/summary')
def api_monitoring_summary(request: Request, tenant_id: int) -> Dict[str, Any]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'monitoring.read')
    return monitoring_summary(tenant_id)


@app.get('/api/v1/monitoring/profiles')
def api_monitoring_profiles(request: Request, tenant_id: int, mode: Optional[str] = None) -> List[Dict[str, Any]]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'monitoring.read')
    return list_monitoring_profiles(tenant_id, mode=mode)


@app.post('/api/v1/monitoring/profiles')
def api_monitoring_profiles_create(payload: MonitoringProfileCreateRequest, request: Request) -> Dict[str, Any]:
    user = require_user(request)
    profile_id = create_monitoring_profile(int(user['id']), payload)
    return {'ok': True, 'profile_id': profile_id}


@app.get('/api/v1/monitoring/runs')
def api_monitoring_runs(request: Request, tenant_id: int, profile_id: Optional[int] = None, mode: Optional[str] = None) -> List[Dict[str, Any]]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'monitoring.read')
    runs = list_monitoring_runs(tenant_id, profile_id=profile_id, limit=50)
    if mode:
        allowed_ids = {int(item['id']) for item in list_monitoring_profiles(tenant_id, mode=mode)}
        runs = [item for item in runs if int(item['watch_profile_id']) in allowed_ids]
    return runs


@app.post('/api/v1/monitoring/dispatch')
def api_monitoring_dispatch(request: Request, tenant_id: int) -> Dict[str, Any]:
    user = require_user(request)
    return queue_due_monitoring_profiles(int(user['id']), tenant_id)


@app.post('/api/v1/monitoring/profiles/{profile_id}/run-now')
def api_monitoring_profile_run_now(profile_id: int, request: Request, tenant_id: int) -> Dict[str, Any]:
    user = require_user(request)
    return run_monitoring_profile(int(user['id']), tenant_id, profile_id, trigger='run_now')


@app.post('/api/v1/monitoring/profiles/{profile_id}/state')
def api_monitoring_profile_state(profile_id: int, payload: MonitoringProfileStateRequest, request: Request, tenant_id: int) -> Dict[str, Any]:
    user = require_user(request)
    profile = set_monitoring_profile_state(tenant_id, profile_id, int(user['id']), payload.is_active)
    return {'ok': True, 'profile': profile}


@app.get('/api/v1/monitoring/profiles/{profile_id}/wallet-activity')
def api_monitoring_profile_wallet_activity(profile_id: int, request: Request, tenant_id: int) -> Dict[str, Any]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'monitoring.read')
    profile = get_monitoring_profile(tenant_id, profile_id)
    if not profile:
        raise HTTPException(status_code=404, detail='Monitoring profile not found')
    return {'profile_id': profile_id, 'wallet_snapshots': profile.get('wallet_snapshots', []), 'wallet_evaluation': evaluate_wallet_activity(profile)}


@app.post('/api/v1/monitoring/profiles/{profile_id}/wallet-refresh')
def api_monitoring_profile_wallet_refresh(profile_id: int, request: Request, tenant_id: int) -> Dict[str, Any]:
    user = require_user(request)
    return refresh_wallet_activity_for_profile(int(user['id']), tenant_id, profile_id)


@app.post('/api/v1/monitoring/wallet-snapshots')
def api_monitoring_wallet_snapshot_upsert(payload: WalletActivitySnapshotUpsertRequest, request: Request) -> Dict[str, Any]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), payload.tenant_id, 'monitoring.manage')
    snapshot_id = upsert_wallet_activity_snapshot(payload.tenant_id, normalize_wallet_address(payload.wallet_address), payload.wallet_role, payload.chain_name, payload.source_mode, tx_count_24h=payload.tx_count_24h, incoming_tx_count_24h=payload.incoming_tx_count_24h, outgoing_tx_count_24h=payload.outgoing_tx_count_24h, outgoing_native_amount_24h=payload.outgoing_native_amount_24h, last_seen_at=payload.last_seen_at, burst_score=payload.burst_score, details=payload.details)
    audit_event(payload.tenant_id, int(user['id']), 'monitoring.wallet.snapshot.upsert', 'wallet_activity_snapshot', str(snapshot_id), 'Wallet activity snapshot upserted', payload.model_dump())
    return {'ok': True, 'snapshot_id': snapshot_id}


@app.get('/api/v1/alerts')
def api_alerts(request: Request, tenant_id: int) -> List[Dict[str, Any]]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'monitoring.read')
    return list_alerts(tenant_id)


@app.post('/api/v1/alerts')
def api_alerts_create(payload: MonitoringAlertCreateRequest, request: Request) -> Dict[str, Any]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), payload.tenant_id, 'monitoring.manage')
    alert_id = create_or_update_alert(payload.tenant_id, payload.alert_key, payload.severity, payload.source, payload.summary, payload.details)
    audit_event(payload.tenant_id, int(user['id']), 'monitoring.alert.upsert', 'alert', str(alert_id), 'Alert created or updated', payload.model_dump())
    return {'ok': True, 'alert_id': alert_id}



@app.get('/api/v1/threat-defense/market-events')
def api_market_events(request: Request, tenant_id: int) -> List[Dict[str, Any]]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'monitoring.read')
    return list_market_surveillance_events(tenant_id)


@app.get('/api/v1/oracle-integrity/snapshots')
def api_oracle_snapshots(request: Request, tenant_id: int) -> List[Dict[str, Any]]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'monitoring.read')
    return list_oracle_integrity_snapshots(tenant_id)


@app.get('/api/v1/oracle-integrity/provenance')
def api_provenance_records(request: Request, tenant_id: int) -> List[Dict[str, Any]]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'monitoring.read')
    return list_provenance_records(tenant_id)


@app.get('/api/v1/governance/controls')
def api_governance_controls(request: Request, tenant_id: int) -> List[Dict[str, Any]]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'monitoring.read')
    return list_compliance_controls(tenant_id)


@app.get('/api/v1/resilience/states')
def api_resilience_states(request: Request, tenant_id: int) -> List[Dict[str, Any]]:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'monitoring.read')
    return list_resilience_states(tenant_id)


@app.get('/api/v1/export/package')
def api_export_package(request: Request, tenant_id: int) -> StreamingResponse:
    user = require_user(request)
    permission_for_tenant(int(user['id']), tenant_id, 'export.package')
    package_bytes = export_package_bytes(tenant_id)
    headers = {'Content-Disposition': f'attachment; filename="tenant-{tenant_id}-evidence-package.zip"'}
    return StreamingResponse(io.BytesIO(package_bytes), media_type='application/zip', headers=headers)
