# Trust Pack + Pilot Readiness

This folder contains the customer-facing and internal readiness materials for the Decoda Security institutional platform.

## Included

- `security_questionnaire_pack.md` - concise answers for customer security review
- `security_overview.md` - architecture, controls, and boundaries summary
- `shared_responsibility_matrix.md` - Decoda vs customer responsibilities
- `data_retention_and_logging.md` - retention, audit, and evidence guidance
- `runbooks/` - operational and incident runbooks
- `sbom/` - SBOM and dependency governance materials
- `pentest/` - external penetration test preparation and rules of engagement
- `soc2/` - readiness tracker and evidence planning
- `design_partner/` - first pilot package, onboarding checklist, and success criteria

## Status language used in this pack

- **Implemented** - present in the current product build
- **Documented** - process or policy written and ready to follow
- **Planned** - intended next step, not yet complete
- **Not in place** - intentionally not claimed yet

## Important honesty note

This pack is designed to help customer security review and pilot readiness. It does **not** claim that Decoda currently has a completed SOC 2 report, completed external penetration test, or production deployment unless those items are separately attached as evidence.
