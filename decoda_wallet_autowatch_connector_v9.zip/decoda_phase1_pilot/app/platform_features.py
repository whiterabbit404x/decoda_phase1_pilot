
from __future__ import annotations

import json
from typing import Any, Dict, List, Mapping

from app.db import db

FRIENDLY_REGIONS = {'us-east', 'us-west', 'us-central', 'govcloud', 'canada', 'uk', 'eu'}


def seed_platform_feature_data(now_value: str) -> None:
    with db() as conn:
        tenants = conn.execute('SELECT id, name FROM tenants ORDER BY id').fetchall()
        for tenant in tenants:
            tenant_id = int(tenant['id'])
            if conn.execute('SELECT COUNT(*) AS count FROM market_surveillance_events WHERE tenant_id = ?', (tenant_id,)).fetchone()['count'] == 0:
                events = [
                    (tenant_id, 'MKT-001', 'medium', 'secondary_market', 'Wash-trading pattern flagged in Treasury-linked pool', json.dumps({'market_anomaly_score': 68, 'suspected_wash_trading': True, 'symbol': 'USTB-26A'}), now_value),
                    (tenant_id, 'MKT-002', 'low', 'secondary_market', 'Order-book spoofing check passed after validator quorum refresh', json.dumps({'market_anomaly_score': 21, 'suspected_spoofing': False, 'symbol': 'USTB-26B'}), now_value),
                ]
                conn.executemany('INSERT INTO market_surveillance_events (tenant_id, event_code, severity, source, summary, details_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)', events)
            if conn.execute('SELECT COUNT(*) AS count FROM oracle_integrity_snapshots WHERE tenant_id = ?', (tenant_id,)).fetchone()['count'] == 0:
                snapshots = [
                    (tenant_id, 'USTB-26A', 3, 3, 2, 100, 'healthy', json.dumps({'sources': ['Bloomberg', 'Reuters', 'Fedwire']}), now_value),
                    (tenant_id, 'USTB-26B', 3, 2, 7, 100, 'review', json.dumps({'sources': ['Bloomberg', 'Reuters', 'Fedwire'], 'degraded_source': 'Reuters'}), now_value),
                ]
                conn.executemany('INSERT INTO oracle_integrity_snapshots (tenant_id, asset_name, source_count, healthy_sources, max_drift_bps, collateral_ratio_pct, status, details_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', snapshots)
            if conn.execute('SELECT COUNT(*) AS count FROM provenance_records WHERE tenant_id = ?', (tenant_id,)).fetchone()['count'] == 0:
                records = [
                    (tenant_id, 'PRV-001', 'USTB-26A', 'minted', 1000000, 'spv-alpha', 'Baker Tilly', 1, json.dumps({'cusip': '912810TM0', 'bankruptcy_remote': True}), now_value),
                    (tenant_id, 'PRV-002', 'USTB-26A', 'redeemed', 250000, 'spv-alpha', 'Baker Tilly', 1, json.dumps({'custodian': 'Northern Trust'}), now_value),
                ]
                conn.executemany('INSERT INTO provenance_records (tenant_id, record_code, asset_name, event_type, token_amount, spv_name, auditor_name, collateral_verified, details_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', records)
            if conn.execute('SELECT COUNT(*) AS count FROM compliance_controls WHERE tenant_id = ?', (tenant_id,)).fetchone()['count'] == 0:
                controls = [
                    (tenant_id, 'CMP-001', 'KYC wrapper enforced', 'enabled', 'high', json.dumps({'kyc_wrapper_enabled': True, 'standard': 'ERC-3643'}), now_value, now_value),
                    (tenant_id, 'CMP-002', 'Travel rule propagation', 'enabled', 'high', json.dumps({'travel_rule_enabled': True, 'transport': 'TRP-v1'}), now_value, now_value),
                    (tenant_id, 'CMP-003', 'Geopatriation / friendly cloud', 'enabled', 'medium', json.dumps({'domestic_processing_only': True, 'region': 'us-east'}), now_value, now_value),
                ]
                conn.executemany('INSERT INTO compliance_controls (tenant_id, control_code, name, status, severity, details_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', controls)
            if conn.execute('SELECT COUNT(*) AS count FROM resilience_states WHERE tenant_id = ?', (tenant_id,)).fetchone()['count'] == 0:
                states = [
                    (tenant_id, 'Ethereum', 'healthy', 0, 1, 1, json.dumps({'token_supply': 1000000, 'finality': 'ok'}), now_value, now_value),
                    (tenant_id, 'Avalanche', 'review', 25, 1, 1, json.dumps({'token_supply': 999975, 'finality': 'delayed'}), now_value, now_value),
                ]
                conn.executemany('INSERT INTO resilience_states (tenant_id, chain_name, status, reconciliation_delta_tokens, circuit_breaker_armed, liquidity_backstop_ready, details_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', states)


def list_market_surveillance_events(tenant_id: int) -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute('SELECT * FROM market_surveillance_events WHERE tenant_id = ? ORDER BY id DESC', (tenant_id,)).fetchall()
    for row in rows:
        row['details'] = json.loads(row['details_json']) if row.get('details_json') else {}
    return rows


def list_oracle_integrity_snapshots(tenant_id: int) -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute('SELECT * FROM oracle_integrity_snapshots WHERE tenant_id = ? ORDER BY id DESC', (tenant_id,)).fetchall()
    for row in rows:
        row['details'] = json.loads(row['details_json']) if row.get('details_json') else {}
    return rows


def list_provenance_records(tenant_id: int) -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute('SELECT * FROM provenance_records WHERE tenant_id = ? ORDER BY id DESC', (tenant_id,)).fetchall()
    for row in rows:
        row['details'] = json.loads(row['details_json']) if row.get('details_json') else {}
    return rows


def list_compliance_controls(tenant_id: int) -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute('SELECT * FROM compliance_controls WHERE tenant_id = ? ORDER BY control_code', (tenant_id,)).fetchall()
    for row in rows:
        row['details'] = json.loads(row['details_json']) if row.get('details_json') else {}
    return rows


def list_resilience_states(tenant_id: int) -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute('SELECT * FROM resilience_states WHERE tenant_id = ? ORDER BY chain_name', (tenant_id,)).fetchall()
    for row in rows:
        row['details'] = json.loads(row['details_json']) if row.get('details_json') else {}
    return rows


def platform_feature_summary(tenant_id: int) -> Dict[str, Any]:
    market_events = list_market_surveillance_events(tenant_id)
    oracle_snapshots = list_oracle_integrity_snapshots(tenant_id)
    provenance_records = list_provenance_records(tenant_id)
    compliance_controls = list_compliance_controls(tenant_id)
    resilience_states = list_resilience_states(tenant_id)
    avg_drift = round(sum(int(item['max_drift_bps']) for item in oracle_snapshots) / len(oracle_snapshots), 1) if oracle_snapshots else 0
    return {
        'market_alerts': sum(1 for item in market_events if item['severity'] in {'high', 'critical', 'medium'}),
        'oracle_pairs': len(oracle_snapshots),
        'avg_oracle_drift_bps': avg_drift,
        'provenance_events': len(provenance_records),
        'compliance_controls_enabled': sum(1 for item in compliance_controls if item['status'] == 'enabled'),
        'resilience_chains': len(resilience_states),
        'circuit_breakers_armed': sum(1 for item in resilience_states if int(item['circuit_breaker_armed']) == 1),
    }


def evaluate_platform_signals(payload: Mapping[str, Any]) -> Dict[str, Any]:
    risk_delta = 0
    hard_failures = 0
    explanations: List[str] = []
    alerts: List[Dict[str, Any]] = []
    layers = {
        'threat_defense': [],
        'oracle_integrity': [],
        'compliance_governance': [],
        'systemic_resilience': [],
    }

    def add(layer: str, message: str) -> None:
        layers[layer].append(message)
        explanations.append(message)

    ai_score = int(payload.get('ai_zero_day_score', 15) or 0)
    market_score = int(payload.get('market_anomaly_score', 8) or 0)
    oracle_total = max(1, int(payload.get('oracle_source_count', 3) or 1))
    oracle_healthy = int(payload.get('oracle_healthy_sources', 3) or 0)
    oracle_drift = int(payload.get('oracle_max_drift_bps', 2) or 0)
    collateral_ratio = int(payload.get('collateral_ratio_pct', 100) or 0)
    chain_count = int(payload.get('chain_count', 2) or 0)
    reconciliation_delta = int(payload.get('reconciliation_delta_tokens', 0) or 0)
    region = str(payload.get('friendly_cloud_region', 'us-east')).strip().lower()

    if ai_score >= 70:
        risk_delta += 22
        add('threat_defense', f'AI zero-day scanner rated the path at {ai_score}/100 and escalated execution risk.')
        alerts.append({'alert_key': f"threat_ai_{ai_score}", 'severity': 'high', 'source': 'threat.zero_day', 'summary': 'High zero-day exploit probability on privileged path', 'details': {'ai_zero_day_score': ai_score}})
    else:
        add('threat_defense', f'AI zero-day scanner baseline stayed at {ai_score}/100.')
    if payload.get('flash_loan_exposure'):
        risk_delta += 16
        add('threat_defense', 'Flash-loan attack surface detected in the simulated path.')
    if payload.get('liquidity_drain_path_detected'):
        risk_delta += 18
        hard_failures += 1
        add('threat_defense', 'Liquidity drainer behavior matched a known critical kill-chain pattern.')
    if market_score >= 65 or payload.get('suspected_spoofing') or payload.get('suspected_wash_trading'):
        risk_delta += 14
        add('threat_defense', f'Secondary-market anomaly score reached {market_score}/100 with spoofing-or-wash indicators present.')
        alerts.append({'alert_key': f"market_{market_score}", 'severity': 'medium', 'source': 'market.surveillance', 'summary': 'Treasury token market anomaly requires analyst review', 'details': {'market_anomaly_score': market_score, 'suspected_spoofing': bool(payload.get('suspected_spoofing')), 'suspected_wash_trading': bool(payload.get('suspected_wash_trading'))}})
    else:
        add('threat_defense', 'No significant spoofing or wash-trading signal was detected in the secondary market view.')

    required_quorum = max(2, (oracle_total + 1) // 2)
    if oracle_healthy < required_quorum:
        risk_delta += 18
        hard_failures += 1
        add('oracle_integrity', f'Oracle health fell below quorum: {oracle_healthy}/{oracle_total} healthy sources.')
    else:
        add('oracle_integrity', f'Oracle quorum healthy: {oracle_healthy}/{oracle_total} institutional sources available.')
    if oracle_drift > 10:
        risk_delta += 14
        hard_failures += 1
        add('oracle_integrity', f'Oracle drift reached {oracle_drift} bps and can de-peg the token from underlying T-bills.')
        alerts.append({'alert_key': f"oracle_{oracle_drift}", 'severity': 'high', 'source': 'oracle.integrity', 'summary': 'Oracle drift exceeded acceptable Treasury tolerance', 'details': {'oracle_max_drift_bps': oracle_drift}})
    else:
        add('oracle_integrity', f'Oracle drift remained inside tolerance at {oracle_drift} bps.')
    if collateral_ratio < 100:
        risk_delta += 16
        hard_failures += 1
        add('oracle_integrity', f'Collateral ratio dropped to {collateral_ratio}% and breaks full-backing guarantees.')
    if not payload.get('spv_attested', True):
        risk_delta += 12
        hard_failures += 1
        add('oracle_integrity', 'Bankruptcy-remote SPV attestation is missing for this token line.')
    else:
        add('oracle_integrity', 'SPV attestation remains present for off-chain backing.')
    if not payload.get('provenance_complete', True):
        risk_delta += 10
        add('oracle_integrity', 'Digital provenance trail is incomplete for this issuance path.')

    if payload.get('sanctioned_wallet_hit'):
        risk_delta += 25
        hard_failures += 1
        add('compliance_governance', 'Sanctioned or unauthorized wallet detected in the transfer path.')
        alerts.append({'alert_key': 'sanctions_hit', 'severity': 'critical', 'source': 'compliance.wrapper', 'summary': 'Sanctions control blocked simulated transfer path', 'details': {'sanctioned_wallet_hit': True}})
    else:
        add('compliance_governance', 'No sanctioned wallet matched the current transfer path.')
    if not payload.get('kyc_wrapper_enabled', True):
        risk_delta += 14
        hard_failures += 1
        add('compliance_governance', 'KYC wrapper is disabled for a production-grade token transfer flow.')
    else:
        add('compliance_governance', 'KYC wrapper stays embedded in the token transfer path.')
    if not payload.get('travel_rule_enabled', True):
        risk_delta += 12
        add('compliance_governance', 'Travel rule propagation is disabled and reduces regulator-grade evidence.')
    else:
        add('compliance_governance', 'Travel rule propagation remains enabled.')
    if not payload.get('transfer_restriction_enabled', True):
        risk_delta += 10
        add('compliance_governance', 'Transfer restrictions are disabled for restricted security tokens.')
    if not payload.get('domestic_processing_only', True):
        risk_delta += 10
        add('compliance_governance', 'Geopatriation control is disabled for sensitive financial processing.')
    if region not in FRIENDLY_REGIONS:
        risk_delta += 12
        add('compliance_governance', f'Processing region {region} is outside configured domestic or friendly cloud boundaries.')
    else:
        add('compliance_governance', f'Processing remains inside approved cloud boundary: {region}.')

    if chain_count >= 4:
        risk_delta += 8
        add('systemic_resilience', f'Cross-chain footprint spans {chain_count} environments and raises reconciliation complexity.')
    else:
        add('systemic_resilience', f'Cross-chain footprint spans {chain_count} environments.')
    if reconciliation_delta > 0:
        risk_delta += 18
        hard_failures += 1 if reconciliation_delta >= 100 else 0
        add('systemic_resilience', f'Cross-chain reconciliation mismatch detected: {reconciliation_delta} tokens.')
        alerts.append({'alert_key': f"recon_{reconciliation_delta}", 'severity': 'high' if reconciliation_delta >= 100 else 'medium', 'source': 'cross_chain.reconciliation', 'summary': 'Cross-chain supply mismatch detected', 'details': {'reconciliation_delta_tokens': reconciliation_delta}})
    else:
        add('systemic_resilience', 'Cross-chain supply reconciled cleanly with no mismatch.')
    if not payload.get('circuit_breaker_armed', True):
        risk_delta += 12
        add('systemic_resilience', 'Circuit breaker is disarmed and cannot halt a digital run during stress.')
    else:
        add('systemic_resilience', 'Circuit breaker remains armed for volatility or cyber stress.')
    if not payload.get('liquidity_backstop_ready', True):
        risk_delta += 10
        add('systemic_resilience', 'Liquidity backstop protocol is not ready for emergency stabilization.')
    if not payload.get('settlement_finality_ok', True):
        risk_delta += 8
        add('systemic_resilience', 'Settlement finality assurance is degraded in the target environment.')

    return {
        'risk_delta': risk_delta,
        'hard_failures': hard_failures,
        'explanations': explanations,
        'layer_summaries': layers,
        'alert_candidates': alerts,
    }
