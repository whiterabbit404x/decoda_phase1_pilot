#!/usr/bin/env bash
set -euo pipefail
: "${DATABASE_URL:?DATABASE_URL must be set}"
out_dir="${1:-./backups}"
mkdir -p "$out_dir"
file="$out_dir/decoda_$(date -u +%Y%m%dT%H%M%SZ).sql.gz"
pg_dump "$DATABASE_URL" | gzip > "$file"
echo "created $file"
