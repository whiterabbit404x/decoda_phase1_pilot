# Dependency Governance Policy

## Objective

Reduce software supply-chain risk by controlling how third-party packages are introduced, updated, reviewed, and retired.

## Rules

1. Every new dependency must have a documented purpose.
2. Prefer widely maintained packages with clear release history.
3. Pin or constrain versions appropriately.
4. Review dependency changes in pull request or change review.
5. Remove unused dependencies promptly.
6. Generate and retain SBOM artifacts for releases.
7. Track critical vulnerabilities to remediation or compensating control.

## Review criteria

- maintenance activity
- license suitability
- security history
- transitive dependency footprint
- replacement options
