from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / '.env')


def env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {'1', 'true', 'yes', 'on'}


def env_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    app_name: str
    version: str
    base_dir: Path
    database_url: str
    app_env: str
    session_cookie: str
    session_cookie_secure: bool
    session_cookie_samesite: str
    session_idle_minutes: int
    session_absolute_minutes: int
    admin_reauth_minutes: int
    webhook_timeout_seconds: int
    webhook_max_retries: int
    worker_poll_seconds: int
    login_rate_window_seconds: int
    login_rate_max_attempts: int
    demo_user_email: str
    demo_user_password: str
    pbkdf2_rounds: int
    oidc_enabled: bool
    oidc_mock_enabled: bool
    oidc_default_provider_slug: str
    oidc_mock_default_email: str
    public_base_url: str
    oidc_redirect_path: str
    trusted_proxy_count: int
    default_worker_name: str
    wallet_connector_timeout_seconds: int
    wallet_connector_max_txs: int


def load_settings() -> Settings:
    app_env = os.getenv('APP_ENV', 'development').strip().lower()
    default_db = f"sqlite:///{(BASE_DIR / 'decoda_pilot.db').as_posix()}"
    return Settings(
        app_name='Decoda Security - Production Deployment Package',
        version='3.0.0',
        base_dir=BASE_DIR,
        database_url=os.getenv('DATABASE_URL', default_db),
        app_env=app_env,
        session_cookie=os.getenv('SESSION_COOKIE', 'decoda_session'),
        session_cookie_secure=env_bool('SESSION_COOKIE_SECURE', app_env == 'production'),
        session_cookie_samesite=os.getenv('SESSION_COOKIE_SAMESITE', 'lax'),
        session_idle_minutes=env_int('SESSION_IDLE_MINUTES', 30),
        session_absolute_minutes=env_int('SESSION_ABSOLUTE_MINUTES', 8 * 60),
        admin_reauth_minutes=env_int('ADMIN_REAUTH_MINUTES', 15),
        webhook_timeout_seconds=env_int('WEBHOOK_TIMEOUT_SECONDS', 5),
        webhook_max_retries=env_int('WEBHOOK_MAX_RETRIES', 5),
        worker_poll_seconds=env_int('WORKER_POLL_SECONDS', 2),
        login_rate_window_seconds=env_int('LOGIN_RATE_WINDOW_SECONDS', 300),
        login_rate_max_attempts=env_int('LOGIN_RATE_MAX_ATTEMPTS', 5),
        demo_user_email=os.getenv('DEMO_USER_EMAIL', 'admin@decoda.local').strip().lower(),
        demo_user_password=os.getenv('DEMO_USER_PASSWORD', 'Decoda123!'),
        pbkdf2_rounds=env_int('PBKDF2_ROUNDS', 120_000),
        oidc_enabled=env_bool('OIDC_ENABLED', True),
        oidc_mock_enabled=env_bool('OIDC_MOCK_ENABLED', True),
        oidc_default_provider_slug=os.getenv('OIDC_DEFAULT_PROVIDER_SLUG', 'mock-sso').strip().lower(),
        oidc_mock_default_email=os.getenv('OIDC_MOCK_DEFAULT_EMAIL', 'sso-admin@decoda.local').strip().lower(),
        public_base_url=os.getenv('PUBLIC_BASE_URL', 'http://127.0.0.1:8000').rstrip('/'),
        oidc_redirect_path=os.getenv('OIDC_REDIRECT_PATH', '/api/auth/oidc/callback').strip(),
        trusted_proxy_count=env_int('TRUSTED_PROXY_COUNT', 0),
        default_worker_name=os.getenv('DEFAULT_WORKER_NAME', 'worker-1').strip(),
        wallet_connector_timeout_seconds=env_int('WALLET_CONNECTOR_TIMEOUT_SECONDS', 8),
        wallet_connector_max_txs=env_int('WALLET_CONNECTOR_MAX_TXS', 25),
    )


settings = load_settings()
