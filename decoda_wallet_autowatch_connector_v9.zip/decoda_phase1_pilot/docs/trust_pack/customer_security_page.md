# Customer Security Page Draft

## Overview

Decoda Security is building an institutional platform for security workflows in tokenized-finance environments.

## What is currently available

- role-based permissions
- audit trail and evidence export
- approval workflow support
- webhook signing and retry behavior
- documented incident, support, backup, and release runbooks
- SBOM and dependency governance workflow templates

## What is in progress

- production identity provider integration
- external penetration test
- SOC 2 readiness program

## What we do not claim yet

- completed SOC 2 report
- completed external penetration test report
- production SCIM support
