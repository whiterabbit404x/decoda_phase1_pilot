#!/usr/bin/env bash
set -euo pipefail
: "${DATABASE_URL:?DATABASE_URL must be set}"
file="${1:?usage: ./scripts/restore_postgres.sh backup.sql.gz}"
gunzip -c "$file" | psql "$DATABASE_URL"
echo "restore complete from $file"
