# Customer Security Questionnaire Pack

This document provides concise answers for early-stage customer review. Replace bracketed placeholders where needed.

## 1. Company and service basics

**Service name:** Decoda Security  
**Primary use case:** Security analysis workflows for tokenized-finance operations  
**Deployment model:** SaaS or customer-managed deployment pattern supported by architecture  
**Environment status:** Institutional enterprise beta

## 2. Access control

**Do you support role-based access control?**  
Yes. The current build includes tenant-aware RBAC, role-to-permission mapping, and approval workflows for sensitive actions. Status: **Implemented**.

**Do you support SSO?**  
A mock OIDC-compatible flow is included for demonstration and internal testing. Production integration with customer IdPs is the next implementation step. Status: **Partially implemented / planned for production hookup**.

**Do you support MFA?**  
MFA should be enforced through the production identity provider. Local break-glass account protection is documented as an operational requirement. Status: **Planned for production deployment policy**.

**Do you support SCIM provisioning?**  
Not yet. Status: **Planned**.

## 3. Logging and auditability

**Are security-relevant actions logged?**  
Yes. The product records audit events for key actions including simulations, administrative changes, approval decisions, and webhook activity. Status: **Implemented**.

**Can customers export evidence?**  
Yes. The platform includes an exportable package endpoint that can bundle audit, alerts, approvals, members, and summary artifacts. Status: **Implemented**.

## 4. Application security

**How do you manage software security?**  
Decoda follows an SSDF-aligned development model with documented dependency governance, runbooks, and change management materials in this package. Status: **Documented / in progress**.

**Do you perform penetration testing?**  
An external penetration test is planned. Scope and rules-of-engagement materials are included in this trust pack. Status: **Planned**.

**Do you maintain an SBOM?**  
Yes, the repository includes an SBOM workflow template and dependency governance materials. Status: **Documented and ready to operationalize**.

## 5. Infrastructure and secrets

**How are secrets handled?**  
Application secrets are externalized into environment-based configuration and are intended to be placed into a managed secrets service in production. Status: **Implemented for separation / planned for managed secrets service in production**.

**How is data backed up?**  
Backup and restore procedures are documented in the runbooks. Production backup frequency and retention should be finalized per deployment environment. Status: **Documented**.

## 6. Compliance and assurance

**Do you have SOC 2?**  
Not yet. SOC 2 readiness materials are included and the intended path is readiness -> Type I -> Type II. Status: **In progress / not yet attested**.

**Do you align to industry standards?**  
Yes. The current program references NIST SSDF for secure software development, CISA SBOM guidance for software transparency, and OWASP ASVS for verification planning. Status: **Documented**.

## 7. Incident response and support

**Do you have an incident response process?**  
Yes. Incident classification, communication, containment, and post-incident review are documented in the included runbooks. Status: **Documented**.

**Do you provide support escalation?**  
Yes. Support workflow, severity levels, and internal ownership are documented in the support runbook. Status: **Documented**.

## 8. Honest current gaps

The following items should not be overstated in customer conversations:

- completed external penetration test report
- completed SOC 2 report
- production-grade live IdP integration
- production cloud monitoring evidence from a live environment
- SCIM provisioning
