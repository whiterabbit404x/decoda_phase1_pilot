# Operational acceptance

This package is suitable for a production deployment candidate.

It still requires real-world execution outside the repo for these claims:
- successful cloud deployment
- actual IdP connection and tested OIDC sign-in
- backup restore evidence
- external penetration test execution
- customer pilot evidence
- SOC 2 attestation
