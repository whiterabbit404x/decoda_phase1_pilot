# Data Retention and Logging Guidance

## Core event types

The current platform can produce and retain:

- authentication and session events
- tenant membership changes
- approval requests and decisions
- simulation requests and results metadata
- incident creation and updates
- webhook configuration and delivery attempts
- export package generation

## Recommended retention baseline

These are starting points and should be tuned per customer and legal requirements.

- security and audit events: 365 days minimum
- operational logs: 30 to 90 days hot retention, then archive as needed
- webhook delivery logs: 30 to 180 days depending on debugging needs
- incident records: retain through closure plus policy-driven archive period
- exported evidence bundles: generate on demand; retention depends on storage policy

## Logging practices

- prefer structured JSON logs
- include actor, tenant, action, timestamp, request correlation ID
- avoid logging secrets or full credential material
- classify customer-provided content before long-term retention
- separate security events from debug telemetry when possible

## Evidence handling

Evidence bundles should be immutable once generated and stored with:

- generation timestamp
- platform version
- tenant identifier
- hash/checksum where practical
