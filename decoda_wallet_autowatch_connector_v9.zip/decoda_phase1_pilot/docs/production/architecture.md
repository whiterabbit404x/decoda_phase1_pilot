# Production architecture

Recommended runtime layout:
- reverse proxy / load balancer
- 2+ app instances
- 1+ worker instances
- PostgreSQL
- centralized logging and monitoring
- object storage for report archives if exports become large

Suggested public endpoints:
- `infra.decodasecurity.com` for the UI
- `api.infra.decodasecurity.com` for external API if later split out
