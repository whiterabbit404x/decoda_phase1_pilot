# SBOM and Dependency Governance

This folder provides the operating materials for software component transparency and dependency risk management.

## Included

- `dependency_governance_policy.md`
- `vulnerability_management_policy.md`
- `sbom_generation.md`
- repository workflow at `.github/workflows/sbom.yml`

## Output format

The recommended default output is CycloneDX JSON stored as a build artifact.

## Minimum operating pattern

- generate SBOM on every release and at least weekly on default branch
- review dependency changes before release
- track high and critical vulnerabilities to remediation
- retain SBOM artifacts for audit evidence
