#!/usr/bin/env bash
set -euo pipefail
./scripts/prestart.sh
exec python -m app.worker
