# Real OIDC provider guide

The app now supports `mode=live` providers in the `oidc_providers` table.

Minimum provider fields:
- `authorization_endpoint`
- `token_endpoint`
- `userinfo_endpoint`
- `client_id`
- `client_secret`
- `scopes`
- `mode=live`

The redirect URI is built from:
- `PUBLIC_BASE_URL`
- `OIDC_REDIRECT_PATH`

Example redirect URI:
- `https://infra.decodasecurity.com/api/auth/oidc/callback`

Expected userinfo claims:
- `email` or `preferred_username`
- `name` or `given_name`

Production recommendation:
- leave `OIDC_MOCK_ENABLED=false`
- create at least one break-glass admin account with MFA at the identity provider
