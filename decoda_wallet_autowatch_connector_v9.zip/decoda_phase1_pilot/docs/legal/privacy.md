# Privacy Notice Starter

This starter document is for demo and pilot preparation.

- Describe what tenant data is stored.
- Describe audit events and report retention.
- Describe contact path for privacy requests.
- Replace all demo references before production use.
